public class AStar {

    public AStar(char[][] map) {
        throw new UnsupportedOperationException();
    }

    public static int getH(Node current, Node goal) {
        throw new UnsupportedOperationException();
    }

    public Iterable<Node> getPath(Node start, Node goal) {
        throw new UnsupportedOperationException();
    }
}
