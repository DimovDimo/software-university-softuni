﻿public enum Priority
{
    LOW,
    MEDIUM,
    HIGH,
    EXTREME
}