package app.domain.entities.enums;

public enum Role {
    ADMIN, USER
}
