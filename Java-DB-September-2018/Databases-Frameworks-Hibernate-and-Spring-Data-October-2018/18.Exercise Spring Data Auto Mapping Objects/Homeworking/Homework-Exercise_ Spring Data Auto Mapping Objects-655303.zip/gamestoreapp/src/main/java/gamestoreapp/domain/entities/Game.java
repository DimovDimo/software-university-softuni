package gamestoreapp.domain.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;


//<title>     |<price>    |<size> |<trailer>  |<thubnailURL>|<description>|<releaseDate>
//Overwatch   |100.00     |15.5   |FqnKB22pOC0



@Entity(name = "games")
public class Game extends BaseEntity{

	private String title;
	private BigDecimal price;
	private Double size;
	private String trailer;
	private String thumbnailUrl;
	private String description;
	private LocalDate releaseDate;
	
	public Game() {
	}
	
	@Column(name = "title",nullable = false,unique = true)
	@NotNull(message = "Title can not be null!")
	@Size(min = 3, max = 100, message = "Title must have length between 3 and 100 symbols!")
	@Pattern(regexp = "^[A-Z].*$", message = "Title has to begin with an uppercase letter!")
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	@Column(name = "price",nullable = false)
	@NotNull(message = "Price can not be null!")
	@Min(value = 0, message = "Price must be a positive number!")
	@Digits(integer = 19, fraction = 2, message = "Price must be floating point number with 2 digits precision!")
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	@Column(name = "size",nullable = false)
	@NotNull(message = "Size can not be null!")
	@Min(value = 0, message = "Size must be a positive number!")
	@Digits(integer = 19, fraction = 1, message = "Size must be floating point number with 1 digits precision!")
	public Double getSize() {
		return size;
	}
	public void setSize(Double size) {
		this.size = size;
	}
	
	@Column(name = "trailer")
	public String getTrailer() {
		return trailer;
	}
	public void setTrailer(String trailer) {
		this.trailer = trailer;
	}
	
	@Column(name = "thumbnail_url")
	@Pattern(regexp = "(http(s)?:\\/\\/).{5,}", message = "Invalid URL!")
	public String getThumbnailUrl() {
		return thumbnailUrl;
	}
	public void setThumbnailUrl(String thumbnailUrl) {
		this.thumbnailUrl = thumbnailUrl;
	}
	
	@Column(name = "description",columnDefinition = "text")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Column(name = "release_date")
	public LocalDate getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}
}
