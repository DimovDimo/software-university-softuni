package gamestoreapp.service;

import gamestoreapp.domain.dtos.GameAddDto;
import gamestoreapp.domain.dtos.UserLoginDto;
import gamestoreapp.domain.dtos.UserRegisterDto;
import gamestoreapp.domain.entities.Game;
import gamestoreapp.domain.entities.Role;
import gamestoreapp.domain.entities.User;
import gamestoreapp.repository.GameRepository;
import gamestoreapp.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.List;
import java.util.Set;

@Service
public class UserServiceImpl implements UserService {
	
	private final UserRepository userRepository;
	private final GameRepository gameRepository;
	private final GameService gameService;
	private final Validator validator;
	private final ModelMapper modelMapper;
	
	private String loggedInUserEmail;
	
	@Autowired
	public UserServiceImpl(UserRepository userRepository, GameRepository gameRepository, GameService gameService, Validator validator, ModelMapper modelMapper) {
		this.userRepository = userRepository;
		this.gameRepository = gameRepository;
		this.gameService = gameService;
		this.validator = validator;
		this.modelMapper = modelMapper;
	}
	
	
	@Override
	public String registerUser(UserRegisterDto userRegisterDto) {
		if (!validateDto(userRegisterDto).isEmpty()) {
			return validateDto(userRegisterDto);
		}
		
		if (!userRegisterDto.getPassword().equals(userRegisterDto.getConfirmPassword())) {
			return "Confirm password must match password!";
		}
		
		User userEntity = userRepository.findByEmail(userRegisterDto.getEmail()).orElse(null);
		if (userEntity != null) {
			return "User already exist!";
		}
		
		userEntity = modelMapper.map(userRegisterDto, User.class);
		
		if (userRepository.count() == 0) {
			userEntity.setRole(Role.ADMIN);
		} else {
			userEntity.setRole(Role.USER);
		}
		
		userRepository.saveAndFlush(userEntity);
		
		return String.format("%s was registered", userEntity.getFullName());
	}
	
	@Override
	public String loginUser(UserLoginDto userLoginDto) {
		if (!validateDto(userLoginDto).isEmpty()) {
			return validateDto(userLoginDto);
		}
		
		User userEntity = userRepository.findByEmail(userLoginDto.getEmail()).orElse(null);
		if (userEntity == null) {
			return "User does not exist!";
		} else if (!userLoginDto.getPassword().equals(userEntity.getPassword())) {
			return "Wrong password!";
		}
		
		if (this.loggedInUserEmail != null) {
			if (this.loggedInUserEmail.equals(userEntity.getEmail())) {
				return "User already logged in!";
			} else {
				return "Session is taken!";
			}
		} else {
			this.loggedInUserEmail = userLoginDto.getEmail();
			return "Successfully logged in";
		}
		
		
	}
	
	@Override
	public String logoutUser() {
		
		if (this.loggedInUserEmail == null) {
			return "Cannot log out. No user is currently logged in!";
		} else {
			User userEntity = userRepository.findByEmail(this.loggedInUserEmail).orElse(null);
			this.loggedInUserEmail = null;
			return String.format("User %s successfully logged out!", userEntity.getFullName());
		}
	}
	
	@Override
	public String addGame(GameAddDto gameAddDto) {
		if (this.loggedInUserEmail == null) {
			return "You should be logged in to add game!";
		}
		if (!isAdmin(this.loggedInUserEmail)) {
			return "Only admin users can add games!";
		}
		
		if (!validateDto(gameAddDto).isEmpty()){
			return validateDto(gameAddDto);
		}
		
		Game game = modelMapper.map(gameAddDto,Game.class);
		gameRepository.saveAndFlush(game);
		
		return "Added " + gameAddDto.getTitle();
	}
	
	@Override
	public String editGameIfAdmin(List<String> editGameParams) {
		if (this.loggedInUserEmail == null) {
			return "You should be logged in to edit game!";
		}
		if (!isAdmin(this.loggedInUserEmail)) {
			return "Only admin users can edit games!";
		}
		
		return gameService.editGame(editGameParams);
	}
	
	@Override
	public String deleteGameIfAdmin(int id) {
		if (this.loggedInUserEmail == null) {
			return "You should be logged in to add game!";
		}
		if (!isAdmin(this.loggedInUserEmail)) {
			return "Only admin users can add games!";
		}
		
		return gameService.deleteGame(id);
	}
	
	@Override
	public String listAllGamesIfLoggedIn() {
		if (this.loggedInUserEmail == null) {
			return "You should be logged in to view games!";
		}
		return gameService.ListAllGames();
	}
	
	@Override
	public String listGameDetailsIfLoggedIn(String title) {
		if (this.loggedInUserEmail == null) {
			return "You should be logged in to view games!";
		}
		return gameService.listGameDetails(title);
	}
	
	@Override
	public String listOwnedGamesTitlesIfLoggedIn() {
		if (this.loggedInUserEmail == null) {
			return "You should be logged in to view games!";
		}
		User user = userRepository.findByEmail(this.loggedInUserEmail).orElse(null);
		if (user.getGames().size()==0){
			return String.format("%s has no games.",user.getFullName());
		}
		return gameService.listUserOwnedGames(user);
	}
	
	
	boolean isAdmin(String email) {
		User user = userRepository.findByEmail(email).orElse(null);
		if ((user != null ? user.getRole() : null) == Role.ADMIN) {
			return true;
		} else {
			return false;
		}
		
	}
	
	public <T> String validateDto(T dto) {
		StringBuilder errors = new StringBuilder();
		Set<ConstraintViolation<T>> validationErrors =
				validator.validate(dto);
		
		if (validationErrors.size() > 0) {
			validationErrors
					.forEach(ve -> errors.append(ve.getMessage()).append(System.lineSeparator()));
			return errors.toString();
		}
		
		return errors.toString();
	}
	
}
