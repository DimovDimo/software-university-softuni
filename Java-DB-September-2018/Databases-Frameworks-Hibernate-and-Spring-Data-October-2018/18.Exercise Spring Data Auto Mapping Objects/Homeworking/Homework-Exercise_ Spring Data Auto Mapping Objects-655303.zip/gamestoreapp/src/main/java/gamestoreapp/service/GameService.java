package gamestoreapp.service;

import gamestoreapp.domain.entities.Game;
import gamestoreapp.domain.entities.User;

import java.util.List;

public interface GameService {
	
	String editGame(List<String> params);
	
	
	String deleteGame(int id);
	
	String ListAllGames();
	
	String listGameDetails(String title);
	
	String listUserOwnedGames(User user);
}
