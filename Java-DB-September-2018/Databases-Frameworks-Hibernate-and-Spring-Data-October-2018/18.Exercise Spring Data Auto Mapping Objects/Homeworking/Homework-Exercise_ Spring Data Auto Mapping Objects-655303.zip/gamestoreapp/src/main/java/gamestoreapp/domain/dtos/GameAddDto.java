package gamestoreapp.domain.dtos;

import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

public class GameAddDto {
	
	private String title;
	private BigDecimal price;
	private Double size;
	private String trailer;
	private String thumbnailUrl;
	private String description;
	private LocalDate releaseDate;
	
	public GameAddDto() {
	}
	
	public GameAddDto(String title, BigDecimal price, double size, String trailer, String thumbnailUrl, String description, LocalDate releaseDate) {
		this.title = title;
		this.price = price;
		this.size = size;
		this.trailer = trailer;
		this.thumbnailUrl = thumbnailUrl;
		this.description = description;
		this.releaseDate = releaseDate;
	}
	
	public GameAddDto(String title, BigDecimal price, Double size, String trailer, String thumbnailUrl, String description) {
		this(title, price, size, trailer, thumbnailUrl, description, null);
	}
	
	public GameAddDto(String title, BigDecimal price, Double size, String trailer, String thumbnailUrl) {
		this(title, price, size, trailer, thumbnailUrl, null, null);
	}
	
	public GameAddDto(String title, BigDecimal price, Double size, String trailer) {
		this(title, price, size, trailer, null, null, null);
	}
	
	public GameAddDto(String title, BigDecimal price, Double size) {
		this(title, price, size, null, null, null, null);
	}
	
	@NotNull(message = "Title can not be null!")
	@Size(min = 3, max = 100, message = "Title must have length between 3 and 100 symbols!")
	@Pattern(regexp = "^[A-Z].*$", message = "Title has to begin with an uppercase letter!")
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	@NotNull(message = "Price can not be null!")
	@Min(value = 0, message = "Price must be a positive number!")
	@Digits(integer = 19, fraction = 2, message = "Price must be floating point number with 2 digits precision!")
	public BigDecimal getPrice() {
		return price;
	}
	
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	@NotNull(message = "Size can not be null!")
	@Min(value = 0, message = "Size must be a positive number!")
	@Digits(integer = 19, fraction = 1, message = "Size must be floating point number with 1 digits precision!")
	public Double getSize() {
		return size;
	}
	
	public void setSize(Double size) {
		this.size = size;
	}
	
	@Size(min = 11, max = 11, message = "Trailer must be a string with 11 characters length!")
	public String getTrailer() {
		return trailer;
	}
	
	public void setTrailer(String trailer) {
		this.trailer = trailer;
	}
	
	@Pattern(regexp = "(http(s)?:\\/\\/).{5,}", message = "Invalid URL!")
	public String getThumbnailUrl() {
		return thumbnailUrl;
	}
	
	public void setThumbnailUrl(String thumbnailUrl) {
		this.thumbnailUrl = thumbnailUrl;
	}
	
	@Size(min = 20)
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	public LocalDate getReleaseDate() {
		return releaseDate;
	}
	
	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}
}

