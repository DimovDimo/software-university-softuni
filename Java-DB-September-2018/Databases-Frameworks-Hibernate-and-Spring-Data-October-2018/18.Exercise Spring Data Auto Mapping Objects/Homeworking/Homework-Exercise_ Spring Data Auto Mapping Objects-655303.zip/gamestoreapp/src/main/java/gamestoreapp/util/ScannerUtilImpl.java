package gamestoreapp.util;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Scanner;

@Configuration
public class ScannerUtilImpl implements ScannerUtil {
	
	public static final Scanner scanner = new Scanner(System.in);
	
	@Bean
	@Override
	public Scanner getScanner() {
		
		return scanner;
	}
}
