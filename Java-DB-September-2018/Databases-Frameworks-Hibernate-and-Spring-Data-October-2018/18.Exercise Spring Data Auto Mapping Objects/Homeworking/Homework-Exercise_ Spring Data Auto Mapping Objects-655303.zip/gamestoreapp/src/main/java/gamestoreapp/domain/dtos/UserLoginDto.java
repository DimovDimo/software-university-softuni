package gamestoreapp.domain.dtos;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class UserLoginDto extends BaseUserDto{
	
	private String password;
	
	public UserLoginDto() {
	}
	
	public UserLoginDto(String email,String password) {
		super(email);
		this.password = password;
	}
	
	@NotNull(message = "Password can not be null!")
	@Size(min = 6,message = "Password must be at least 6 characters!")
	@Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{6,}",message = "Password must contain at least 1 uppercase, 1 lowercase letter and 1 digit.")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
