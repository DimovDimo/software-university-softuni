package gamestoreapp.domain.dtos;

import javax.validation.constraints.*;
import java.math.BigDecimal;

public class GameListDto {
	
	private String title;
	private BigDecimal price;
	
	@NotNull(message = "Title can not be null!")
	@Size(min = 3, max = 100, message = "Title must have length between 3 and 100 symbols!")
	@Pattern(regexp = "^[A-Z].*$", message = "Title has to begin with an uppercase letter!")
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	@NotNull(message = "Price can not be null!")
	@Min(value = 0, message = "Price must be a positive number!")
	@Digits(integer = 19, fraction = 2, message = "Price must be floating point number with 2 digits precision!")
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
}
