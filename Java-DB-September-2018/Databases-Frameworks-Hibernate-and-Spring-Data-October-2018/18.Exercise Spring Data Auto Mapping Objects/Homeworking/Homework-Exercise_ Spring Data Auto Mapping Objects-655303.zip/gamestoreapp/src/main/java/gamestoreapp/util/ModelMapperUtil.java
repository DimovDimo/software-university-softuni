package gamestoreapp.util;

import org.modelmapper.ModelMapper;

public interface ModelMapperUtil {
	
	ModelMapper getModelMapper();
}
