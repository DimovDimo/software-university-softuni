package gamestoreapp.util;

import gamestoreapp.domain.dtos.GameDetailsDto;
import gamestoreapp.domain.entities.Game;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ModelMapperUtilImpl implements ModelMapperUtil{
	
	public static final ModelMapper modelMapper = new ModelMapper();
	
	@Bean
	@Override
	public ModelMapper getModelMapper() {
		modelMapper
				.createTypeMap(Game.class, GameDetailsDto.class)
				.addMappings(m->{
					m.map(Game::getReleaseDate,GameDetailsDto::setReleasedDate);
				});
		
		return modelMapper;
	}
}
