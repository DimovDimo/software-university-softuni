package gamestoreapp.domain.dtos;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class BaseUserDto {
	
	private String email;
	
	public BaseUserDto() {
	}
	
	public BaseUserDto(String email) {
		this.email = email;
	}
	
	@NotNull(message = "Email can not be null!")
	@Pattern(regexp = "^\\w+@[a-zA-Z]+_?[a-zA-Z]+\\.[a-zA-Z]{2,6}$",message = "Invalid email!")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
