package gamestoreapp.util;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.validation.Validation;
import javax.validation.Validator;

@Configuration
public class ValidatorUtilImpl implements ValidatorUtil {
	
	public static final Validator validator = Validation
			.byDefaultProvider()
			.configure()
			.buildValidatorFactory()
			.getValidator();
	
	
	@Bean
	@Override
	public Validator getValidator() {
		return validator;
	}

	
}
