package gamestoreapp.service;


import gamestoreapp.domain.dtos.GameAddDto;
import gamestoreapp.domain.dtos.UserLoginDto;
import gamestoreapp.domain.dtos.UserRegisterDto;

import java.util.List;

public interface UserService {

	String registerUser(UserRegisterDto userRegisterDto);
	
	String loginUser(UserLoginDto userLoginDto);
	
	String logoutUser();
	
	String addGame(GameAddDto gameAddDto);
	
	String editGameIfAdmin(List<String> editGameParams);
	
	String deleteGameIfAdmin(int parseInt);
	
	String listAllGamesIfLoggedIn();
	
	String listGameDetailsIfLoggedIn(String title);
	
	String listOwnedGamesTitlesIfLoggedIn();
}
