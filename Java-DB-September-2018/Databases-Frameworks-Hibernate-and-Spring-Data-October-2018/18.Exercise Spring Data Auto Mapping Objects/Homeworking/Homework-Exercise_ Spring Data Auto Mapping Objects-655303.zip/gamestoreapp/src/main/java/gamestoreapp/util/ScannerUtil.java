package gamestoreapp.util;

import java.util.Scanner;

public interface ScannerUtil {

	Scanner getScanner();
}
