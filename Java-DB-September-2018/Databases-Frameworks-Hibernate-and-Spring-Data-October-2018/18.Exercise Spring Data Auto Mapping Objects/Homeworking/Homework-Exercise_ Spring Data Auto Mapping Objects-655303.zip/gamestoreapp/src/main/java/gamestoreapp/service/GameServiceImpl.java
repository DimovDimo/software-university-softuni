package gamestoreapp.service;

import gamestoreapp.domain.dtos.GameDetailsDto;
import gamestoreapp.domain.dtos.GameListDto;
import gamestoreapp.domain.entities.Game;
import gamestoreapp.domain.entities.User;
import gamestoreapp.repository.GameRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class GameServiceImpl implements GameService {
	
	private final GameRepository gameRepository;
	private final Validator validator;
	private final ModelMapper modelMapper;
	
	
	@Autowired
	public GameServiceImpl(GameRepository gameRepository, Validator validator, ModelMapper modelMapper) {
		this.gameRepository = gameRepository;
		this.validator = validator;
		this.modelMapper = modelMapper;
	}
	
	@Override
	public String editGame(List<String> editGameParams) {
		Game gameToEdit;
		Integer id;
		try {
			id = Integer.parseInt(editGameParams.get(0));
			gameToEdit = gameRepository.findById(id).orElse(null);
		} catch (NumberFormatException e) {
			return "Invalid id input";
		}
		if (gameToEdit == null) {
			return String.format("No game with %d id exist", id);
		}
		
		editGameParams.forEach(p -> updateGameProperty(p, gameToEdit));
		if (!validateDto(gameToEdit).isEmpty()) {
			return validateDto(gameToEdit);
		}
		
		gameRepository.saveAndFlush(gameToEdit);
		
		return String.format("Edited %s", gameToEdit.getTitle());
	}
	
	@Override
	public String deleteGame(int id) {
		Game gameToDelete = gameRepository.findById(id).orElse(null);
		if (gameToDelete == null) {
			return String.format("No game with %d id exist", id);
		}
		gameRepository.delete(gameToDelete);
		return String.format("Deleted %s", gameToDelete.getTitle());
	}
	
	@Override
	public String ListAllGames() {
		return gameRepository
				.findAll()
				.stream()
				.map(g -> {
					GameListDto gameListDto = modelMapper.map(g, GameListDto.class);
					return String.format("%s %.2f", gameListDto.getTitle(), gameListDto.getPrice());
				})
				.collect(Collectors.joining(System.lineSeparator()));
	}
	
	@Override
	public String listGameDetails(String title) {
		Game game = gameRepository.findFirstByTitle(title);
		if (game == null) {
			return "There is no such game title!";
		}
		GameDetailsDto gd = modelMapper.map(game, GameDetailsDto.class);
		LocalDate releaseDate = gd.getReleasedDate();
		String date;
		if (releaseDate == null) {
			date = "no release date available";
		} else {
			date = releaseDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		}
		
		return String.format("Title: %s\n" +
						"Price: %.2f \n" +
						"Description: %s\n" +
						"Release date: %s", gd.getTitle(), gd.getPrice().doubleValue(),
				gd.getDescription(), date);
	}
	
	@Override
	public String listUserOwnedGames(User user) {
		return user
				.getGames()
				.stream()
				.map(g->g.getTitle())
				.collect(Collectors.joining(System.lineSeparator()));
	}
	
	private void updateGameProperty(String p, Game gameToEdit) {
		String[] tokens = p.split("=");
		switch (tokens[0].trim().toLowerCase()) {
			case "title":
				gameToEdit.setTitle(tokens[1]);
				break;
			case "price":
				gameToEdit.setPrice(new BigDecimal(tokens[1]));
				break;
			case "size":
				gameToEdit.setSize(Double.parseDouble(tokens[1]));
				break;
			case "trailer":
				gameToEdit.setTrailer(tokens[1]);
				break;
			case "thumbnailurl":
				gameToEdit.setThumbnailUrl(tokens[1]);
				break;
			case "description":
				gameToEdit.setDescription(tokens[1]);
				break;
			case "releasedate":
				gameToEdit.setReleaseDate(LocalDate.parse(tokens[1], DateTimeFormatter.ofPattern("dd-MM-yyyy")));
				break;
		}
		
		
	}
	
	public <T> String validateDto(T dto) {
		StringBuilder errors = new StringBuilder();
		Set<ConstraintViolation<T>> validationErrors =
				validator.validate(dto);
		
		if (validationErrors.size() > 0) {
			validationErrors
					.forEach(ve -> errors.append(ve.getMessage()).append(System.lineSeparator()));
			return errors.toString();
		}
		
		return errors.toString();
	}
}
