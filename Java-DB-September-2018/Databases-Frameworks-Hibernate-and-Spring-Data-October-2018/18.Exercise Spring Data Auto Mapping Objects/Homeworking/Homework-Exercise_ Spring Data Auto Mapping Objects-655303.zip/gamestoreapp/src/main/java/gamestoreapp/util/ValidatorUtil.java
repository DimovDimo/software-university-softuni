package gamestoreapp.util;

import javax.validation.Validator;

public interface ValidatorUtil {
	
	Validator getValidator();
	
	
}
