package gamestoreapp.web.controllers;

import gamestoreapp.domain.dtos.GameAddDto;
import gamestoreapp.domain.dtos.UserLoginDto;
import gamestoreapp.domain.dtos.UserRegisterDto;
import gamestoreapp.service.GameService;
import gamestoreapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@SpringBootApplication
public class GameStoreConsoleRunner implements CommandLineRunner {
	
	private final UserService userService;
	private final GameService gameService;
	private final Scanner scanner;
	
	@Autowired
	public GameStoreConsoleRunner(UserService userService, GameService gameService, Scanner scanner) {
		this.userService = userService;
		this.gameService = gameService;
		this.scanner = scanner;
	}
	
	
	@Override
	public void run(String... args) throws Exception {
		String input = "";
		
		while (true) {
			System.out.println("Enter command or 'q' to quit: \n" +
					"RegisterUser|<email>|<password>|<confirmPassword>|<fullName>\n" +
					"LoginUser|<email>|<password>\n" +
					"Logout\n" +
					"AddGame|<title>|<price>|<size>|<trailer>|<thubnailURL>|<description>|<releaseDate>\n" +
					"EditGame|<id>|<values>\n" +
					"DeleteGame|<id>\n" +
					"AllGame\n" +
					"DetailGame|<gameTitle>\n" +
					"OwnedGames"
			);
			input = scanner.nextLine();
			if (input.toLowerCase().equals("q")) {
				System.exit(0);
			}
			String[] params = input.split("\\|");
			
			runCommand(params);
		}
		
	}
	
	private void runCommand(String[] params) {
		String result = "";
		
		switch (params[0].toLowerCase()) {
			case "registeruser":
				if (params.length!=5){
					System.out.println("Expecting command parameter number don't match!");
					return;
				}
				UserRegisterDto userRegisterDto = new UserRegisterDto(params[1],params[2],params[3],params[4]);
				result = userService.registerUser(userRegisterDto);
				System.out.println(result);
				break;
				
			case "loginuser":
				if (params.length!=3){
					System.out.println("Expecting command parameter number don't match!");
					return;
				}
				UserLoginDto userLoginDto = new UserLoginDto(params[1],params[2]);
				result = userService.loginUser(userLoginDto);
				System.out.println(result);
				break;
				
			case "logout":
				System.out.println(userService.logoutUser());
				break;
			case "addgame":
				GameAddDto gameAddDto = createGameAddDto(params);
				result = userService.addGame(gameAddDto);
				System.out.println(result);
				break;
				
			case "editgame":
				List<String> editGameParams = new ArrayList<>();
				for (int i = 1; i < params.length; i++) {
					editGameParams.add(params[i]);
				}
				result = userService.editGameIfAdmin(editGameParams);
				System.out.println(result);
				break;
				
			case "deletegame":
				if (params.length!=2){
					System.out.println("Expecting command parameter number don't match!");
					return;
				}
				result = userService.deleteGameIfAdmin(Integer.parseInt(params[1]));
				System.out.println(result);
				break;
			case "allgame":
				if (params.length!=1){
					System.out.println("Expecting command parameter number don't match!");
					return;
				}
				result = userService.listAllGamesIfLoggedIn();
				System.out.println(result);
				break;
			case "detailgame":
				if (params.length!=2){
					System.out.println("Expecting command parameter number don't match!");
					return;
				}
				result = userService.listGameDetailsIfLoggedIn(params[1]);
				System.out.println(result);
				break;
				
			case "ownedgames":
			case "ownedgame":
				if (params.length!=1){
					System.out.println("Expecting command parameter number don't match!");
					return;
				}
				result=userService.listOwnedGamesTitlesIfLoggedIn();
				System.out.println(result);
				break;
				
			default:
				System.out.println("Invalid Command!");
				break;
			
		}
		
		
	}
	
	private GameAddDto createGameAddDto(String[] params) {
		String title;
		BigDecimal price;
		Double size;
		String trailer;
		String thumbnailUrl;
		String description;
		LocalDate releaseDate;
		if (params.length<3 || params.length>8){
			System.out.println("Expecting command parameter number don't match!");
			return null;
		}
		title = params[1];
		price= new BigDecimal(params[2]);
		size = Double.parseDouble(params[3]);
		try {
			trailer = params[4];
		} catch (Exception e) {
			trailer = null;
		}
		try {
			thumbnailUrl = params[5];
		} catch (Exception e) {
			thumbnailUrl = null;
		}
		try {
			description = params[6];
		} catch (Exception e) {
			description = null;
		}
		try {
			releaseDate = LocalDate.parse(params[7], DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		} catch (Exception e) {
			releaseDate = null;
		}
		
		return new GameAddDto(title,price, size, trailer, thumbnailUrl, description, releaseDate);
		
	}
	
	
}
