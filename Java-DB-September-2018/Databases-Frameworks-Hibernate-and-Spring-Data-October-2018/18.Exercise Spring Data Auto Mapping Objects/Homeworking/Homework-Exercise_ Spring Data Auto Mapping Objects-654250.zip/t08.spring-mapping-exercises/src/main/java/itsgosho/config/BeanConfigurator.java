package itsgosho.config;

import itsgosho.services.UserServicesImp;
import itsgosho.tools.CommandReader;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfigurator {

    private static ModelMapper modelMapper;

    static {
        modelMapper = new ModelMapper();

        modelMapper.validate();
    }

    @Bean
    public static ModelMapper getModelMapper() {
        return modelMapper;
    }
}
