package itsgosho.services;

import itsgosho.domain.dtos.GameCreateDto;
import itsgosho.domain.entities.Game;
import itsgosho.repositories.GameRepository;
import itsgosho.repositories.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;

@Service
public class GameServicesImp implements GameServices {
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final GameRepository gameRepository;

    @Autowired
    public GameServicesImp(UserRepository userRepository, ModelMapper modelMapper, GameRepository gameRepository) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.gameRepository = gameRepository;
    }

    @Override
    public void save(GameCreateDto gameCreateDto) {
        Game game = this.modelMapper.map(gameCreateDto, Game.class);
        this.gameRepository.save(game);
    }

    @Override
    public void add(String title, BigDecimal price, long size, String trail, String thumbnailURL, String description, Date realeseDate) {
        GameCreateDto gameCreateDto = new GameCreateDto(
                title,price,size,trail,thumbnailURL,description);
        this.save(gameCreateDto);
    }

    @Override
    public void edit(long id, String... values) {

    }

}
