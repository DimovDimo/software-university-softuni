package itsgosho.services;

import itsgosho.domain.dtos.GameCreateDto;

import java.math.BigDecimal;
import java.util.Date;

public interface GameServices {

    void save(GameCreateDto gameCreateDto);
    void add(String title, BigDecimal price, long size, String trail,
             String thumbnailURL, String description, Date realeseDate);
    void edit(long id,String... values);
}
