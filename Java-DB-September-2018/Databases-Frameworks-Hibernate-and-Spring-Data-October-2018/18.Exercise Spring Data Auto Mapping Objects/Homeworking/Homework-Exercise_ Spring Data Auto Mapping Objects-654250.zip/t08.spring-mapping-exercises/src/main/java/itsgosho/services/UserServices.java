package itsgosho.services;

import itsgosho.domain.dtos.UserCreateDto;
import org.springframework.stereotype.Service;

public interface UserServices {

    void save(UserCreateDto userCreateDto);
    boolean create(String email,String password,String confirmPassword,String fullName);
    boolean login(String email,String password);
    boolean logout();

}
