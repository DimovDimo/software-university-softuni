package itsgosho.tools;

import itsgosho.domain.entities.User;

public class FloatDB {

    private static User loggedUser;

    public static User getLoggedUser() {
        return loggedUser;
    }

    public static void setLoggedUser(User loggedUser) {
        FloatDB.loggedUser = loggedUser;
    }
}
