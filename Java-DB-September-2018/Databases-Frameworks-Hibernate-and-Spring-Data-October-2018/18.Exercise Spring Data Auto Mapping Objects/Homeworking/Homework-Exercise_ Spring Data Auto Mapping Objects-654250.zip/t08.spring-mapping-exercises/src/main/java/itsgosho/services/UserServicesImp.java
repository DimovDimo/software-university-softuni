package itsgosho.services;

import itsgosho.domain.dtos.UserCreateDto;
import itsgosho.domain.entities.User;
import itsgosho.repositories.GameRepository;
import itsgosho.repositories.UserRepository;
import itsgosho.tools.FloatDB;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServicesImp implements UserServices {

    private final GameRepository gameRepository;
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public UserServicesImp(GameRepository gameRepository, UserRepository userRepository, ModelMapper modelMapper) {
        this.gameRepository = gameRepository;
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public void save(UserCreateDto userCreateDto) {
         User user = this.modelMapper.map(userCreateDto,User.class);
         this.userRepository.save(user);
    }

    @Override
    public boolean create(String email, String password,String confirmPassword, String fullName) {
        if(!password.equals(confirmPassword)){
            throw new IllegalArgumentException("The user passwords doesn't match!");
        }
        UserCreateDto userCreateDto = new UserCreateDto(email,password,fullName);
        this.save(userCreateDto);
        return true;
    }

    @Override
    public boolean login(String email, String password) {
        User user = this.userRepository.findUserByEmail(email);
        if(user == null){
            throw new IllegalArgumentException("Did not found a user with the provided email!");
        }
        if(!user.getPassword().equals(password)){
            throw new IllegalArgumentException("The provided password doesn't match!");
        }
        if(FloatDB.getLoggedUser()!=null){
            throw new IllegalArgumentException("There is already logged in user!");
        }
        FloatDB.setLoggedUser(user);
        return true;
    }

    @Override
    public boolean logout() {
        if(FloatDB.getLoggedUser()!=null){
            throw new IllegalArgumentException("There isn't a logged in user!");
        }
        FloatDB.setLoggedUser(null);
        return false;
    }
}
