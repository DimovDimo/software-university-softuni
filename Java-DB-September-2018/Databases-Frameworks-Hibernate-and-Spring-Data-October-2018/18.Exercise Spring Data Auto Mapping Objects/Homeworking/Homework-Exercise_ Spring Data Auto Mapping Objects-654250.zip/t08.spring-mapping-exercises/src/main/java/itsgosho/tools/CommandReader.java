package itsgosho.tools;

import itsgosho.repositories.GameRepository;
import itsgosho.services.GameServicesImp;
import itsgosho.services.UserServicesImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Scanner;

@Component
public class CommandReader {

    private final UserServicesImp userServicesImp;
    private final GameServicesImp gameServicesImp;

    @Autowired
    public CommandReader(UserServicesImp userServicesImp,GameServicesImp gameServicesImp) {
        this.userServicesImp = userServicesImp;
        this.gameServicesImp = gameServicesImp;
    }

    public void run(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Waiting for command: /To exit type \"exit\"");
        while (true){
            String line = scanner.nextLine().trim();
            if(line.toLowerCase().equals("exit")){
                System.out.println("Exited from the command reader!");
                break;
            }
            String[] lineArr = line.split("\\s+");
            switch (lineArr[0].toLowerCase()){
                case "registeruser":
                    this.userServicesImp.create(lineArr[1],lineArr[2],lineArr[3],lineArr[4]);
                    break;
                case "loginuser":
                    this.userServicesImp.login(lineArr[1],lineArr[2]);
                    break;
                case "logout":
                    this.userServicesImp.logout();
                    break;


                case "addgame":
                    this.gameServicesImp.add(lineArr[1],
                            new BigDecimal(String.valueOf(lineArr[2])),
                            Long.parseLong(lineArr[3]),
                            lineArr[4],
                            lineArr[5],
                            lineArr[6],
                            null);
                    break;
                case "editgame":
                    this.gameServicesImp.edit(0,null);
                    break;
            }
        }
    }
}
