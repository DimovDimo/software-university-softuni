package itsgosho;

import itsgosho.services.GameServicesImp;
import itsgosho.services.UserServicesImp;
import itsgosho.tools.CommandReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CLR implements CommandLineRunner {

    private final UserServicesImp userServicesImp;
    private final GameServicesImp gameServicesImp;

    @Autowired
    public CLR(UserServicesImp userServicesImp, GameServicesImp gameServicesImp) {
        this.userServicesImp = userServicesImp;
        this.gameServicesImp = gameServicesImp;
    }

    @Override
    public void run(String... args) throws Exception {

//        CommandReader commandReader = new CommandReader(this.userServicesImp,this.gameServicesImp);
//        commandReader.run();


    }
}
