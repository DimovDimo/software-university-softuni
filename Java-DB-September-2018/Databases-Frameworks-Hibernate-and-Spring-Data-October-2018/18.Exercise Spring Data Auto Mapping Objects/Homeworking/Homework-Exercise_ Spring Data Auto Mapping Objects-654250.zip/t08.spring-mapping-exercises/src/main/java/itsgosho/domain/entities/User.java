package itsgosho.domain.entities;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(unique = true)
    private String email;
    private String password;
    @Column(name = "full_name")
    private String fullName;
    @ManyToMany
    @JoinTable(name = "user_games",
            joinColumns = @JoinColumn(name = "user_id",referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "game_id",referencedColumnName = "id"))
    private Set<Game> games;
    @Column(name = "is_administrator")
    private boolean isAdministrator;

    public User() {
        this.setGames(new HashSet<>());
        this.setAdministrator(false);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        Matcher matcher = Pattern.compile("^([A-Za-z0-9]+(@)([A-Za-z]+)(\\.)([A-Za-z]+))$")
                .matcher(email);
        if(matcher.find()){
            this.email = email;
        }else{
            throw new IllegalArgumentException("Email is invalid!");
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        Matcher mUpper = Pattern.compile("([A-Z]{1,})")
                .matcher(password);
        Matcher mLower = Pattern.compile("([a-z]{1,})")
                .matcher(password);
        Matcher mDigit = Pattern.compile("([0-9]{1,})")
                .matcher(password);
        if(mUpper.find() && mLower.find() && mDigit.find() && password.length()>=6){
            this.password = password;
        }else{
            throw new IllegalArgumentException("Password is invalid!");
        }
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Set<Game> getGames() {
        return games;
    }

    public void setGames(Set<Game> games) {
        this.games = games;
    }

    public boolean isAdministrator() {
        return isAdministrator;
    }

    public void setAdministrator(boolean administrator) {
        isAdministrator = administrator;
    }
}
