package app.ccb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CcbApplication {

    public static void main(String[] args) {
        SpringApplication.run(CcbApplication.class, args);
    }
}
