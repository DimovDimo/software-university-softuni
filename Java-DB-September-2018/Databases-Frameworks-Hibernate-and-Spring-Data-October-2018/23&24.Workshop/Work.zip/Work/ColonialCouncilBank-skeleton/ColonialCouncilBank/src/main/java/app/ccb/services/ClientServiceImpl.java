package app.ccb.services;

import app.ccb.domain.dtos.ClientImportDto;
import app.ccb.domain.entities.Client;
import app.ccb.domain.entities.Employee;
import app.ccb.repositories.ClientRepository;
import app.ccb.repositories.EmployeeRepository;
import app.ccb.util.FileUtil;
import app.ccb.util.ValidationUtil;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class ClientServiceImpl implements ClientService {

    private final static String CLIENTS_JSON_FILE_PATH = System.getProperty("user.dir") + "/src/main/resources/files/json/clients.json";

    private final ClientRepository clientRepository;
    private final EmployeeRepository employeeRepository;
    private final FileUtil fileUtil;
    private final Gson gson;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public ClientServiceImpl(ClientRepository clientRepository, EmployeeRepository employeeRepository, FileUtil fileUtil, Gson gson, ValidationUtil validationUtil, ModelMapper modelMapper) {
        this.clientRepository = clientRepository;
        this.employeeRepository = employeeRepository;
        this.fileUtil = fileUtil;
        this.gson = gson;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public Boolean clientsAreImported() {
        return this.clientRepository.count() != 0;
    }

    @Override
    public String readClientsJsonFile() throws IOException {
        return this.fileUtil.readFile(CLIENTS_JSON_FILE_PATH);
    }

    @Override
    public String importClients(String clients) {
        StringBuilder importResult = new StringBuilder();

        Arrays.stream(this.gson.fromJson(clients, ClientImportDto[].class)).forEach(clientImportDto -> {
            String[] employeeNames = clientImportDto.getAppointedEmployee().split("\\s+");

            Employee employeeEntity = this.employeeRepository.findByFirstNameAndLastName(employeeNames[0], employeeNames[1]).orElse(null);
            if (!this.validationUtil.isValid(clientImportDto) || employeeEntity == null) {
                importResult.append("Error: Incorrect Data!").append(System.lineSeparator());

                return;
            }

            Client clientEntity = this.clientRepository
                    .findByFullName(String.format("%s %s", clientImportDto.getFirstName(), clientImportDto.getLastName()))
                    .orElse(null);

            if (clientEntity != null) {
                importResult.append("Error: Incorrect Data!").append(System.lineSeparator());

                return;
            }

            String clientFullName = String.format("%s %s",
                    clientImportDto.getFirstName(),
                    clientImportDto.getLastName());

            clientEntity = this.modelMapper.map(clientImportDto, Client.class);
            clientEntity.setFullName(clientFullName);
            List<Employee> employees = new ArrayList<>();
            employees.add(employeeEntity);
            clientEntity.setEmployees(employees);
            this.clientRepository.saveAndFlush(clientEntity);

            importResult
                    .append(String
                            .format("Successfully imported %s – %s.", clientEntity.getClass().getSimpleName(), clientEntity.getFullName()))
                    .append(System.lineSeparator());
        });

        return importResult.toString().trim();
    }

    @Override
    public String exportFamilyGuy() {
        StringBuilder exportResult = new StringBuilder();
        Client client = this.clientRepository.extractFamilyGuy().get(0);

        exportResult.append(String.format("Full Name: %s", client.getFullName())).append(System.lineSeparator());
        exportResult.append(String.format("Age: %d", client.getAge())).append(System.lineSeparator());
        exportResult.append(String.format("Bank Account: %s", client.getBankAccount().getAccountNumber())).append(System.lineSeparator());
        client.getBankAccount().getCards().forEach(card -> {
            exportResult.append(String.format("   Card Number: %s", card.getCardNumber())).append(System.lineSeparator());
            exportResult.append(String.format("   Card Status: %s", card.getCardStatus())).append(System.lineSeparator());
        });

        return exportResult.toString().trim();
    }
}
