package app.ccb.domain.dtos;

import app.ccb.domain.entities.base.BaseEntity;
import com.google.gson.annotations.Expose;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.validation.constraints.NotNull;

public class BranchImportDto{

    @Expose
    private String name;

    public BranchImportDto() {
    }

    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
