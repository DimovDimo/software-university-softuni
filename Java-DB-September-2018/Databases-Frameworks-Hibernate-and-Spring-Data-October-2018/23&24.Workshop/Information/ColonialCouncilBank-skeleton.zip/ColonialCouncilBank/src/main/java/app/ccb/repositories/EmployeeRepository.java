package app.ccb.repositories;

public interface EmployeeRepository {
    // TODO : Implement EmployeeRepository
}
