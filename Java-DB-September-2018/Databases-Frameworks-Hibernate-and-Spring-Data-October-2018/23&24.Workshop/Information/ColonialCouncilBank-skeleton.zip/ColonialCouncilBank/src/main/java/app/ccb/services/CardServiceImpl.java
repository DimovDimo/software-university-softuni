package app.ccb.services;

public class CardServiceImpl implements CardService {

    @Override
    public Boolean cardsAreImported() {
        // TODO : Implement Me
//        return this.cardRepository.count() != 0;
        return null;
    }

    @Override
    public String readCardsXmlFile() {
        // TODO : Implement Me
        return null;
    }

    @Override
    public String importCards() {
        // TODO : Implement Me
        return null;
    }
}
