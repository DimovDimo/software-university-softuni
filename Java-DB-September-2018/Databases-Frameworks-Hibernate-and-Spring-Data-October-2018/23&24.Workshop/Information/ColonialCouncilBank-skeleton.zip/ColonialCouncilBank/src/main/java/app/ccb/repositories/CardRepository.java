package app.ccb.repositories;

public interface CardRepository {
    // TODO : Implement CardRepository
}
