package app.ccb.repositories;

public interface ClientRepository {
    // TODO : Implement ClientRepository
}
