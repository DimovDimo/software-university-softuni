package app.ccb.services;

public class EmployeeServiceImpl implements EmployeeService {

    @Override
    public Boolean employeesAreImported() {
        // TODO : Implement Me
//        return this.employeeRepository.count() != 0;
        return null;
    }

    @Override
    public String readEmployeesJsonFile() {
        // TODO : Implement Me
        return null;
    }

    @Override
    public String importEmployees(String employees) {
        // TODO : Implement Me
        return null;
    }

    @Override
    public String exportTopEmployees() {
        // TODO : Implement Me
        return null;
    }
}
