package app.ccb.repositories;

public interface BranchRepository {
    // TODO : Implement BranchRepository
}
