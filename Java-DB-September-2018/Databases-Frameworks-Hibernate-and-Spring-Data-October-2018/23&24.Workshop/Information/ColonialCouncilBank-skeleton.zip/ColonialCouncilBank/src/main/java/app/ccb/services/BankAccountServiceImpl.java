package app.ccb.services;

public class BankAccountServiceImpl implements BankAccountService {

    @Override
    public Boolean bankAccountsAreImported() {
        // TODO : Implement Me
//        return this.bankAccountRepository.count() != 0;
        return null;
    }

    @Override
    public String readBankAccountsXmlFile() {
        // TODO : Implement Me
        return null;
    }

    @Override
    public String importBankAccounts() {
        // TODO : Implement Me
        return null;
    }
}
