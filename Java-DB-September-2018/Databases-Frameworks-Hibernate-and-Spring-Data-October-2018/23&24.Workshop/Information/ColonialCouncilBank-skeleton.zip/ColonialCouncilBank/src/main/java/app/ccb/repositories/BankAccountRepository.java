package app.ccb.repositories;

public interface BankAccountRepository {
    // TODO : Implement BankAccountRepository
}
