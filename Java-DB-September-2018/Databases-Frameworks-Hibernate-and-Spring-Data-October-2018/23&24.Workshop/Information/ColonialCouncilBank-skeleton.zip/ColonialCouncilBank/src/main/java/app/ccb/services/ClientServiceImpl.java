package app.ccb.services;

public class ClientServiceImpl implements ClientService {

    @Override
    public Boolean clientsAreImported() {
        // TODO : Implement Me
//        return this.clientRepository.count() != 0;
        return null;
    }

    @Override
    public String readClientsJsonFile() {
        // TODO : Implement Me
        return null;
    }

    @Override
    public String importClients(String clients) {
        // TODO : Implement Me
        return null;
    }

    @Override
    public String exportFamilyGuy() {
        // TODO : Implement Me
        return null;
    }
}
