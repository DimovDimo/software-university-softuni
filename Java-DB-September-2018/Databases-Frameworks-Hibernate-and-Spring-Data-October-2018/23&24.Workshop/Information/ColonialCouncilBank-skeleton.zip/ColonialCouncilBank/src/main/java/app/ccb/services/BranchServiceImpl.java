package app.ccb.services;

public class BranchServiceImpl implements BranchService {

    @Override
    public Boolean branchesAreImported() {
        // TODO : Implement Me
//        return this.branchRepository.count() != 0;
        return null;
    }

    @Override
    public String readBranchesJsonFile() {
        // TODO : Implement Me
        return null;
    }

    @Override
    public String importBranches(String branchesJson) {
        // TODO : Implement Me
        return null;
    }
}
