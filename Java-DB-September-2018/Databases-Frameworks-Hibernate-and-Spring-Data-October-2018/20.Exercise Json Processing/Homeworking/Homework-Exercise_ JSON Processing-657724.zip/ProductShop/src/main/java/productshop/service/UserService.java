package productshop.service;

import productshop.domain.dtos.UserSoldProductsDto;
import productshop.domain.dtos.seedsdto.UserSeedDto;
import productshop.domain.entities.User;

import java.util.List;

public interface UserService {

    void seedUsers(UserSeedDto[] seed);
    User getById(Integer id);
    List<UserSoldProductsDto> getUserSoldProducts();
}
