package productshop.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import productshop.domain.dtos.ProductInRangeDto;
import productshop.domain.dtos.SoldProductsDto;
import productshop.domain.dtos.seedsdto.ProductSeedDto;
import productshop.domain.entities.Category;
import productshop.domain.entities.Product;
import productshop.domain.entities.User;
import productshop.repository.CategoryRepository;
import productshop.repository.ProductRepository;
import productshop.repository.UserRepository;
import productshop.util.ValidatorUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service
public class ProductServiceImpl implements ProductService {
    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final UserRepository userRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public ProductServiceImpl(ProductRepository productRepository, CategoryRepository categoryRepository, UserRepository userRepository, ValidatorUtil validatorUtil, ModelMapper modelMapper) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
        this.userRepository = userRepository;
        this.validatorUtil = validatorUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<SoldProductsDto> soldProductsBySeller(Integer id) {
        List<Product> products = this.productRepository.findAllBySellerIdAndBayerIsNotNull(id);
        List<SoldProductsDto> soldProductDtos = new ArrayList<>();

        for (Product pr : products) {
            SoldProductsDto soldProduct = this.modelMapper.map(pr,SoldProductsDto.class);
            soldProduct.setBuyerFirstName(pr.getBayer().getFirstName());
            soldProduct.setBuyerLastName(pr.getBayer().getLastName());
            soldProductDtos.add(soldProduct);
        }
        return soldProductDtos;
    }

    @Override
    public List<ProductInRangeDto> productsInRange(BigDecimal more, BigDecimal less) {

        List<Product> productEntities = this.productRepository.findAllByPriceBetweenAndBayerOrderByPrice(more,less,null);
        List<ProductInRangeDto> prInRangeDtos = new ArrayList<>();

        for (Product productEntity : productEntities) {

            ProductInRangeDto prInRange = this.modelMapper.map(productEntity,ProductInRangeDto.class);
            prInRange.setSeller(String.format("%s %s",productEntity.getSeller().getFirstName(),productEntity.getSeller().getLastName()));
            prInRangeDtos.add(prInRange);
        }

        return prInRangeDtos;
    }

    @Override
    public void seedProducts(ProductSeedDto[] seed) {

        for (ProductSeedDto productSeedDto : seed) {

            if(!validatorUtil.isValid(productSeedDto)){
                validatorUtil.violations(productSeedDto)
                        .forEach(v-> System.out.println(v.getMessage()));
                continue;
            }

            Product product = this.modelMapper.map(productSeedDto, Product.class);
             product.setSeller(this.getRandomUser());

             Random  random = new Random();

             if(random.nextInt()%13 !=0){
                 product.setBayer(this.getRandomUser());
             }

             product.setCategories(this.getRandomCategories());

            this.productRepository.saveAndFlush(product);
        }
    }

    private User getRandomUser(){
        Random random = new Random();

        return this.userRepository.getOne(random.nextInt((int) this.userRepository.count()-1)+1);
    }
    
    private List<Category> getRandomCategories(){
        Random random = new Random();
        List<Category> categories = new ArrayList<>();
        int categoriesCount = random.nextInt((int) this.categoryRepository.count()-1)+1;
        for (int i = 0; i < categoriesCount; i++) {

            categories.add(this.categoryRepository.getOne(random.nextInt((int) this.categoryRepository.count()-1)+1));
        }

        return categories;
    }
}
