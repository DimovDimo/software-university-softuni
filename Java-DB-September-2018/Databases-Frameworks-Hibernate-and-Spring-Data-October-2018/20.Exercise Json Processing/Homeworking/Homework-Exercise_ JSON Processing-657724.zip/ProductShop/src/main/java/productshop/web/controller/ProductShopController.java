package productshop.web.controller;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;
import productshop.domain.dtos.CategoriesByProductDto;
import productshop.domain.dtos.ProductInRangeDto;
import productshop.domain.dtos.SoldProductsDto;
import productshop.domain.dtos.UserSoldProductsDto;
import productshop.domain.dtos.seedsdto.CategorySeedDto;
import productshop.domain.dtos.seedsdto.ProductSeedDto;
import productshop.domain.dtos.seedsdto.UserSeedDto;
import productshop.service.CategoryService;
import productshop.service.ProductService;
import productshop.service.UserService;
import productshop.util.FileIOUtil;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class ProductShopController implements CommandLineRunner {
    private final String USERS_FILE_PATH = "E:\\JAVA PROJECTS\\JavaDB Frameworks\\9_JSONProcessing\\ProductShop\\src\\main\\resources\\files\\users.json";
    private final String CATEGORY_FILE_PATH = "E:\\JAVA PROJECTS\\JavaDB Frameworks\\9_JSONProcessing\\ProductShop\\src\\main\\resources\\files\\categories.json";
    private final String PRODUCT_FILE_PATH = "E:\\JAVA PROJECTS\\JavaDB Frameworks\\9_JSONProcessing\\ProductShop\\src\\main\\resources\\files\\products.json";
    private final String PRODUCTS_IN_RANGE_PATH = "E:\\JAVA PROJECTS\\JavaDB Frameworks\\9_JSONProcessing\\ProductShop\\src\\main\\resources\\files\\output\\products-in-range.json";
    private final String USERS_SOLD_PRODUCTS_PATH = "E:\\JAVA PROJECTS\\JavaDB Frameworks\\9_JSONProcessing\\ProductShop\\src\\main\\resources\\files\\output\\users-sold-products.json";
    private final String CATEGORIES_BY_PRODUCT_PATH = "E:\\JAVA PROJECTS\\JavaDB Frameworks\\9_JSONProcessing\\ProductShop\\src\\main\\resources\\files\\output\\categories-by-products.json";
    private final String USERS_AND_PRODUCTS_PATH = "E:\\JAVA PROJECTS\\JavaDB Frameworks\\9_JSONProcessing\\ProductShop\\src\\main\\resources\\files\\output\\users-and-products.json";

    private final UserService userService;
    private final CategoryService categoryService;
    private final ProductService productService;
    private final FileIOUtil fileIOUtil;
    private final Gson gson;

    @Autowired
    public ProductShopController(UserService userService, CategoryService categoryService, ProductService productService, FileIOUtil fileIOUtil, Gson gson) {
        this.userService = userService;
        this.categoryService = categoryService;
        this.productService = productService;
        this.fileIOUtil = fileIOUtil;
        this.gson = gson;
    }

    @Override
    public void run(String... args) throws Exception {
//        this.seedUsers();
//        this.seedCategories();
//        this.seedProducts();
        //   productsInRange();
        //    usersSoldProducts();
        allCategoriesByProduct();
    }

    private void allCategoriesByProduct() throws IOException {
        List<CategoriesByProductDto> catDto = this.categoryService.allCategoriesByProduct();
        String productsInRangeJson = this.gson.toJson(catDto);

        // System.out.println(productsInRangeJson);
        this.fileIOUtil.writeToFile(productsInRangeJson, CATEGORIES_BY_PRODUCT_PATH);
    }

    private void usersSoldProducts() throws IOException {

        List<UserSoldProductsDto> userSoldProducts = this.userService.getUserSoldProducts();

        for (UserSoldProductsDto dto : userSoldProducts) {
            List<SoldProductsDto> soldProductsDtos = this.productService.soldProductsBySeller(dto.getId());
            dto.setSoldProductDtos(soldProductsDtos);
        }

        List<UserSoldProductsDto> filteredDto = userSoldProducts
                .stream()
                .filter(d -> d.getSoldProductDtos().size() > 0)
                .collect(Collectors.toList());
        String soldProductsJson = this.gson.toJson(filteredDto);
        // System.out.println(soldProductsJson);
        this.fileIOUtil.writeToFile(soldProductsJson, USERS_SOLD_PRODUCTS_PATH);

    }

    private void productsInRange() throws IOException {
        List<ProductInRangeDto> productInRangeDtos = this.productService.productsInRange(BigDecimal.valueOf(500), BigDecimal.valueOf(1000));
        String productsInRangeJson = this.gson.toJson(productInRangeDtos);

        //System.out.println(productsInRangeJson);
        this.fileIOUtil.writeToFile(productsInRangeJson, PRODUCTS_IN_RANGE_PATH);

    }

    private void seedUsers() throws IOException {
        String userFileContent = this.fileIOUtil.readFile(USERS_FILE_PATH);
        UserSeedDto[] userSeedDtos = this.gson.fromJson(userFileContent, UserSeedDto[].class);
        this.userService.seedUsers(userSeedDtos);
    }


    private void seedCategories() throws IOException {

        String categoryFileContent = this.fileIOUtil.readFile(CATEGORY_FILE_PATH);
        CategorySeedDto[] categorySeedDtos = this.gson.fromJson(categoryFileContent, CategorySeedDto[].class);
        this.categoryService.seedCategories(categorySeedDtos);

    }


    private void seedProducts() throws IOException {
        String productFileContent = this.fileIOUtil.readFile(PRODUCT_FILE_PATH);
        ProductSeedDto[] productSeedDtos = this.gson.fromJson(productFileContent, ProductSeedDto[].class);
        this.productService.seedProducts(productSeedDtos);
    }

}
