package productshop.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import productshop.domain.dtos.CategoriesByProductDto;
import productshop.domain.dtos.seedsdto.CategorySeedDto;
import productshop.domain.entities.Category;
import productshop.domain.entities.Product;
import productshop.repository.CategoryRepository;
import productshop.util.ValidatorUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public CategoryServiceImpl(CategoryRepository categoryRepository, ValidatorUtil validatorUtil, ModelMapper modelMapper) {
        this.categoryRepository = categoryRepository;
        this.validatorUtil = validatorUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<CategoriesByProductDto> allCategoriesByProduct() {
        List<Category> all = this.categoryRepository.findAll();
        List<CategoriesByProductDto> dto = new ArrayList<>();

        for (Category category : all) {
            CategoriesByProductDto mapped = this.modelMapper.map(category, CategoriesByProductDto.class);
            mapped.setCategory(category.getName());
            int productsCount = category.getProducts().size();
            BigDecimal totalRevenue = category.getProducts()
                    .stream()
                    .map(Product::getPrice)
                    .reduce(BigDecimal::add)
                    .orElse(BigDecimal.ZERO);
            mapped.setProductsCount(productsCount);
            mapped.setTotalRevenue(totalRevenue);
            if(totalRevenue.compareTo(BigDecimal.ZERO)>0) {
                mapped.setAveragePrice(totalRevenue.divide(BigDecimal.valueOf(productsCount), RoundingMode.HALF_DOWN));
            }

            dto.add(mapped);
        }

        return dto;
    }

    @Override
    public void seedCategories(CategorySeedDto[] seed) {

        for (CategorySeedDto categorySeedDto : seed) {
            if(!validatorUtil.isValid(categorySeedDto)){
                validatorUtil.violations(categorySeedDto).forEach(v-> System.out.println(v.getMessage()));
                continue;
            }

            Category category = this.modelMapper.map(categorySeedDto,Category.class);
            this.categoryRepository.saveAndFlush(category);
        }

    }
}
