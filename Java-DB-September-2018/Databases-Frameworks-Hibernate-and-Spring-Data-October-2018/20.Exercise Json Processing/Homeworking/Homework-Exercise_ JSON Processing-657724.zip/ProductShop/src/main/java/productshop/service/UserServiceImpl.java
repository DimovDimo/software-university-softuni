package productshop.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import productshop.domain.dtos.UserSoldProductsDto;
import productshop.domain.dtos.seedsdto.UserSeedDto;
import productshop.domain.entities.User;
import productshop.repository.UserRepository;
import productshop.util.ValidatorUtil;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public UserServiceImpl(UserRepository userRepository, ValidatorUtil validatorUtil, ModelMapper modelMapper) {
        this.userRepository = userRepository;
        this.validatorUtil = validatorUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<UserSoldProductsDto> getUserSoldProducts() {
        List<User> all = this.userRepository.findAll();
        List<UserSoldProductsDto> result = new ArrayList<>();

        for (User seller : all) {
            UserSoldProductsDto userDto = this.modelMapper.map(seller,UserSoldProductsDto.class);
            result.add(userDto);
        }
        return result;
    }

    @Override
    public User getById(Integer id) {
        return this.userRepository.getById(id);
    }

    @Override
    public void seedUsers(UserSeedDto[] seed) {
        for (UserSeedDto userSeedDto : seed) {

            if (!this.validatorUtil.isValid(userSeedDto)) {
                this.validatorUtil.violations(userSeedDto)
                        .forEach(v -> System.out.println(v.getMessage()));
                continue;
            }
            User user = this.modelMapper.map(userSeedDto,User.class);
            this.userRepository.saveAndFlush(user);
        }
    }
}
