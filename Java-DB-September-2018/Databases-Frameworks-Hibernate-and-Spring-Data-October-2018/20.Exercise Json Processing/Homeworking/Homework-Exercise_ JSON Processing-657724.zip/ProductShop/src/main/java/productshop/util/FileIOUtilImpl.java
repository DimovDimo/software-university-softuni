package productshop.util;

import java.io.*;

public class FileIOUtilImpl implements FileIOUtil {
    @Override
    public String readFile(String filePath) throws IOException {

        File file = new File(filePath);
        BufferedReader bf =
                new BufferedReader(new InputStreamReader(new FileInputStream(file)));
        StringBuilder sb = new StringBuilder();
        String line;

        while ((line=bf.readLine()) !=null){
            sb.append(line);
        }
        return sb.toString();
    }

    @Override
    public void writeToFile(String productsJson, String filePath) throws IOException {
        File file = new File(filePath);
        FileWriter writer = new FileWriter(file);
        writer.write(productsJson);
        writer.close();
    }
}
