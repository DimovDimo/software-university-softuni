package cardealer.service;

import cardealer.domain.dto.CarSeedDto;

public interface CarService {
    void seedCars(CarSeedDto[] seed);
}
