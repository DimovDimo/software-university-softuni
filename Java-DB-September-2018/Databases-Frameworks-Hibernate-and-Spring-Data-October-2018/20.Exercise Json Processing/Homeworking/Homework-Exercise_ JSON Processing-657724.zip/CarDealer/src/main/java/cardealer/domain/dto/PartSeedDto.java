package cardealer.domain.dto;

import cardealer.domain.entities.Supplier;
import com.google.gson.annotations.Expose;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class PartSeedDto {
   @Expose
    private String name;
    @Expose
    private BigDecimal price;
    @Expose
    private Integer quantity;
    @Expose
    private Supplier supplier;

    public PartSeedDto() {
    }
@NotNull(message = "Part name cannot be null!")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
@NotNull(message = "Price cannot be null!")
    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
    @NotNull(message = "Quantity cannot be null!")
    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }
}
