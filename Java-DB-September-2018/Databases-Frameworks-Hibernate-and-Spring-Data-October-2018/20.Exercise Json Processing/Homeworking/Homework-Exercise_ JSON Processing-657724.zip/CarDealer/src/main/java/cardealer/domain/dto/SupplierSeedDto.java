package cardealer.domain.dto;

import com.google.gson.annotations.Expose;

import javax.validation.constraints.NotNull;

public class SupplierSeedDto {
    @Expose
    private String name;
    @Expose
    private boolean isImporter;

    public SupplierSeedDto() {
    }
@NotNull(message = "Supplier name cannot be Null!")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    @NotNull(message = "Importer flag cannot be Null!")
    public boolean isImporter() {
        return isImporter;
    }

    public void setImporter(boolean importer) {
        isImporter = importer;
    }
}
