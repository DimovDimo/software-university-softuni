package cardealer.domain.dto;

import cardealer.domain.entities.Part;
import com.google.gson.annotations.Expose;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

public class CarSeedDto {
    @Expose
    private String make;
    @Expose
    private String model;
    @Expose
    private Long travelledDistance;
    @Expose
    private List<Part> parts;

    public CarSeedDto() {
    }
@NotNull(message="Maker cannot be null!")
    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }
    @NotNull(message="Model cannot be null!")
    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
    public Long getTravelledDistance() {
        return travelledDistance;
    }

    public void setTravelledDistance(Long travelledDistance) {
        this.travelledDistance = travelledDistance;
    }

    public List<Part> getParts() {
        return parts;
    }

    public void setParts(List<Part> parts) {
        this.parts = parts;
    }
}
