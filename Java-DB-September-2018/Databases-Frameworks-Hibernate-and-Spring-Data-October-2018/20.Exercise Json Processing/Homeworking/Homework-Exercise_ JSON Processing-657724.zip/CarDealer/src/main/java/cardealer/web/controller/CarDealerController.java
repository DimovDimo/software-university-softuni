package cardealer.web.controller;

import cardealer.domain.dto.CarSeedDto;
import cardealer.domain.dto.PartSeedDto;
import cardealer.domain.dto.SupplierSeedDto;
import cardealer.service.CarService;
import cardealer.service.PartService;
import cardealer.service.SupplierService;
import cardealer.util.FileIOUtil;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;

import java.io.IOException;

@Controller
public class CarDealerController implements CommandLineRunner {
    private final String SUPPLIERS_FILE_PATH="E:\\JAVA PROJECTS\\JavaDB Frameworks\\9_JSONProcessing\\CarDealer\\src\\main\\resources\\files\\suppliers.json";
    private final String PARTS_FILE_PATH="E:\\JAVA PROJECTS\\JavaDB Frameworks\\9_JSONProcessing\\CarDealer\\src\\main\\resources\\files\\parts.json";
    private final String CARS_FILE_PATH="E:\\JAVA PROJECTS\\JavaDB Frameworks\\9_JSONProcessing\\CarDealer\\src\\main\\resources\\files\\cars.json";

    private final SupplierService supplierService;
    private final PartService partService;
    private final CarService carService;
    private final FileIOUtil fileIOUtil;
    private final Gson gson;

    @Autowired
    public CarDealerController(SupplierService supplierService, PartService partService, CarService carService, FileIOUtil fileIOUtil, Gson gson) {
        this.supplierService = supplierService;
        this.partService = partService;
        this.carService = carService;
        this.fileIOUtil = fileIOUtil;
        this.gson = gson;
    }

    @Override
    public void run(String... args) throws Exception {
       this.seedSuppliers();
         this.seedParts();
        this.seedCars();
    }

    private void seedSuppliers() throws IOException {
        String supplierFileContent = this.fileIOUtil.readFile(SUPPLIERS_FILE_PATH);
        SupplierSeedDto[] productSeedDtos = this.gson.fromJson(supplierFileContent, SupplierSeedDto[].class);
        this.supplierService.seedSuppliers(productSeedDtos);
    }
    private void seedParts() throws IOException {
        String partsFileContent = this.fileIOUtil.readFile(PARTS_FILE_PATH);
        PartSeedDto[] partSeedDtos = this.gson.fromJson(partsFileContent, PartSeedDto[].class);
        this.partService.seedParts(partSeedDtos);
    }
    private void seedCars() throws IOException {
        String carsFileContent = this.fileIOUtil.readFile(CARS_FILE_PATH);
        CarSeedDto[] partSeedDtos = this.gson.fromJson(carsFileContent, CarSeedDto[].class);
        this.carService.seedCars(partSeedDtos);
    }
}
