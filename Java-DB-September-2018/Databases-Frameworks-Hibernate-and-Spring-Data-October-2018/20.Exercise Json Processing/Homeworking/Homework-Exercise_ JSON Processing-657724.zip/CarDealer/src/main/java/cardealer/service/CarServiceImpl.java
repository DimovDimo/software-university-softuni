package cardealer.service;

import cardealer.domain.dto.CarSeedDto;
import cardealer.domain.entities.Car;
import cardealer.domain.entities.Part;
import cardealer.repository.CarRepository;
import cardealer.repository.PartRepository;
import cardealer.util.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service
public class CarServiceImpl implements CarService {
    private final PartRepository partRepository;
    private final CarRepository carRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper modelMapper;
@Autowired
    public CarServiceImpl(PartRepository partRepository, CarRepository carRepository, ValidatorUtil validatorUtil, ModelMapper modelMapper) {
        this.partRepository = partRepository;
        this.carRepository = carRepository;
        this.validatorUtil = validatorUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public void seedCars(CarSeedDto[] seed) {


        for (CarSeedDto carSeedDto : seed) {

            if(!validatorUtil.isValid(carSeedDto)){
                validatorUtil.violations(carSeedDto)
                        .forEach(v-> System.out.println(v.getMessage()));
                continue;
            }
            Car car = this.modelMapper.map(carSeedDto, Car.class);
            car.setParts(this.getRandomParts());
            System.out.println();

            this.carRepository.saveAndFlush(car);
        }
    }

    private List<Part> getRandomParts() {
        Random random = new Random();
        List<Part> parts = new ArrayList<>();
        //random.nextInt(max - min + 1) + min
        int partsCount = random.nextInt(20-10+1)+10;
        for (int i = 0; i < partsCount; i++) {
            Part p = this.partRepository.getById(random.nextInt((int) this.partRepository.count() - 1) + 1);
            parts.add(p);
        }

        return parts;
    }
}
