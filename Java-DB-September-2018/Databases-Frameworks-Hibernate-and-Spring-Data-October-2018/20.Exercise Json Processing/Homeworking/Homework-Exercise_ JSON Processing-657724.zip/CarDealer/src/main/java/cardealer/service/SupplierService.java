package cardealer.service;

import cardealer.domain.dto.SupplierSeedDto;

public interface SupplierService {
    void seedSuppliers(SupplierSeedDto[] seed);
}
