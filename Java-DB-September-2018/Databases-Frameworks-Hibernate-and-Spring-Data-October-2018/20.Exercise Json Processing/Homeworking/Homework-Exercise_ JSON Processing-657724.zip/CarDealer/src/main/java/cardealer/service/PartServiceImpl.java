package cardealer.service;

import cardealer.domain.dto.PartSeedDto;
import cardealer.domain.entities.Part;
import cardealer.domain.entities.Supplier;
import cardealer.repository.PartRepository;
import cardealer.repository.SupplierRepository;
import cardealer.util.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class PartServiceImpl implements PartService {
    private final PartRepository partRepository;
    private final SupplierRepository supplierRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public PartServiceImpl(PartRepository partRepository, SupplierRepository supplierRepository, ValidatorUtil validatorUtil, ModelMapper modelMapper) {
        this.partRepository = partRepository;
        this.supplierRepository = supplierRepository;
        this.validatorUtil = validatorUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public void seedParts(PartSeedDto[] seed) {
        for (PartSeedDto partSeedDto : seed) {

            if (!validatorUtil.isValid(partSeedDto)) {
                validatorUtil.violations(partSeedDto)
                        .forEach(v -> System.out.println(v.getMessage()));
                continue;
            }
            Part part = this.modelMapper.map(partSeedDto, Part.class);
            part.setSupplier(this.getRandomSupplier());

            this.partRepository.saveAndFlush(part);
        }

    }

    private Supplier getRandomSupplier() {
        Random random = new Random();
        return this.supplierRepository.getOne(random.nextInt((int) this.supplierRepository.count() - 1) + 1);
    }
}
