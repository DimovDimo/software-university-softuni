package cardealer.service;

import cardealer.domain.dto.SupplierSeedDto;
import cardealer.domain.entities.Supplier;
import cardealer.repository.SupplierRepository;
import cardealer.util.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SupplierServiceImpl implements SupplierService {

    private final SupplierRepository supplierRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public SupplierServiceImpl(SupplierRepository supplierRepository, ValidatorUtil validatorUtil, ModelMapper modelMapper) {
        this.supplierRepository = supplierRepository;
        this.validatorUtil = validatorUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public void seedSuppliers(SupplierSeedDto[] seed) {


        for (SupplierSeedDto supplierSeedDto : seed) {

            if (!validatorUtil.isValid(supplierSeedDto)) {
                validatorUtil.violations(supplierSeedDto)
                        .forEach(v -> System.out.println(v.getMessage()));
                continue;
            }

            Supplier supplier = this.modelMapper.map(supplierSeedDto, Supplier.class);
            supplier.setImporter(supplierSeedDto.isImporter());

            this.supplierRepository.saveAndFlush(supplier);
        }
    }

}
