package cardealer.service;

import cardealer.domain.dto.PartSeedDto;

public interface PartService {
    void seedParts(PartSeedDto[] seed);
}
