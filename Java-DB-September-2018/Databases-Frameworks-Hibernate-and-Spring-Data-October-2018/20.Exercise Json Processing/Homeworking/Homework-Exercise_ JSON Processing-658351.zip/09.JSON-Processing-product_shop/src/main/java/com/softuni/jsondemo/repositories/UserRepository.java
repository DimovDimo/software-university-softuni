package com.softuni.jsondemo.repositories;

import com.softuni.jsondemo.domain.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    @Query("SELECT DISTINCT u " +
            "FROM users AS u " +
            "INNER JOIN u.soldProducts AS p " +
            "WHERE p.buyer IS NOT NULL")
    List<User> findBySoldProducts();

    @Query("SELECT u FROM users AS u " +
            "INNER JOIN u.soldProducts AS sp " +
            "WHERE sp.buyer IS NOT NULL GROUP BY u " +
            "ORDER BY COUNT(sp.id) DESC" )
    List<User> findBySoldProductsCount();
}
