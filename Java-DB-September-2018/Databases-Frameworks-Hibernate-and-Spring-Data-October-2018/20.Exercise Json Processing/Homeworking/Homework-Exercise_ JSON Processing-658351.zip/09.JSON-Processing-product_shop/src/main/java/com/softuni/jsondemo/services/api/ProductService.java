package com.softuni.jsondemo.services.api;

import com.softuni.jsondemo.dtos.ProductSeedDto;
import com.softuni.jsondemo.dtos.view.ProductInRangeDto;

import java.math.BigDecimal;
import java.util.List;

public interface ProductService {
    void seedProducts(ProductSeedDto[] productSeedDtos);

    List<ProductInRangeDto> getAllProductsInPriceRange(BigDecimal lowLimit, BigDecimal highLimit);
}
