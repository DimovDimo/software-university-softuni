package com.softuni.jsondemo.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.softuni.jsondemo.io.FileParserImpl;
import com.softuni.jsondemo.utils.ValidatorUtil;
import com.softuni.jsondemo.utils.ValidatorUtilImpl;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppBeanConfig {


    @Bean
    public FileParserImpl fileParser() {
        return new FileParserImpl();
    }

    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    @Bean
    public Gson gson() {
        return new GsonBuilder()
                .excludeFieldsWithoutExposeAnnotation()
                .setPrettyPrinting()
                .create();
    }

    @Bean
    public ValidatorUtil validatorUtil() {
        return new ValidatorUtilImpl();
    }
}
