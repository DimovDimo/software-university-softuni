package com.softuni.jsondemo.services.api;

import com.softuni.jsondemo.dtos.CategorySeedDto;
import com.softuni.jsondemo.dtos.view.CategoryViewDto;

import java.util.List;

public interface CategoryService {
    void seedCategories(CategorySeedDto[] categorySeedDtos);

    List<CategoryViewDto> getAllCategoriesByProductCount();
}
