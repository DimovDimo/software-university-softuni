package com.softuni.jsondemo.services.impl;

import com.softuni.jsondemo.domain.entities.Product;
import com.softuni.jsondemo.domain.entities.User;
import com.softuni.jsondemo.dtos.UserSeedDto;
import com.softuni.jsondemo.dtos.view.UserSoldProductsDto;
import com.softuni.jsondemo.dtos.view.query4.ProductListDto;
import com.softuni.jsondemo.dtos.view.query4.ProductsNameAndPriceDto;
import com.softuni.jsondemo.dtos.view.query4.UsersListDto;
import com.softuni.jsondemo.dtos.view.query4.UsersProductsDto;
import com.softuni.jsondemo.repositories.ProductRepository;
import com.softuni.jsondemo.repositories.UserRepository;
import com.softuni.jsondemo.services.api.UserService;
import com.softuni.jsondemo.utils.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public UserServiceImpl(UserRepository userRepository, ProductRepository productRepository, ValidatorUtil validatorUtil, ModelMapper modelMapper) {
        this.userRepository = userRepository;
        this.productRepository = productRepository;
        this.validatorUtil = validatorUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public void seedUsers(UserSeedDto[] userSeedDtos) {
        for (UserSeedDto userSeedDto : userSeedDtos) {
            if (!this.validatorUtil.isValid(userSeedDto)) {
                this.validatorUtil.violations(userSeedDto)
                        .forEach(violation -> System.out.println(violation.getMessage()));
                continue;
            }

            User user = this.modelMapper.map(userSeedDto, User.class);
            this.userRepository.saveAndFlush(user);
        }
    }

    @Override
    public List<UserSoldProductsDto> getAllUsersSoldProducts() {
        List<User> users = this.userRepository.findBySoldProducts();
        List<UserSoldProductsDto> userSoldProductsDtos = new ArrayList<>();

        for (User user : users) {
            List<Product> forRemove = new ArrayList<>();
            for (Product soldProduct : user.getSoldProducts()) {
                if (soldProduct.getBuyer() == null) {
                    forRemove.add(soldProduct);
                }
            }
            user.getSoldProducts().removeAll(forRemove);

            UserSoldProductsDto userSoldProductsDto = this.modelMapper.map(user, UserSoldProductsDto.class);
            userSoldProductsDtos.add(userSoldProductsDto);
        }

        return userSoldProductsDtos;
    }

    @Override
    public UsersListDto getUsersBySoldProductsCount() {
        List<User> users = this.userRepository.findBySoldProducts();
        UsersListDto usersListDto = new UsersListDto();
        usersListDto.setUsersCount(users.size());

        List<UsersProductsDto> usersProductsDtos = new ArrayList<>();
        for (User user : users) {
            UsersProductsDto usersProductsDto = this.modelMapper.map(user, UsersProductsDto.class);
            ProductListDto productListDto = usersProductsDto.getSoldProducts();
            List<Product> products = this.productRepository.findSoldProductsByUserId(user.getId());
            productListDto.setCount(products.size());
            List<ProductsNameAndPriceDto> productsNameAndPriceDtos = new ArrayList<>();
            for (Product product : products) {
                ProductsNameAndPriceDto productsNameAndPriceDto = this.modelMapper.map(product, ProductsNameAndPriceDto.class);
                productsNameAndPriceDtos.add(productsNameAndPriceDto);
            }

            productListDto.setProducts(productsNameAndPriceDtos);
            usersProductsDtos.add(usersProductsDto);
        }

        usersListDto.setUsers(usersProductsDtos);
        return usersListDto;
    }
}
