package com.softuni.jsondemo.io;

import org.springframework.stereotype.Component;

import java.io.*;

public class FileParserImpl implements FileParser {

    public String readFile(String filePath) {
        StringBuilder sb = new StringBuilder();

        try (InputStream inputStream = this.getClass().getResourceAsStream(filePath);
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {

            String line = reader.readLine();
            while (line != null) {
                sb.append(line);
                line = reader.readLine();
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

        return sb.toString().trim();
    }

    public void writeFile(String filePath, String content) {
        File file = new File(System.getProperty("user.dir") + filePath);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try (OutputStream outputStream = new FileOutputStream(System.getProperty("user.dir") + filePath);
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream))) {

            writer.write(content);

        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }
}
