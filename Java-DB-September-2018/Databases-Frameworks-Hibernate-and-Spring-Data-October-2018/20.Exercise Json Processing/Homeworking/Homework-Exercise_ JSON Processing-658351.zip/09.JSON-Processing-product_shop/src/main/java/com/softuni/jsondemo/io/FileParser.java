package com.softuni.jsondemo.io;

public interface FileParser {
    String readFile(String filePath);

    void writeFile(String filePath, String content);
}
