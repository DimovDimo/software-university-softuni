package com.softuni.jsondemo.appcontroller;

import com.google.gson.Gson;
import com.softuni.jsondemo.dtos.CategorySeedDto;
import com.softuni.jsondemo.dtos.ProductSeedDto;
import com.softuni.jsondemo.dtos.UserSeedDto;
import com.softuni.jsondemo.dtos.view.CategoryViewDto;
import com.softuni.jsondemo.dtos.view.ProductInRangeDto;
import com.softuni.jsondemo.dtos.view.UserSoldProductsDto;
import com.softuni.jsondemo.dtos.view.query4.UsersListDto;
import com.softuni.jsondemo.io.FileParser;
import com.softuni.jsondemo.services.api.CategoryService;
import com.softuni.jsondemo.services.api.ProductService;
import com.softuni.jsondemo.services.api.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;

import java.math.BigDecimal;
import java.util.List;

@Controller
public class ProductShopController implements CommandLineRunner {
    private static final String USER_FILE_PATH = "/files/in/users.json";
    private static final String CATEGORY_FILE_PATH = "/files/in/categories.json";
    private static final String PRODUCT_FILE_PATH = "/files/in/products.json";
    private static final String PRODUCTS_IN_RANGE_FILE_PATH = "/src/main/resources/files/out/productsInRange.json";
    private static final String USERS_SUCCESSFULLY_SOLD_PRODUCTS_FILE_PATH = "/src/main/resources/files/out/userSoldProducts.json";
    private static final String CATEGORIES_BY_PRODUCTS_COUNT_FILE_PATH = "/src/main/resources/files/out/categoriesByProductCount.json";
    private static final String USERS_AND_THEIR_PRODUCTS_FILE_PATH = "/src/main/resources/files/out/usersBySoldProductCount.json";


    private final UserService userService;
    private final CategoryService categoryService;
    private final ProductService productService;
    private final FileParser fileParser;
    private final Gson gson;

    @Autowired
    public ProductShopController(UserService userService, CategoryService categoryService,
                                 ProductService productService, FileParser fileParser, Gson gson) {
        this.userService = userService;
        this.categoryService = categoryService;
        this.productService = productService;
        this.fileParser = fileParser;
        this.gson = gson;
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Running ...");
//        1.
//        this.seedUsers();

//        2.
//        this.seedCategories();

//        3.
//        this.seedProducts();

//        4.
//        this.writeToFileAllProductsInPriceRange(new BigDecimal("500"), new BigDecimal("1000"));

//        5.
//        this.writeToFileSuccessfullySoldProducts();

//        6.
//        this.writeToFileCategoriesByProductsCount();

//        7.
//        this.writeToFileUsersAndTheirSoldProducts();
    }

    private void seedCategories() {
        String content = this.fileParser.readFile(CATEGORY_FILE_PATH);
        CategorySeedDto[] categorySeedDtos = this.gson.fromJson(content, CategorySeedDto[].class);
        this.categoryService.seedCategories(categorySeedDtos);
    }

    private void seedUsers() {
        String content = this.fileParser.readFile(USER_FILE_PATH);
        UserSeedDto[] userSeedDtos = this.gson.fromJson(content, UserSeedDto[].class);
        this.userService.seedUsers(userSeedDtos);

    }

    private void seedProducts() {
        String content = this.fileParser.readFile(PRODUCT_FILE_PATH);
        ProductSeedDto[] productSeedDtos = this.gson.fromJson(content, ProductSeedDto[].class);
        this.productService.seedProducts(productSeedDtos);
    }

    private void writeToFileAllProductsInPriceRange(BigDecimal lowLimit, BigDecimal highLimit) {
        List<ProductInRangeDto> productInRangeDtos = this.productService.getAllProductsInPriceRange(lowLimit, highLimit);
        String content = this.gson.toJson(productInRangeDtos);

        this.fileParser.writeFile(PRODUCTS_IN_RANGE_FILE_PATH, content);
    }

    private void writeToFileSuccessfullySoldProducts() {
        List<UserSoldProductsDto> userSoldProductsDtos = this.userService.getAllUsersSoldProducts();
        String content = this.gson.toJson(userSoldProductsDtos);

        this.fileParser.writeFile(USERS_SUCCESSFULLY_SOLD_PRODUCTS_FILE_PATH, content);
    }

    private void writeToFileCategoriesByProductsCount() {
        List<CategoryViewDto> categoryViewDtos = this.categoryService.getAllCategoriesByProductCount();
        String content = this.gson.toJson(categoryViewDtos);

        this.fileParser.writeFile(CATEGORIES_BY_PRODUCTS_COUNT_FILE_PATH, content);
    }

    private void writeToFileUsersAndTheirSoldProducts() {
        UsersListDto usersListDto = this.userService.getUsersBySoldProductsCount();
        String content = this.gson.toJson(usersListDto);

        this.fileParser.writeFile(USERS_AND_THEIR_PRODUCTS_FILE_PATH, content);
    }
}
