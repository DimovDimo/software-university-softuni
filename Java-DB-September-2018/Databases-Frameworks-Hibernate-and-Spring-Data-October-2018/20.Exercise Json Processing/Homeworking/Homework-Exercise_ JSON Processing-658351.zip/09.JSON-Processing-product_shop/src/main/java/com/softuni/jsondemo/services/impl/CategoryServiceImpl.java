package com.softuni.jsondemo.services.impl;

import com.softuni.jsondemo.domain.entities.Category;
import com.softuni.jsondemo.dtos.CategorySeedDto;
import com.softuni.jsondemo.dtos.view.CategoryViewDto;
import com.softuni.jsondemo.repositories.CategoryRepository;
import com.softuni.jsondemo.services.api.CategoryService;
import com.softuni.jsondemo.utils.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {
    private final CategoryRepository categoryRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public CategoryServiceImpl(CategoryRepository categoryRepository, ValidatorUtil validatorUtil, ModelMapper modelMapper) {
        this.categoryRepository = categoryRepository;
        this.validatorUtil = validatorUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public void seedCategories(CategorySeedDto[] categorySeedDtos) {
        for (CategorySeedDto categorySeedDto : categorySeedDtos) {
            if (!this.validatorUtil.isValid(categorySeedDto)) {
                this.validatorUtil.violations(categorySeedDto)
                        .forEach(violation -> System.out.println(violation.getMessage()));
                continue;
            }

            Category category = this.modelMapper.map(categorySeedDto, Category.class);
            this.categoryRepository.saveAndFlush(category);
        }
    }

    @Override
    public List<CategoryViewDto> getAllCategoriesByProductCount() {
        List<Object[]> categories = this.categoryRepository.findAllByNumberOfProducts();
        List<CategoryViewDto> categoryViewDtos = new ArrayList<>();

        for (Object[] category : categories) {
            CategoryViewDto categoryViewDto = new CategoryViewDto();
            categoryViewDto.setCategory((String) category[0]);
            categoryViewDto.setProductCount((Long) category[1]);
            categoryViewDto.setAveragePrice(BigDecimal.valueOf(Double.parseDouble(category[2].toString())));
            categoryViewDto.setTotalRevenue(BigDecimal.valueOf(Double.parseDouble(category[3].toString())));
            categoryViewDtos.add(categoryViewDto);
        }

        return categoryViewDtos;
    }
}
