package com.softuni.jsondemo.services.impl;

import com.softuni.jsondemo.domain.entities.Category;
import com.softuni.jsondemo.domain.entities.Product;
import com.softuni.jsondemo.domain.entities.User;
import com.softuni.jsondemo.dtos.ProductSeedDto;
import com.softuni.jsondemo.dtos.view.ProductInRangeDto;
import com.softuni.jsondemo.repositories.CategoryRepository;
import com.softuni.jsondemo.repositories.ProductRepository;
import com.softuni.jsondemo.repositories.UserRepository;
import com.softuni.jsondemo.services.api.ProductService;
import com.softuni.jsondemo.utils.ValidatorUtil;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

@Service
public class ProductServiceImpl implements ProductService {
    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final UserRepository userRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper modelMapper;

    public ProductServiceImpl(ProductRepository productRepository, CategoryRepository categoryRepository, UserRepository userRepository, ValidatorUtil validatorUtil, ModelMapper modelMapper) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
        this.userRepository = userRepository;
        this.validatorUtil = validatorUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public void seedProducts(ProductSeedDto[] productSeedDtos) {
        List<User> users = this.userRepository.findAll();
        List<Category> categories = this.categoryRepository.findAll();
        Random random = new Random();

        for (int i = 0; i < productSeedDtos.length; i++) {
            if (!this.validatorUtil.isValid(productSeedDtos[i])) {
                this.validatorUtil.violations(productSeedDtos[i])
                        .forEach(violation -> System.out.println(violation.getMessage()));
                continue;
            }

            Product product = this.modelMapper.map(productSeedDtos[i], Product.class);

            if (i % 5 != 0) {
                product.setBuyer(users.get(random.nextInt(users.size())));
            }
            product.setSeller(users.get(random.nextInt(users.size())));

            Set<Integer> ids = new HashSet<>();
            for (int j = 0; j < 7; j++) {
                ids.add(random.nextInt(categories.size()));
            }

            Set<Category> categorySet = new HashSet<>();
            for (Integer id : ids) {
                categorySet.add(categories.get(id));
            }

            product.setCategories(categorySet);
            this.productRepository.saveAndFlush(product);
        }
    }

    @Override
    public List<ProductInRangeDto> getAllProductsInPriceRange(BigDecimal lowLimit, BigDecimal highLimit) {
        List<Product> products = this.productRepository.findAllByPriceBetweenAndBuyerIsNullOrderByPriceAsc(lowLimit, highLimit);
        List<ProductInRangeDto> productInRangeDtos = new ArrayList<>();

//        for (Product product : products) {
//            ProductInRangeDto productInRangeDto = this.modelMapper.map(product, ProductInRangeDto.class);
//            productInRangeDto.setSeller(String.format("%s %s", product.getSeller().getFirstName(), product.getSeller().getLastName()));
//            productInRangeDtos.add(productInRangeDto);
//        }
//
//        return productInRangeDtos;

        Converter<User, String> sellerFullName = ctx -> {
            User user = ctx.getSource();
            return user.getFirstName() + " " + user.getLastName();
        };

        this.modelMapper.createTypeMap(Product.class, ProductInRangeDto.class)
                .addMappings(m -> m.using(sellerFullName)
                        .map(Product::getSeller, ProductInRangeDto::setSeller));


        for (Product product : products) {
            ProductInRangeDto productInRangeDto = this.modelMapper.map(product, ProductInRangeDto.class);
            productInRangeDtos.add(productInRangeDto);
        }

        return productInRangeDtos;
    }
}

