package com.softuni.jsondemo.services.api;

import com.softuni.jsondemo.dtos.UserSeedDto;
import com.softuni.jsondemo.dtos.view.UserSoldProductsDto;
import com.softuni.jsondemo.dtos.view.query4.UsersListDto;
import org.springframework.stereotype.Service;

import java.util.List;

public interface UserService {
    void seedUsers(UserSeedDto[] userSeedDtos);

    List<UserSoldProductsDto> getAllUsersSoldProducts();

    UsersListDto getUsersBySoldProductsCount();
}
