package com.softuni.jsondemo.repositories;

import com.softuni.jsondemo.domain.entities.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Integer> {
    List<Product> findAllByPriceBetweenAndBuyerIsNullOrderByPriceAsc(BigDecimal lowLimit, BigDecimal highLimit);

    @Query("SELECT p FROM products AS p " +
            "WHERE p.buyer IS NOT NULL AND p.seller.id = :userId")
    List<Product> findSoldProductsByUserId(@Param("userId") Integer userId);
}
