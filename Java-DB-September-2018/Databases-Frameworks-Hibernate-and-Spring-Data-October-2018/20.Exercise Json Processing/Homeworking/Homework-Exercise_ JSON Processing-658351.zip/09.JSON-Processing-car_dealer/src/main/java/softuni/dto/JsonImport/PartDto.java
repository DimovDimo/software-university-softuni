package softuni.dto.JsonImport;


public class PartDto {
    private Long id;

    public PartDto() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
