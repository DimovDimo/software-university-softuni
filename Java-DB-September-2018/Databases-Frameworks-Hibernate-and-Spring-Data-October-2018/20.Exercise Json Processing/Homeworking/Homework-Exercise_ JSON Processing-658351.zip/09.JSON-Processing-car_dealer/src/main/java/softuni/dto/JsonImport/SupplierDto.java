package softuni.dto.JsonImport;


public class SupplierDto {
    private Long id;

    public SupplierDto() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
