package productsshop.util;

import java.io.IOException;

public interface FileIOUtil {

    String readFile(String filePath) throws IOException;
}
