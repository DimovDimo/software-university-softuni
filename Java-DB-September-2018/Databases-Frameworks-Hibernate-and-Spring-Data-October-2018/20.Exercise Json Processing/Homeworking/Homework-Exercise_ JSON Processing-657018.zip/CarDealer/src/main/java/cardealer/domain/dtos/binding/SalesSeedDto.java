package cardealer.domain.dtos.binding;

public class SalesSeedDto {
}
