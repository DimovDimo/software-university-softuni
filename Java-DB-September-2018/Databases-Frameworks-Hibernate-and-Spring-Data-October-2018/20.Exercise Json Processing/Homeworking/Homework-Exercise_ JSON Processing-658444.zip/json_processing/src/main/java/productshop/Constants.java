package productshop;

public class Constants {
}
