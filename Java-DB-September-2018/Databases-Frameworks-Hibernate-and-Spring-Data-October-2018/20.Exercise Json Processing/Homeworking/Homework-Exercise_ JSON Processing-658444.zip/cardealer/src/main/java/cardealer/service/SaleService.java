package cardealer.service;

public interface SaleService {
    void generateSales();
}
