package appbookshopsystem.domain.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT;
}
