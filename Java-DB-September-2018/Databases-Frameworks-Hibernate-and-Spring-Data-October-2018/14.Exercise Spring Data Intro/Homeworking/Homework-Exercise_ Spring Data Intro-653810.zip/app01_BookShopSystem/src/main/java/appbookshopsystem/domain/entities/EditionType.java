package appbookshopsystem.domain.entities;

public enum EditionType {
    NORMAL,PROMO,GOLD;
}
