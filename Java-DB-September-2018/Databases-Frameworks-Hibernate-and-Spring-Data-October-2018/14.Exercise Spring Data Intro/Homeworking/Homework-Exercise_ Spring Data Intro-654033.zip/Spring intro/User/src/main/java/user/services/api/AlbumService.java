package user.services.api;

public interface AlbumService {
}
