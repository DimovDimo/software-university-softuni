package bookshopapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookshopApp {
    public static void main(String[] args) {
        SpringApplication.run(BookshopApp.class, args);
    }
}
