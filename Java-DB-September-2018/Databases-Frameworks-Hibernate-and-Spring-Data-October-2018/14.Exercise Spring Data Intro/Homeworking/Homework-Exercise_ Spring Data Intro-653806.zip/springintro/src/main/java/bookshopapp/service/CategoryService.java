package bookshopapp.service;

import java.io.IOException;

public interface CategoryService {

    void seedCategories() throws IOException;
}
