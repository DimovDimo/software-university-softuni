package bookshopapp.domain.enums;

public enum AgeRestriction {
    MINOR, TEEN, ADULT;
}
