package bookshopapp.domain.enums;

public enum EditionType {
    NORMAL, PROMO, GOLD;
}
