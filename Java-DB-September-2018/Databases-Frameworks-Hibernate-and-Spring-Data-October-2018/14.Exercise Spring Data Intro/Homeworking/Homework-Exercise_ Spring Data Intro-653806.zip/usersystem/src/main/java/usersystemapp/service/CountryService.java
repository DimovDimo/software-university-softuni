package usersystemapp.service;

public interface CountryService {

}
