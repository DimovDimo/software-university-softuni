package usersystemapp.service;

public interface AlbumService {
}
