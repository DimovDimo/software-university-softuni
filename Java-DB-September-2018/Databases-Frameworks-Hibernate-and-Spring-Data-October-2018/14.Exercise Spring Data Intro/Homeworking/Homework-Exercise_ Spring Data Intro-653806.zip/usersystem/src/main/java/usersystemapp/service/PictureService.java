package usersystemapp.service;

public interface PictureService {
}
