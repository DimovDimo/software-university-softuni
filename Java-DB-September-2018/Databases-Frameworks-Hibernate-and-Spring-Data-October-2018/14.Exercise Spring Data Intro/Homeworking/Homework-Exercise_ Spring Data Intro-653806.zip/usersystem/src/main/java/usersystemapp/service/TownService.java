package usersystemapp.service;

public interface TownService {
}
