package bookshop;

import javax.persistence.Entity;

@Entity
public class Book {
}
