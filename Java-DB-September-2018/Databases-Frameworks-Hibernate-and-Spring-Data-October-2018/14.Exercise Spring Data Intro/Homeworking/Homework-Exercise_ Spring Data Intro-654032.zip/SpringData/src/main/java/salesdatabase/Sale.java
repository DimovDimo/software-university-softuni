package salesdatabase;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Table(name="sales")
public class Sale extends BaseEntity {

    @ManyToOne(targetEntity = Product.class)
    @JoinColumn(name="product_id",referencedColumnName = "id")
    Product product;
    @ManyToOne(targetEntity = Customer.class)
    @JoinColumn(name="customer_id",referencedColumnName = "id")
    Customer customer;
    @ManyToOne(targetEntity = StoreLocation.class)
    @JoinColumn(name="store_location_id",referencedColumnName = "id")
    StoreLocation storeLocation;



    @Column(name="date")
    LocalDate date;


    public Sale() {
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public StoreLocation getStoreLocation() {
        return storeLocation;
    }

    public void setStoreLocation(StoreLocation storeLocation) {
        this.storeLocation = storeLocation;
    }
    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

}
