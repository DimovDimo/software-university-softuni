package entities;

import org.hibernate.annotations.Check;

import javax.persistence.*;
import java.util.Date;
import javax.validation.constraints.*;

@Entity(name="wizard_deposits")
@Table(schema = "soft_uni")
public class WizardDeposits {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @PositiveOrZero
    @Column(length = (231-1))
    private int id; //– Primary Key (number in range [1, 231-1].
    @Column(name="first_name", length = 50)
    private String firstName; //         first_name – Text field with max length of 50 symbols.
    @Column(name="last_name", length = 60)
    private String lastName;//           last_name - Text field with max length of 60 symbols. Required
    @Column(name="notes", length = 1000)
    private String notes;//              notes – Text field with max length of 1000 symbols
    @Column(name="age",nullable = false)
    @PositiveOrZero
    private int age;//                   age – Non-negative number. Required
    @Column(name="magic_wand_creator")
    private String magicWandCreator;//   magic_wand_creator – Text field with max length of 100 symbols
    @PositiveOrZero
    @Column(name="magic_wand_size", length = 215-1)
    private int magicWandSize;//          magic_wand_size – Number in range [1, 215-1]
    @Column(name="deposit_group",length = 20)
    private String depositGroup;//          deposit_group - Text field with max length of 20 symbols
    @Column(name="deposit_start_date")
    private Date  depositStartDate;//        deposit_start_date – Date and time field
    @Column(name="deposit_amount")
    private Float depositAmount;//        deposit_amount – Floating point number field
    @Column(name="deposit_interest")
    private Float depositInterest;//      deposit_interest - Floating point number field
    @Column(name="deposit_charge")
    private Float depositCharge;//     deposit_charge - Floating point number field
    @Column(name="deposit_expiration_date")
    private Date depositExpirationDate;//   deposit_expiration_date – Date and time field

    private Boolean isDepositExpire;//                           is_deposit_expired – Boolean field

    public WizardDeposits() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getMagicWandCreator() {
        return magicWandCreator;
    }

    public void setMagicWandCreator(String magicWandCreator) {
        this.magicWandCreator = magicWandCreator;
    }

    public int getMagicWandSize() {
        return magicWandSize;
    }

    public void setMagicWandSize(int magicWandSize) {
        this.magicWandSize = magicWandSize;
    }

    public String getDepositGroup() {
        return depositGroup;
    }

    public void setDepositGroup(String depositGroup) {
        this.depositGroup = depositGroup;
    }

    public Date getDepositStartDate() {
        return depositStartDate;
    }

    public void setDepositStartDate(Date depositStartDate) {
        this.depositStartDate = depositStartDate;
    }

    public Float getDepositAmount() {
        return depositAmount;
    }

    public void setDepositAmount(Float depositAmount) {
        this.depositAmount = depositAmount;
    }

    public Float getDepositInterest() {
        return depositInterest;
    }

    public void setDepositInterest(Float depositInterest) {
        this.depositInterest = depositInterest;
    }

    public Float getDepositCharge() {
        return depositCharge;
    }

    public void setDepositCharge(Float depositCharge) {
        this.depositCharge = depositCharge;
    }

    public Date getDepositExpirationDate() {
        return depositExpirationDate;
    }

    public void setDepositExpirationDate(Date depositExpirationDate) {
        this.depositExpirationDate = depositExpirationDate;
    }

    public Boolean getDepositExpire() {
        return isDepositExpire;
    }

    public void setDepositExpire(Boolean depositExpire) {
        isDepositExpire = depositExpire;
    }
}
