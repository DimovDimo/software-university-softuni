

import javax.persistence.EntityManager;

import java.sql.SQLException;
import java.util.*;

public class Engine implements Runnable {

    private final EntityManager entityManager;
    private Scanner scanner;

    public Engine(EntityManager entityManager) {
        this.entityManager = entityManager;
        this.scanner = new Scanner(System.in);

    }

    public void run() {
//        try {
//
//            this.callTask(this.scanner.nextInt());
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
    }

    private void callTask(int taskNumber) throws SQLException {

        switch (taskNumber) {

        }
    }


}
