package app.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name= "bank_accounts")
public class BankAccount extends  BillingDetail {

    private  String name;
    @Column(name ="swift_code")
    private  String SwiftCode;

    public BankAccount() {
    }

    public BankAccount(int number, User user, String name, String swiftCode) {
        super(number, user);
        this.name = name;
        SwiftCode = swiftCode;
    }
}
