package app.entities;

import javax.persistence.*;
import java.security.PublicKey;
import java.util.Set;

@Entity
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;
    private Double quantity;
    @OneToMany(mappedBy = "product", targetEntity = Sale.class)
    Set<Sale> sales;

    public Product(String name, Double quantity) {
        this.name = name;
        this.quantity = quantity;
        this.sales = sales;
    }
    public  Product(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public Set<Sale> getSales() {
        return sales;
    }

    public void setSales(Set<Sale> sales) {
        this.sales = sales;
    }
}
