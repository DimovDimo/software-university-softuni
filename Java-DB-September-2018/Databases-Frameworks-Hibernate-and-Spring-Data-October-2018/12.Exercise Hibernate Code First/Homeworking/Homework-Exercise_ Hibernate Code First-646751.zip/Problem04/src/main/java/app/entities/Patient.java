package app.entities;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.sql.Clob;
import java.sql.PreparedStatement;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "patients")
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  int id;
    @Column (name ="first_name")
    private String firstName;
    @Column(name = "last_name")
    private String lastName;
    private  String address;
    private String email;
    @Column(name ="date_of_birth")
    private Date dateOfBirth;
    //private Clob picture;
    @Lob
    @Column(name="BOOK_IMAGE", nullable=false, columnDefinition="mediumblob")
    private byte[] image;
    @Column(name = "is_insured")
    private  boolean isInsurted;

    @OneToMany(mappedBy = "patient",targetEntity = Visitation.class, fetch = FetchType.LAZY)
    @Cascade( value = org.hibernate.annotations.CascadeType.ALL)
    private Set<Visitation> visitations;

    @OneToMany(mappedBy = "patient",targetEntity = Diagnose.class, fetch = FetchType.LAZY)
    @Cascade( value = org.hibernate.annotations.CascadeType.ALL)
    private List<Diagnose> diagnoses;


    @OneToMany(mappedBy = "patient",targetEntity = PrescribedMedicament.class, fetch = FetchType.LAZY)
    @Cascade( value = org.hibernate.annotations.CascadeType.ALL)
    private  List<PrescribedMedicament> prescribedMedicaments;


    public  Patient(){}

    public Patient(String firstName, String lastName, String address, String email, Date dateOfBirth, byte[] image, boolean isInsurted,
                   Set<Visitation> visitations, List<Diagnose> diagnoses,
                   List<PrescribedMedicament> prescribedMedicaments) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.image = image;
        this.isInsurted = isInsurted;
        this.visitations = visitations;
        this.diagnoses = diagnoses;
        this.prescribedMedicaments = prescribedMedicaments;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public boolean isInsurted() {
        return isInsurted;
    }

    public void setInsurted(boolean insurted) {
        isInsurted = insurted;
    }

    public Set<Visitation> getVisitations() {
        return visitations;
    }

    public void setVisitations(Set<Visitation> visitations) {
        this.visitations = visitations;
    }

    public List<Diagnose> getDiagnoses() {
        return diagnoses;
    }

    public void setDiagnoses(List<Diagnose> diagnoses) {
        this.diagnoses = diagnoses;
    }

    public List<PrescribedMedicament> getPrescribedMedicaments() {
        return prescribedMedicaments;
    }

    public void setPrescribedMedicaments(List<PrescribedMedicament> prescribedMedicaments) {
        this.prescribedMedicaments = prescribedMedicaments;
    }
}
