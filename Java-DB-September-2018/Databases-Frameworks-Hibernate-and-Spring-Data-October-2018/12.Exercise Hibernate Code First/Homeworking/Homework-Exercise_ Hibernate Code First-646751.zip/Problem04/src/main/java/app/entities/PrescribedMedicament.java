package app.entities;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;

@Entity
@Table (name = "prescribed_medicaments")
public class PrescribedMedicament {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  int id;
    private String name;

    @ManyToOne (optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name ="patient_id", referencedColumnName = "id")
    @Cascade(value = org.hibernate.annotations.CascadeType.ALL)
    private  Patient patient;

    public PrescribedMedicament() {
    }

    public PrescribedMedicament(String name, Patient patient) {
        this.name = name;
        this.patient = patient;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }
}
