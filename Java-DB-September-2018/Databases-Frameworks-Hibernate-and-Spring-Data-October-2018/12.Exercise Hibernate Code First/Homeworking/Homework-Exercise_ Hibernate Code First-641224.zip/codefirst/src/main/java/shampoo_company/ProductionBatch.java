package shampoo_company;

public class ProductionBatch {
}
