package shampoo_company;

public class Price {
}
