package app.hospital;

import app.hospital.entities.Diagnose;
import app.hospital.entities.Medicament;
import app.hospital.entities.Patient;
import app.hospital.entities.Visitation;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("hospital");
        EntityManager em = emf.createEntityManager();

        System.out.println("Running ...");

        LocalDate birthDateGosho = LocalDate.of(2000, 10, 12);
        Patient gosho = new Patient("Gosho", "Pesov", birthDateGosho, true);

        LocalDate birthDateMisho = LocalDate.of(2000, 10, 12);
        Patient misho = new Patient("Misho", "Mishev", birthDateMisho, false);

        Medicament aspirin = new Medicament("Aspirin");
        Medicament vitaminC = new Medicament("Vitamin C");
        Medicament paracetamol = new Medicament("Paracetamol");
        gosho.getMedicaments().add(aspirin);
        gosho.getMedicaments().add(vitaminC);
        misho.getMedicaments().add(vitaminC);
        misho.getMedicaments().add(paracetamol);

        Diagnose diagnose = new Diagnose("Malko piene", "Pacientyt pie mnogo malko.");
        gosho.getDiagnoses().add(diagnose);
        misho.getDiagnoses().add(diagnose);

        Visitation visitation = new Visitation(LocalDate.now(), "Wsichko e tochno", gosho);

        em.getTransaction().begin();
        em.persist(visitation);
        em.persist(misho);
        em.getTransaction().commit();

        em.clear();

        Patient testPatient = em.find(Patient.class, 2L);
        testPatient.getMedicaments().forEach(m -> System.out.println(m.getName()));
        System.out.println("====================================================================");
        Diagnose testDiagnose = em.find(Diagnose.class, 1L);
        testDiagnose.getPatients().forEach(p -> System.out.println(p.getFirstName() + " " + p.getLastName()));

        em.close();
        emf.close();
    }
}
