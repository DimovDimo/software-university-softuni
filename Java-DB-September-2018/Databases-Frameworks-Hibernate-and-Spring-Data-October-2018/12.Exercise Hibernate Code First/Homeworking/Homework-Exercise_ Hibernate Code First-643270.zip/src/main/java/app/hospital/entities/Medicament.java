package app.hospital.entities;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "medicaments")
public class Medicament {
    private long id;
    private String name;
    private Set<Patient> patients;

    public Medicament() {
        this.setPatients(new HashSet<>());
    }

    public Medicament(String name) {
        this.setName(name);
        this.setPatients(new HashSet<>());
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Column
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @ManyToMany(mappedBy = "medicaments", targetEntity = Patient.class, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    public Set<Patient> getPatients() {
        return this.patients;
    }

    public void setPatients(Set<Patient> patients) {
        this.patients = patients;
    }
}
