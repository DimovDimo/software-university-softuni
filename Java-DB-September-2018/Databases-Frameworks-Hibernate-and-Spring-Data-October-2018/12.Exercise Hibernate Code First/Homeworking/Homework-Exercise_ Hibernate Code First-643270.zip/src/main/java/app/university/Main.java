package app.university;

import app.university.entities.Course;
import app.university.entities.Human;
import app.university.entities.Student;
import app.university.entities.Teacher;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("university");
        EntityManager em = emf.createEntityManager();

        System.out.println("Running...");

//        em.getTransaction().begin();

//        Student studentGosho = new Student();
//        studentGosho.setFirstName("goshi");
//        studentGosho.setLastName("goshev");
//
//        Student studentPesho = new Student();
//        studentPesho.setFirstName("Pesho");
//        studentPesho.setLastName("Peshev");
//
//        Student studentMisho = new Student();
//        studentMisho.setFirstName("Misho");
//        studentMisho.setLastName("Mishev");
//
//        Course course = new Course();
//        course.setName("Java");
//        course.setDescription("Mnogo qk");
//
//        course.getStudents().add(studentGosho);
//        course.getStudents().add(studentPesho);
//        course.getStudents().add(studentMisho);
//
//        em.persist(studentGosho);
//        em.persist(studentPesho);
//        em.persist(studentMisho);
//
//        em.persist(course);
//        em.getTransaction().commit();
//
//        em.clear();


//        em.getTransaction().begin();
//        Teacher teacher = new Teacher();
//        teacher.setFirstName("Master");
//        teacher.setLastName("Masterov");
//        em.persist(teacher);
//
//        Course course = em.find(Course.class,1L);
//        course.setTeacher(teacher);
//        em.persist(course);
//        em.getTransaction().commit();
//
//        em.clear();


        em.find(Student.class, 3L)
                .getCourses()
                .forEach(c -> System.out.println(c.getName()));

        em.find(Course.class, 1L)
                .getStudents()
                .forEach(s -> System.out.println(s.getFirstName()));

        em.find(Teacher.class, 5L)
                .getCourses()
                .forEach(c -> System.out.println(c.getName()));

        em.close();
        emf.close();

    }
}
