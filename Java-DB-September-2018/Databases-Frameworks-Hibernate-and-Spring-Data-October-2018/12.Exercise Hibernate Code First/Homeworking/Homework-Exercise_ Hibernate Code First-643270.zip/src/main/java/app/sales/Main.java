package app.sales;

import app.sales.entities.Customer;
import app.sales.entities.Product;
import app.sales.entities.Sale;
import app.sales.entities.StoreLocation;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.math.BigDecimal;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("sales");
        EntityManager em = emf.createEntityManager();
        System.out.println("Running...");

        em.getTransaction().begin();

        Product product = new Product("Zele", 3.6, new BigDecimal(4.5));
        Product product1 = new Product("Domat", 3.0, new BigDecimal(1.5));
        Customer customer = new Customer("Gosho", "gosho@google.com", "123456789");
        Customer customer1 = new Customer("Misho", "misho@google.com", "777777777");
        StoreLocation storeLocation = new StoreLocation("Sofia");

        Sale sale = new Sale();
        Sale sale1 = new Sale();
        Sale sale2 = new Sale();

        sale.setProduct(product);
        sale.setCustomer(customer);
        sale.setStoreLocation(storeLocation);

        sale1.setProduct(product);
        sale1.setCustomer(customer1);
        sale1.setStoreLocation(storeLocation);

        sale2.setProduct(product);
        sale2.setCustomer(customer);
        sale.setStoreLocation(storeLocation);

        em.persist(sale);
        em.persist(sale1);
        em.persist(sale2);
        em.getTransaction().commit();

        em.clear();

        Sale sale3 = em.find(Sale.class, 2L);
        Product product2 = em.find(Product.class,1L);

        em.close();
        emf.close();


    }
}
