package app.billing.entities;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "bank_account")
public class BankAccount extends BillingDetail {
    private String name;
    private String swift;

    public BankAccount() {
    }

    @Column
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column
    public String getSwift() {
        return this.swift;
    }

    public void setSwift(String swift) {
        this.swift = swift;
    }
}
