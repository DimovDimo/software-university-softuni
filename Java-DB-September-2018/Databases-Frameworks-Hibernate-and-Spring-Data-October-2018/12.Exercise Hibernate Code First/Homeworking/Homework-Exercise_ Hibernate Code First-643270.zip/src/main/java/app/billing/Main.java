package app.billing;

import app.billing.entities.BankAccount;
import app.billing.entities.BillingDetail;
import app.billing.entities.CreditCard;
import app.billing.entities.User;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("billing");
        EntityManager em = emf.createEntityManager();

        System.out.println("Running ...");


        User pesho = new User();
        pesho.setFirstName("Pesho");
        pesho.setLastName("Mishov");
        pesho.setEmail("pesho@gmail.com");
        pesho.setPassword("Opalqnka");

        CreditCard card = new CreditCard();
        card.setCardType("visa");
        card.setExpirationMonth(10);
        card.setExpirationYear(2020);
        card.setNumber("12345");
        card.setOwner(pesho);

        BankAccount account = new BankAccount();
        account.setName("Amerika");
        account.setSwift("ABC123");
        account.setNumber("909090");
        account.setOwner(pesho);

        pesho.getBillingDetails().add(card);
        pesho.getBillingDetails().add(account);

        em.getTransaction().begin();
        em.persist(pesho);
        em.getTransaction().commit();

        em.clear();

        User testUser = em.find(User.class, 1L);
        testUser.getBillingDetails().forEach(b-> System.out.println(b.getNumber()));

        em.close();
        emf.close();
    }
}
