package cardealer.util.io.contract;

import java.io.IOException;

public interface FileUtil {
    String getFileContent(String filePath) throws IOException;
}
