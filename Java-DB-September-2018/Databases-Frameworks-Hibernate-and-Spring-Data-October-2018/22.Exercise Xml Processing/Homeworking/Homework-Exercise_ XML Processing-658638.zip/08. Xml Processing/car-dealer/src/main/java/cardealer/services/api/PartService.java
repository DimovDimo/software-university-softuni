package cardealer.services.api;

import cardealer.dto.binding.PartsWrapper;

public interface PartService {
    void saveParts(PartsWrapper models);
}
