package cardealer.services;


import cardealer.domain.dtos.seeddtos.CarImportDto;
import cardealer.domain.dtos.seeddtos.CarImportRootDto;
import cardealer.domain.entities.Car;
import cardealer.domain.entities.Part;
import cardealer.repositories.CarRepository;
import cardealer.repositories.PartRepository;
import cardealer.util.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service
public class CarServiceImpl implements CarService {
    private final String FILE_PATH_CARS="D:\\000000 PROGRAMMING COURSE\\03_JAVA DB FUNDAMENTALS-JANUARY_2018\\JAVA DB FRAMEWORKS-HIBERNATE&SPRING DATA\\JAVA DB FRAMEWORKS - NOVEMBER 2018\\11 XML PROCESSING\\Exercises\\Problem02_CarDealerDatabase\\src\\main\\resources\\files\\cars.xml";
   private final CarRepository carRepository;
   private final PartRepository partRepository;
   private final ValidatorUtil validatorUtil;
   private final ModelMapper modelMapper;

    public CarServiceImpl(CarRepository carRepository, PartRepository partRepository, ValidatorUtil validatorUtil, ModelMapper modelMapper) {
        this.carRepository = carRepository;
        this.partRepository = partRepository;
        this.validatorUtil = validatorUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public void seedCar() throws JAXBException {
        if(this.carRepository.count()!=0){
            return;
        }
        CarImportRootDto carImportRootDto = this.importCars();
        for (CarImportDto carImportDto : carImportRootDto.getCarImportDtos()) {
            if(!this.validatorUtil.isValid(carImportDto)){
                continue;
            }
            Car car=this.modelMapper.map(carImportDto,Car.class);
            List<Part> parts=this.getRandomListParts();
            car.setParts(parts);
            this.carRepository.saveAndFlush(car);
            System.out.println();
        }
    }

    private List<Part> getRandomListParts() {
        List<Part> parts=new ArrayList<>();
        Random random=new Random();
        int getCountParts=random.nextInt(10)+10;
        for (int i = 0; i <getCountParts ; i++) {
            int getRandomPart=random.nextInt((int)this.partRepository.count()-1)+1;
            Part part=this.partRepository.findAll().get(getRandomPart);
            parts.add(part);
        }

        return parts;
    }

    private CarImportRootDto importCars() throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(CarImportRootDto.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        File file=new File(FILE_PATH_CARS);
        CarImportRootDto  carImportRootDto= (CarImportRootDto) unmarshaller.unmarshal(file);
        return carImportRootDto;
    }

}

