package cardealer.config;

import cardealer.util.FileUtil;
import cardealer.util.FileUtilImpl;
import cardealer.util.ValidatorUtil;
import cardealer.util.ValidatorUtilImpl;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class ApplicationBeanConfiguration {

    @Bean
    public ModelMapper modelMapper(){
       return  new ModelMapper();
    }
    @Bean
    public FileUtil fileUtil(){
        return  new FileUtilImpl();
    }
    @Bean
    public ValidatorUtil validatorUtil() {
        return new ValidatorUtilImpl();
    }
}

