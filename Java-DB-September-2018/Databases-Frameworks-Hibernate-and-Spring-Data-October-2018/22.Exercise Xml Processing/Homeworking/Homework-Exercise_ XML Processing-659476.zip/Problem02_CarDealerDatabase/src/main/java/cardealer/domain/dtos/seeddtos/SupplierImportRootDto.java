package cardealer.domain.dtos.seeddtos;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "suppliers")
@XmlAccessorType(XmlAccessType.FIELD)
public class SupplierImportRootDto {

    @XmlElement(name="supplier")
    private SupplierImportDto[] suppliers;

    public SupplierImportRootDto() {
    }

    public SupplierImportDto[] getSuppliers() {
        return this.suppliers;
    }

    public void setSuppliers(SupplierImportDto[] suppliers) {
        this.suppliers = suppliers;
    }
}
