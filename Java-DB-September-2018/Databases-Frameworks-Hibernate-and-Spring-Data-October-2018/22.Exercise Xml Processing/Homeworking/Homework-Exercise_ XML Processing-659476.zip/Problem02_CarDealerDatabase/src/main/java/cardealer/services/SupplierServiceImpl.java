package cardealer.services;

import cardealer.domain.dtos.seeddtos.SupplierImportDto;
import cardealer.domain.dtos.seeddtos.SupplierImportRootDto;
import cardealer.domain.entities.Supplier;
import cardealer.repositories.SupplierReposiroy;
import cardealer.util.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;

@Service
public class SupplierServiceImpl implements SupplierService {
    private final String PATH_FILE_SUPPLIER="D:\\000000 PROGRAMMING COURSE\\03_JAVA DB FUNDAMENTALS-JANUARY_2018\\JAVA DB FRAMEWORKS-HIBERNATE&SPRING DATA\\JAVA DB FRAMEWORKS - NOVEMBER 2018\\11 XML PROCESSING\\Exercises\\Problem02_CarDealerDatabase\\src\\main\\resources\\files\\suppliers.xml";
   private final ValidatorUtil validationUtil;
    private final ModelMapper modelMapper;
    private final SupplierReposiroy supplierRepsoritory;

    @Autowired
    public SupplierServiceImpl(ValidatorUtil validationUtil, ModelMapper modelMapper, SupplierReposiroy supplierRepsoritory) {
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
        this.supplierRepsoritory = supplierRepsoritory;
    }

    private SupplierImportRootDto importSuplier() throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(SupplierImportRootDto.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        File file=new File(PATH_FILE_SUPPLIER);
        SupplierImportRootDto supplierImportDto = (SupplierImportRootDto) unmarshaller.unmarshal(file);
        return supplierImportDto;
    }

    @Override
    public void seedSupplier() throws JAXBException {
        if(this.supplierRepsoritory.count()!=0){
            return;
        }
        SupplierImportRootDto supplierImportRootDto=this.importSuplier();
        for (SupplierImportDto supplier : supplierImportRootDto.getSuppliers()) {
            if (!this.validationUtil.isValid(supplier)) {
                System.out.println("Something went wrong");

                continue;
            }
            Supplier suppliers=this.modelMapper.map(supplier,Supplier.class);
            this.supplierRepsoritory.saveAndFlush(suppliers);
        }

        System.out.println();
    }
}
