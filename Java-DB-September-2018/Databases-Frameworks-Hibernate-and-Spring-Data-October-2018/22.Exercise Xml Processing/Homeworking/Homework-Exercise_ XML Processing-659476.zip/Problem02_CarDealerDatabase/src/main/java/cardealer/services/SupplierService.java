package cardealer.services;

import cardealer.domain.dtos.seeddtos.SupplierImportRootDto;

import javax.xml.bind.JAXBException;

public interface SupplierService {
    void seedSupplier() throws JAXBException;
}
