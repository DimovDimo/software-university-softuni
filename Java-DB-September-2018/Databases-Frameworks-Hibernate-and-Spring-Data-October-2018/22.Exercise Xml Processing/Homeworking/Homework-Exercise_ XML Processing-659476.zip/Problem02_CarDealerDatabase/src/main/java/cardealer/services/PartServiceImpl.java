package cardealer.services;

import cardealer.domain.dtos.seeddtos.PartImportDto;
import cardealer.domain.dtos.seeddtos.PartImportRootDto;
import cardealer.domain.entities.Part;
import cardealer.domain.entities.Supplier;
import cardealer.repositories.PartRepository;
import cardealer.repositories.SupplierReposiroy;
import cardealer.util.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.Random;

@Service
public class PartServiceImpl implements PartService {
    private final String PATH_FILE_PART="D:\\000000 PROGRAMMING COURSE\\03_JAVA DB FUNDAMENTALS-JANUARY_2018\\JAVA DB FRAMEWORKS-HIBERNATE&SPRING DATA\\JAVA DB FRAMEWORKS - NOVEMBER 2018\\11 XML PROCESSING\\Exercises\\Problem02_CarDealerDatabase\\src\\main\\resources\\files\\parts.xml";
    private final ValidatorUtil validationUtil;
    private final ModelMapper modelMapper;
    private final PartRepository partRepository;
    private final SupplierReposiroy supplierRepository;

    @Autowired
    public PartServiceImpl(ValidatorUtil validationUtil, ModelMapper modelMapper, PartRepository partRepository, SupplierReposiroy supplierRepository) {
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
        this.partRepository = partRepository;
        this.supplierRepository = supplierRepository;
    }

    @Override
    public void seedPart() throws JAXBException {
        if(this.partRepository.count()!=0){
            return;
        }
        PartImportRootDto partImportRootDtos=this.importPart();
        for (PartImportDto partImportDto : partImportRootDtos.getPartImportDtos()) {
            if (!this.validationUtil.isValid(partImportDto)) {
                System.out.println("Something went wrong");

                continue;
            }
            Part part=this.modelMapper.map(partImportDto,Part.class);
            Supplier supplier=this.gerRandomSupplier();
            part.setSupplier(supplier);
            this.partRepository.saveAndFlush(part);
        }
    }

    private Supplier gerRandomSupplier() {
        Random random=new Random();
        int idRandomSupplier=random.nextInt((int)this.supplierRepository.count() - 1)+1;
        return this.supplierRepository.findById(idRandomSupplier).orElse(null);
    }

    private PartImportRootDto importPart() throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(PartImportRootDto.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        File file=new File(PATH_FILE_PART);
        PartImportRootDto partImportRootDto = (PartImportRootDto) unmarshaller.unmarshal(file);
        return partImportRootDto;
    }
}
