package cardealer.domain.entities;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity(name="sales")
public class Sale extends BaseEntity {
    private BigDecimal discount;
    private Car car;
    private Customer customer;

    public Sale() {
    }

    @Column(name="discount")
    public BigDecimal getDiscount() {
        return this.discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    @OneToOne
    @JoinColumn(name="car_id",referencedColumnName = "id")
    public Car getCar() {
        return this.car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    @ManyToOne()
    @JoinColumn(name="customer_id",referencedColumnName = "id")
    public Customer getCustomer() {
        return this.customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
