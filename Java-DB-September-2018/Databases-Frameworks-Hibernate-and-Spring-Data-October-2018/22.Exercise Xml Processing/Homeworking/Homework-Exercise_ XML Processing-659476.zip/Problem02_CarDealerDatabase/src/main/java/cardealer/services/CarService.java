package cardealer.services;

import javax.xml.bind.JAXBException;

public interface CarService {
    void seedCar() throws JAXBException;
}
