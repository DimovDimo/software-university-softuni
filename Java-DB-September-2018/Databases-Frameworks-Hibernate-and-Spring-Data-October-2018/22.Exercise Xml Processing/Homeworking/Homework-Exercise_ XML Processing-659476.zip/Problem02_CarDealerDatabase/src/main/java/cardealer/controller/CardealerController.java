package cardealer.controller;

import cardealer.services.CarService;
import cardealer.services.PartService;
import cardealer.services.SupplierService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;

import javax.xml.bind.JAXBException;
import java.util.Random;


@Controller
public class CardealerController implements CommandLineRunner {
     private final SupplierService supplierService;
     private final PartService partService;
     private final CarService carService;

    public CardealerController(SupplierService supplierService, PartService partService, CarService carService) {
        this.supplierService = supplierService;
        this.partService = partService;
        this.carService = carService;
    }

    @Override
    public void run(String... args) throws Exception {
        this.seedSupplier();
        this.seedPart();
        this.seedCar();
    }

    private void seedCar() throws JAXBException {
        this.carService.seedCar();
    }

    private void seedPart() throws JAXBException {
        this.partService.seedPart();
    }

    private void seedSupplier() throws JAXBException {
        this.supplierService.seedSupplier();
    }
}
