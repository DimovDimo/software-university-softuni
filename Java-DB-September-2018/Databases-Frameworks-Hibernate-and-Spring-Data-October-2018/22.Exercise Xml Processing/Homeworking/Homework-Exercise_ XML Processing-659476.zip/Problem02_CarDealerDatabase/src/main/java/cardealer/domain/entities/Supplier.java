package cardealer.domain.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import java.util.List;

@Entity(name="suppliers")
public class Supplier extends BaseEntity {
    private String name;
    private String isImporter;
    private List<Part> parts;

    public Supplier() {
    }

    @Column(name="name")
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name="is_importer")
    public String getImporter() {
        return this.isImporter;
    }

    public void setImporter(String importer) {
        isImporter = importer;
    }

    @OneToMany(mappedBy = "supplier",targetEntity = Part.class)
    public List<Part> getParts() {
        return this.parts;
    }

    public void setParts(List<Part> parts) {
        this.parts = parts;
    }
}
