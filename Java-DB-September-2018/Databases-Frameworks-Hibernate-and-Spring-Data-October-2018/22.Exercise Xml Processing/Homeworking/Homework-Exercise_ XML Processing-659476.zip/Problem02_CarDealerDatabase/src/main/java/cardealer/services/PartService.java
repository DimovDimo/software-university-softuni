package cardealer.services;

import javax.xml.bind.JAXBException;

public interface PartService {
    void seedPart() throws JAXBException;
}
