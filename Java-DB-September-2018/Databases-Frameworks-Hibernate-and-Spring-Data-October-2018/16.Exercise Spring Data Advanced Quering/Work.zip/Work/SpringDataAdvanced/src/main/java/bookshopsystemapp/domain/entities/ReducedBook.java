package bookshopsystemapp.domain.entities;

public interface ReducedBook {

    String getTitle();

    String getEditionType();

    String getRestrictionType();

    String getPrice();
}
