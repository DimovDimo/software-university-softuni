package bookshopsystemapp.service;

import bookshopsystemapp.domain.entities.*;
import bookshopsystemapp.repository.AuthorRepository;
import bookshopsystemapp.repository.BookRepository;
import bookshopsystemapp.repository.CategoryRepository;
import bookshopsystemapp.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Transactional
public class BookServiceImpl implements BookService {

    private final static String BOOKS_FILE_PATH = "C:\\Main\\Software-University-SoftUni\\Java-DB-September-2018\\Databases-Frameworks-Hibernate-and-Spring-Data-October-2018\\16.Exercise Spring Data Advanced Quering\\Work\\SpringDataAdvanced\\src\\main\\resources\\files\\books.txt";

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;
    private final CategoryRepository categoryRepository;
    private final FileUtil fileUtil;

    @Autowired
    public BookServiceImpl(BookRepository bookRepository, AuthorRepository authorRepository, CategoryRepository categoryRepository, FileUtil fileUtil) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
        this.categoryRepository = categoryRepository;
        this.fileUtil = fileUtil;
    }

    @Override
    public void seedBooks() throws IOException {
        if (this.bookRepository.count() != 0) {
            return;
        }

        String[] booksFileContent = this.fileUtil.getFileContent(BOOKS_FILE_PATH);
        for (String line : booksFileContent) {
            String[] lineParams = line.split("\\s+");

            Book book = new Book();
            book.setAuthor(this.getRandomAuthor());

            EditionType editionType = EditionType.values()[Integer.parseInt(lineParams[0])];
            book.setEditionType(editionType);

            LocalDate releaseDate = LocalDate.parse(lineParams[1], DateTimeFormatter.ofPattern("d/M/yyyy"));
            book.setReleaseDate(releaseDate);

            int copies = Integer.parseInt(lineParams[2]);
            book.setCopies(copies);

            BigDecimal price = new BigDecimal(lineParams[3]);
            book.setPrice(price);

            AgeRestriction ageRestriction = AgeRestriction.values()[Integer.parseInt(lineParams[4])];
            book.setAgeRestriction(ageRestriction);

            StringBuilder title = new StringBuilder();
            for (int i = 5; i < lineParams.length; i++) {
                title.append(lineParams[i]).append(" ");
            }

            book.setTitle(title.toString().trim());

            Set<Category> categories = this.getRandomCategories();
            book.setCategories(categories);

            this.bookRepository.saveAndFlush(book);
        }
    }

    @Override
    public List<String> getAllBooksTitlesAfter() {
        List<Book> books = this.bookRepository.findAllByReleaseDateAfter(LocalDate.parse("2000-12-31"));

        return books.stream().map(b -> b.getTitle()).collect(Collectors.toList());
    }

    @Override
    public Set<String> getAllAuthorsWithBookBefore() {
        List<Book> books = this.bookRepository.findAllByReleaseDateBefore(LocalDate.parse("1990-01-01"));

        return books.stream().map(b -> String.format("%s %s", b.getAuthor().getFirstName(), b.getAuthor().getLastName())).collect(Collectors.toSet());
    }

    @Override
    public List<String> booksTitlesByAgeRestriction(String ageRestrictionInput) {
        AgeRestriction ageRestriction = AgeRestriction.valueOf(ageRestrictionInput.toUpperCase());
        List<Book> books = this.bookRepository.findAllByAgeRestriction(ageRestriction);

        return books.stream().map(Book::getTitle).collect(Collectors.toList());
    }

    @Override
    public List<String> goldenBooksLessThan5KCopies() {
        EditionType editionType = EditionType.GOLD;
        int copies = 5000;
        List<Book> books = this.bookRepository.findAllByeditionTypeAndCopiesLessThan(editionType, copies);

        return books.stream().map(Book::getTitle).collect(Collectors.toList());
    }

    @Override
    public List<Book> booksTitlesByPriceLessThanOrPriceGreaterThan() {
        BigDecimal less = BigDecimal.valueOf(5);
        BigDecimal greater = BigDecimal.valueOf(40);
        return this.bookRepository.findAllByPriceLessThanOrPriceGreaterThan(less, greater);
    }

    @Override
    public List<String> booksTitlesNotReleasedBooksInAGivenYear(String yearAsString) {
        LocalDate before = LocalDate.parse(yearAsString + "-01-01");
        LocalDate after = LocalDate.parse(yearAsString + "-12-31");
        List<Book> books = this.bookRepository
                .findAllByReleaseDateBeforeOrReleaseDateAfter(before, after);

        return books.stream().map(Book::getTitle).collect(Collectors.toList());
    }

    @Override
    public String titleReleasedBeforeDate(String dateAsString) {
        LocalDate before = LocalDate.parse(dateAsString, DateTimeFormatter.ofPattern("dd-MM-yyyy"));

        return this.bookRepository
                .findAllByReleaseDateBefore(before)
                .stream()
                .map(Book::getTitle)
                .collect(Collectors.joining(System.lineSeparator()));
    }

    @Override
    public String titleContains(String targetString) {
        return this.bookRepository
                .findAllByTitleContains(targetString).stream()
                .map(Book::getTitle)
                .collect(Collectors.joining(System.lineSeparator()));
    }

    @Override
    public String titleWrittenByAuthorsWhoseLastNameStartsWithAGivenString(String startOfName) {
        return this.getResult(this.bookRepository
                .findBookByAuthorLastNameStartsWith(startOfName)
                .stream()
                .map(book -> String.format("%s (%s %s)",
                        book.getTitle(),
                        book.getAuthor().getFirstName(),
                        book.getAuthor().getLastName()))
        );
    }

    @Override
    public int countOfBooksWithTitleLengthLongerThan(String numberInput){
        int number = Integer.parseInt(numberInput);
        return this.bookRepository
                .numberOfBooksWithTitlesLongerThan(number);
    }

    @Override
    public String totalNumberOfCopiesByAuthor() {
        return this.getResult(this.bookRepository
                .totalNumberOfCopiesByAuthor()
                .map(o -> String.format("%s %s - %s",
                        o[0], o[1], o[2]))
        );
    }

    @Override
    public String reduceBook(String title){

        List<ReducedBook> reducedBooks = fillReducedBooks(title);

        if (reducedBooks.size() == 0){
            return "The title does not found.";
        }

        return this.getResult(this.bookRepository
                .reducedBook(title)
                .map(o -> String.format("%s %s %s %s", o[0], o[1], o[2], o[3]))
        );
    }

    private List<ReducedBook> fillReducedBooks(String title) {
        return this.bookRepository.reducedBook(title)
                    .map(ob -> new ReducedBook() {
                        @Override
                        public String getTitle() {
                            return ob[0].toString();
                        }

                        @Override
                        public String getEditionType() {
                            return ob[1].toString();
                        }

                        @Override
                        public String getRestrictionType() {
                            return ob[2].toString();
                        }

                        @Override
                        public String getPrice() {
                            return ob[3].toString();
                        }
                    })
                    .collect(Collectors.toList());
    }

    private Author getRandomAuthor() {
        Random random = new Random();

        int randomId = random.nextInt((int) (this.authorRepository.count() - 1)) + 1;

        return this.authorRepository.findById(randomId).orElse(null);
    }

    private Set<Category> getRandomCategories() {
        Set<Category> categories = new LinkedHashSet<>();

        Random random = new Random();
        int length = random.nextInt(5);

        for (int i = 0; i < length; i++) {
            Category category = this.getRandomCategory();

            categories.add(category);
        }

        return categories;
    }

    private Category getRandomCategory() {
        Random random = new Random();

        int randomId = random.nextInt((int) (this.categoryRepository.count() - 1)) + 1;

        return this.categoryRepository.findById(randomId).orElse(null);
    }

    private String getResult(Stream<String> stream){
        StringBuilder builder = new StringBuilder();
        stream.forEach(s -> builder.append(s).append(System.lineSeparator()));
        return builder.toString().trim();
    }
}
