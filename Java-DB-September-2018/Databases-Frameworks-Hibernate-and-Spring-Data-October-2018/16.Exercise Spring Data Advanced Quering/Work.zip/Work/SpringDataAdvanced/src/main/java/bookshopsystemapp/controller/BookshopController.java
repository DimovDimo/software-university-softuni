package bookshopsystemapp.controller;

import bookshopsystemapp.service.AuthorService;
import bookshopsystemapp.service.BookService;
import bookshopsystemapp.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

@Controller
public class BookshopController implements CommandLineRunner {

    private final AuthorService authorService;
    private final CategoryService categoryService;
    private final BookService bookService;

    private Scanner scannner = new Scanner(System.in);

    @Autowired
    public BookshopController(AuthorService authorService, CategoryService categoryService, BookService bookService) {
        this.authorService = authorService;
        this.categoryService = categoryService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... strings) throws Exception {
        this.authorService.seedAuthors();
        this.categoryService.seedCategories();
        this.bookService.seedBooks();

        this.printRemoveComments();
        /**
         * Remove this comments.
         */
//        this.booksTitlesByAgeRestriction();
//        this.goldenBooksLessThan5KCopies();
//        this.booksByPrice();
//        this.notReleasedBooks();
//        this.booksReleasedBeforeDate();
//        this.authorsSearchFirstNameEndsWithAGivenString();
//        this.booksSearchTitlesWhichContainAGivenString();
//        this.booksTitlesSearchWrittenByAuthorsWhoseLastNameStartsWithAGivenString();
//        this.countOfBooksWithTitleLengthLongerThan();
//        this.totalBookCopies();
//        this.reducedBook();
    }

    private void printRemoveComments(){
        System.out.println("Go to BookshopController, remove comments and start the methods for the problems.");
    }

    /**
     *  1. Books Titles by Age Restriction
     * Write a program that prints the titles of all books, for which the age restriction matches the given input (minor,
     * teen or adult). Ignore casing of the input.
     */
    private void booksTitlesByAgeRestriction(){
        System.out.println("Problem 1. Books Titles by Age Restriction");
        System.out.print("Insert age restriction: ");
        String ageRestriction = this.scannner.nextLine();
        this.bookService
                .booksTitlesByAgeRestriction(ageRestriction)
                .forEach(System.out::println);
    }

    /**
     * 2. Golden Books
     * Write a program that prints the titles of the golden edition books, which have less than 5000 copies.
     */
    private void goldenBooksLessThan5KCopies(){
        System.out.println("Problem 2. Golden Books");
        this.bookService
                .goldenBooksLessThan5KCopies()
                .forEach(System.out::println);
    }

    /**
     * 3. Books by Price
     * Write a program that prints the titles and prices of books with price lower than 5 and higher than 40.
     */
    private void booksByPrice(){
        System.out.println("Problem 3. Books by Price");
        this.bookService
                .booksTitlesByPriceLessThanOrPriceGreaterThan()
                .forEach(b ->
                        System.out.printf("%s - %.2f%n",
                                b.getTitle(),
                                b.getPrice()));
    }

    /**
     * 4. Not Released Books
     * Write a program that prints the titles of all books that are NOT released in a given year.
     */
    private void notReleasedBooks(){
        System.out.println("Problem 4. Not Released Books");
        System.out.printf("Insert not released year: ");
        String yearAsString = this.scannner.nextLine();
        this.bookService
                .booksTitlesNotReleasedBooksInAGivenYear(yearAsString)
                .forEach(System.out::println);
    }

    /**
     * 5. Books Released Before Date
     * Write a program that prints the title, the edition type and the price of books, which are released before a given
     * date. The date will be in the format dd-MM-yyyy
     */
    private void booksReleasedBeforeDate(){
        System.out.println("Problem 5. Books Released Before Date");
        System.out.print("Insert not released year: ");
        String dateAsString = this.scannner.nextLine();
        System.out.println(
                this.bookService
                    .titleReleasedBeforeDate(dateAsString)
        );
    }

    /**
     * 6. Authors Search
     * Write a program that prints the names of those authors, whose first name ends with a given string.
     */
    private void authorsSearchFirstNameEndsWithAGivenString(){
        System.out.println("Problem 6. Authors Search");
        System.out.print("Insert first name ends with: ");
        String endOfName = this.scannner.nextLine();
        System.out.println(
                this.authorService
                        .authorsSearchFirstNameEndsWithAGivenString(endOfName)
        );
    }

    /**
     * 7. Books Search
     * Write a program that prints the titles of books, which contain a given string (regardless of the casing).
     */
    private void booksSearchTitlesWhichContainAGivenString(){
        System.out.println("Problem 7. Books Search");
        System.out.print("Insert books search titles which contain a given string: ");
        String targetString = this.scannner.nextLine();
        System.out.println(
                this.bookService
                        .titleContains(targetString)
        );
    }

    /**
     * 8. Book Titles Search
     * Write a program that prints the titles of books, which are written by authors, whose last name starts with a given
     * string
     */
    private void booksTitlesSearchWrittenByAuthorsWhoseLastNameStartsWithAGivenString(){
        System.out.println("Problem 8. Book Titles Search");
        System.out.print("Insert last name starts with: ");
        String startOfName = this.scannner.nextLine();
        System.out.println(
                this.bookService
                        .titleWrittenByAuthorsWhoseLastNameStartsWithAGivenString(startOfName)
        );
    }

    /**
     * 9. Count Books
     * Write a program that prints the number of books, whose title is longer than a given number.
     */
    public void countOfBooksWithTitleLengthLongerThan(){
        System.out.println("Problem 9. Count Books");
        System.out.print("Insert title length: ");
        String numberString = this.scannner.nextLine();
        System.out.println(
                this.bookService
                    .countOfBooksWithTitleLengthLongerThan(numberString)
        );
    }

    /**
     * 10. Total Book Copies
     * Write a program that prints the total number of book copies by author. Order the results descending by total book
     * copies.
     */
    public void totalBookCopies(){
        System.out.println("Problem 10. Total Book Copies");
        System.out.println(
                this.bookService.totalNumberOfCopiesByAuthor()
        );
    }

    /**
     * 11. Reduced Book
     * Write a program that prints information (title, edition type, age restriction and price) for a book by given title.
     * When retrieving the book information select only those fields and do NOT include any other information in the
     * returned result.
     *
     * Hints
     * You must create a projection of the book class omitting the not required fields.
     * 1. Create an interface ReducedBook with properties for title, edition type, age restriction and price.
     * 2. In the books repository create query method that would return ReducedBook by given title.
     * © Software University Foundation. This work is licensed under the CC-BY-NC-SA license.
     *
     * Follow us: Page 4 of 4
     * 3. Use that method in the BookService class.
     * 4. Use the BookService to retrieve instance of that object and print its information.
     */
    public void reducedBook(){
        System.out.println("Problem 11. Reduced Book");
        System.out.print("Insert title: ");
        String title = this.scannner.nextLine();
        System.out.println(
                this.bookService.reduceBook(title)
        );
    }
}
