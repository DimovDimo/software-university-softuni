package bookshopsystemapp.repository;

import bookshopsystemapp.domain.entities.AgeRestriction;
import bookshopsystemapp.domain.entities.Author;
import bookshopsystemapp.domain.entities.Book;
import bookshopsystemapp.domain.entities.EditionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Stream;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {

    List<Book> findAllByReleaseDateAfter(LocalDate date);

    List<Book> findAllByReleaseDateBefore(LocalDate date);

    List<Book> findAllByAgeRestriction(AgeRestriction ageRestriction);

    List<Book> findAllByeditionTypeAndCopiesLessThan(EditionType editionType, int copies);

    List<Book> findAllByPriceLessThanOrPriceGreaterThan(BigDecimal upper, BigDecimal lower);

    List<Book> findAllByReleaseDateBeforeOrReleaseDateAfter(LocalDate before, LocalDate after);

    List<Book> findAllByTitleContains(String targetString);

    List<Book> findBookByAuthorLastNameStartsWith(String startOfName);

    @Query("SELECT COUNT(b) FROM bookshopsystemapp.domain.entities.Book AS b WHERE LENGTH(b.title) > :number")
    int numberOfBooksWithTitlesLongerThan(@Param(value = "number") int number);

    @Query("SELECT " +
                "b.author.firstName, " +
                "b.author.lastName, " +
                "SUM(b.copies) AS sum_o_copies " +
            "FROM bookshopsystemapp.domain.entities.Book AS b " +
            "group by b.author " +
            "order by sum(b.copies) desc")
    Stream<Object[]> totalNumberOfCopiesByAuthor();

    @Query("SELECT " +
                "b.title, " +
                "b.editionType, " +
                "b.ageRestriction, " +
                "b.price " +
            "FROM bookshopsystemapp.domain.entities.Book AS b " +
            "WHERE b.title = :title")
    Stream<Object[]> reducedBook(@Param(value = "title") String title);
}
