package bookshopsystemapp.service;


import bookshopsystemapp.domain.entities.Book;

import java.io.IOException;
import java.util.List;
import java.util.Set;

public interface BookService {

    void seedBooks() throws IOException;

    List<String> getAllBooksTitlesAfter();

    Set<String> getAllAuthorsWithBookBefore();

    List<String> booksTitlesByAgeRestriction(String ageRestriction);

    List<String> goldenBooksLessThan5KCopies();

    List<Book> booksTitlesByPriceLessThanOrPriceGreaterThan();

    List<String> booksTitlesNotReleasedBooksInAGivenYear(String yearAsString);

    String titleReleasedBeforeDate(String dateAsString);

    String titleContains(String targetString);

    String titleWrittenByAuthorsWhoseLastNameStartsWithAGivenString(String startOfName);

    int countOfBooksWithTitleLengthLongerThan(String numberInput);

    String totalNumberOfCopiesByAuthor();

    String reduceBook(String title);
}
