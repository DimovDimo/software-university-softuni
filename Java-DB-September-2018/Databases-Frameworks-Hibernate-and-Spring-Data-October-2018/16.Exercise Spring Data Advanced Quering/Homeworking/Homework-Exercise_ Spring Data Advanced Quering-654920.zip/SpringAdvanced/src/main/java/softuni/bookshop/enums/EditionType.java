package softuni.bookshop.enums;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
