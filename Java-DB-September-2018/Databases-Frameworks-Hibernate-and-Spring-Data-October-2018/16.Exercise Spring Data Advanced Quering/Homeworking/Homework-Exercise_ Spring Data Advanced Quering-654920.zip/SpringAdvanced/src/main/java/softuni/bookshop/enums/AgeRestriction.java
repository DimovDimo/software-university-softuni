package softuni.bookshop.enums;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
