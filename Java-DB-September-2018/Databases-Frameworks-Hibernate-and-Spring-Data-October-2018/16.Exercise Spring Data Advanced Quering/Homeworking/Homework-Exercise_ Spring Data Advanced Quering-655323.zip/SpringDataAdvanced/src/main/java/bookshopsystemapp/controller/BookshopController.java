package bookshopsystemapp.controller;

import bookshopsystemapp.service.AuthorService;
import bookshopsystemapp.service.BookService;
import bookshopsystemapp.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;

import java.io.InputStream;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

@Controller
public class BookshopController implements CommandLineRunner {

    private final AuthorService authorService;
    private final CategoryService categoryService;
    private final BookService bookService;
    private Scanner scanner;

    @Autowired
    public BookshopController(AuthorService authorService, CategoryService categoryService, BookService bookService) {
        this.authorService = authorService;
        this.categoryService = categoryService;
        this.bookService = bookService;
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void run(String... strings) throws Exception {
        // this.authorService.seedAuthors();
        // this.categoryService.seedCategories();
        // this.bookService.seedBooks();

        // this.bookTitlesByAgeRestriction();
        // this.goldenBooksTitlesWithLessThan5000Copies();
        // this.booksByPriceLowerBy5GreaterBy40();
        // this.notReleasedBooks();
        // this.booksReleasedBeforeDate();
        // this.authorsNameSearchByEndString();
        // this.booksTitleContainingString();
        // this.booksTitleWhoseLastNameStartsWith();
        // this.countBooksTitleLongerThan();
        // this.totalNumberOfBookCopiesByAuthor();
        // this.totalNumberOfBookCopiesByAuthor();
        // this.reducedBook();
        // this.increaseBookCopies();
        // this.removeBooksByCopies();

    }

    /**
     * 2
     * 1.	Books Titles by Age Restriction
     */
    private void bookTitlesByAgeRestriction() {
        System.out.println("FEED ME DATA PLEASE!");
        String ageRestrictionStr = scanner.nextLine();

        this.bookService.getAllBookTitlesByAgeRestriction(ageRestrictionStr).forEach(System.out::println);
    }

    /**
     * 2.	Golden Books
     */
    private void goldenBooksTitlesWithLessThan5000Copies() {
        this.bookService.getAllGoldenBooksTitlesWithLessThan5000Copies().forEach(System.out::println);
    }

    /**
     * 3.	Books by Price
     */
    private void booksByPriceLowerBy5GreaterBy40() {
        System.out.println(this.bookService.getBooksByPriceLowerBy5GreaterBy40());
    }

    /**
     * 4.	Not Released Books
     */
    private void notReleasedBooks() {
        System.out.println("FEED ME DATA PLEASE!");
        int year = Integer.parseInt(scanner.nextLine());
        this.bookService.getBooksTitleNotReleasedOnGivenYear(year).forEach(System.out::println);
    }

    /**
     * 5.	Books Released Before Date
     */
    private void booksReleasedBeforeDate() {
        System.out.println("FEED ME DATA PLEASE!");
        String date = scanner.nextLine();
        this.bookService.getBooksReleasedBeforeDate(date).forEach(System.out::println);
    }

    /**
     * 6.	Authors Search
     */
    private void authorsNameSearchByEndString() {
        System.out.println("FEED ME DATA PLEASE!");
        String ending = scanner.nextLine();
        this.authorService.getAuthorsFirstNamesEndingWith(ending).forEach(System.out::println);
    }

    /**
     * 7.	Books Search
     */
    private void booksTitleContainingString() {
        System.out.println("FEED ME DATA PLEASE!");
        String str = scanner.nextLine();
        this.bookService.getBooksTitlesContainingString(str).forEach(System.out::println);
    }

    /**
     * 8.	Book Titles Search
     */
    private void booksTitleWhoseLastNameStartsWith() {
        System.out.println("FEED ME DATA PLEASE!");
        String str = scanner.nextLine();
        this.bookService.getBooksTitlesWithLastNameEndingWith(str).forEach(System.out::println);
    }

    /**
     * 9.	Count Books
     */
    private void countBooksTitleLongerThan() {
        System.out.println("FEED ME DATA PLEASE!");
        int titleLength = Integer.parseInt(scanner.nextLine());
        System.out.println(this.bookService.getCountOfBooksTitlesLongerThan(titleLength));
    }

    /**
     * 10.	Total Book Copies
     */
    private void totalNumberOfBookCopiesByAuthor() {
        this.authorService.getTotalNumberOfBookCopiesByAuthor().forEach(System.out::println);
    }

    /**
     * 11.	Reduced Book
     */
    private void reducedBook() {
        System.out.println("FEED ME DATA PLEASE!");
        String title = scanner.nextLine();
        System.out.println(this.bookService.getReducedBookByTitle(title));
    }

    /**
     * 12.	* Increase Book Copies
     */
    private void increaseBookCopies() {
        System.out.println("FEED ME DATA PLEASE!");
        String date = scanner.nextLine();
        int num = Integer.parseInt(scanner.nextLine());

        System.out.println(this.bookService.increaseBookCopiesAfterGivenDate(date, num));
    }

    /**
     * 13.	* Remove Books
     */
    private void removeBooksByCopies() {
        System.out.println("FEED ME DATA PLEASE!");
        int num = Integer.parseInt(scanner.nextLine());

        System.out.println(this.bookService.removeBooksWithCopiesLowerThan(num));
    }

}
