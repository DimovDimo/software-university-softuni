package bookshopsystemapp.repository;

import bookshopsystemapp.domain.entities.AgeRestriction;
import bookshopsystemapp.domain.entities.Book;
import bookshopsystemapp.domain.entities.EditionType;

import bookshopsystemapp.domain.entities.ReducedBook;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {

    List<Book> findAllByReleaseDateAfter(LocalDate date);

    List<Book> findAllByReleaseDateBefore(LocalDate date);

    List<Book> findAllByAgeRestriction(AgeRestriction ageRestriction);

    List<Book> getBooksByEditionTypeIsAndCopiesLessThan(EditionType editionType, Integer targetNumberOfCopies);

    List<Book> findAllByPriceLessThanOrPriceGreaterThan(BigDecimal lessThan, BigDecimal greaterThan);

    @Query("SELECT b FROM bookshopsystemapp.domain.entities.Book AS b WHERE FUNCTION('YEAR', b.releaseDate) <> :year")
    List<Book> getBooksByReleaseDateNot(@Param("year") int year);

    List<Book> getBooksByReleaseDateBefore(LocalDate date);

    List<Book> getBooksByTitleContaining(String str);

    @Query("SELECT b FROM bookshopsystemapp.domain.entities.Book AS b WHERE b.author.lastName LIKE :startsWith% ORDER BY b.author.lastName ASC")
    List<Book> getBooksByAuthorLastNameStartsWith(@Param("startsWith") String str);

    @Query("SELECT COUNT(b) FROM bookshopsystemapp.domain.entities.Book AS b WHERE LENGTH(b.title) > :titleLength ")
    Integer getCountOfBooksWithTitlesLongerThan(@Param("titleLength") int length);

    @Query("SELECT new bookshopsystemapp.domain.entities.ReducedBook(b.title, b.editionType, b.ageRestriction, b.price) FROM bookshopsystemapp.domain.entities.Book AS b WHERE b.title = :targetTitle")
    ReducedBook getReducedBooks(@Param("targetTitle") String title);

    @Transactional
    @Modifying
    @Query("UPDATE bookshopsystemapp.domain.entities.Book AS b SET b.copies = b.copies + :increase WHERE b.id=:id")
    void increaseCopiesForBooks(@Param("increase") int id, @Param("id") int num);

    @Transactional
    @Modifying
    @Query("DELETE FROM bookshopsystemapp.domain.entities.Book AS b WHERE b.copies < :num")
    Integer removeBooksWithCopiesLowerThan(@Param("num") int num);


}
