package bookshopsystemapp.service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public interface BookService {

    void seedBooks() throws IOException;

    List<String> getAllBooksTitlesAfter();

    Set<String> getAllAuthorsWithBookBefore();

    List<String> getAllBookTitlesByAgeRestriction(String ageRestriction);

    List<String> getAllGoldenBooksTitlesWithLessThan5000Copies();

    String getBooksByPriceLowerBy5GreaterBy40();

    List<String> getBooksTitleNotReleasedOnGivenYear(int year);

    List<String> getBooksReleasedBeforeDate(String date);

    List<String> getBooksTitlesContainingString(String str);

    List<String> getBooksTitlesWithLastNameEndingWith(String str);

    Integer getCountOfBooksTitlesLongerThan(int titleLength);

    String getReducedBookByTitle(String title);

    Integer increaseBookCopiesAfterGivenDate(String date, int num);

    String removeBooksWithCopiesLowerThan(int num);

}
