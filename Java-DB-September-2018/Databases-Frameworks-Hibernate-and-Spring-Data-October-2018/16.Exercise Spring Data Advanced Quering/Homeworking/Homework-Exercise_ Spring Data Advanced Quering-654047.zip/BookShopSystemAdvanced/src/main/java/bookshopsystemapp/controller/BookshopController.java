package bookshopsystemapp.controller;

import bookshopsystemapp.service.AuthorService;
import bookshopsystemapp.service.BookService;
import bookshopsystemapp.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;

import javax.persistence.criteria.CriteriaBuilder;
import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

@Controller
public class BookshopController implements CommandLineRunner {

    private final AuthorService authorService;
    private final CategoryService categoryService;
    private final BookService bookService;

    @Autowired
    public BookshopController(AuthorService authorService, CategoryService categoryService, BookService bookService) {
        this.authorService = authorService;
        this.categoryService = categoryService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... strings) throws Exception {
        Scanner scanner = new Scanner(System.in);

        /* PROBLEM 1
         String line = scanner.nextLine();
        List<String> result = this.bookService.getAllBooksWithAgeRestriction(line.toUpperCase());
         result.forEach(System.out::println);
        */

        /* PROBLEM 2
         List<String> result = this.bookService.getAllByCopiesIsLessThanAndEditionType(5000, "GOLD");
         result.forEach(System.out::println);
        */

        /* PROBLEM 3
       List<String> result = this.bookService.getAllByPriceLessThanOrPriceGreaterThan(BigDecimal.valueOf(4), BigDecimal.valueOf(40));
        result.forEach(System.out::println);
        */

        /* PROBLEM 4
        String year = scanner.nextLine();
        List<String> result = this.bookService.getNotReleasedBooks(year);
        result.forEach(System.out::println);
        */

        /* PROBLEM 5
        String date = scanner.nextLine();
        List<String> result = this.bookService.getAllBooksWithReleaseDateBefore(date);
        result.forEach(System.out::println);
        */

        /* PROBLEM 6
        String line = scanner.nextLine();
        List<String> result = this.authorService.getAllAuthorsByFirstNameEndingWith(line);
        result.forEach(System.out::println);
        */

        /* PROBLEM 7
        String line = scanner.nextLine();
        List<String> result = this.bookService.getAllBooksByTitleContaining(line.toLowerCase());
        result.forEach(System.out::println);
        */

        /* PROBLEM 8
        String line = scanner.nextLine();
        List<String> result = this.bookService.getBooksByAuthorsLastNameStartingWith(line);
        result.forEach(System.out::println);
        */

        /* PROBLEM 9
        Integer length = Integer.parseInt(scanner.nextLine());
        System.out.println(this.bookService.getCountOfBooksWithTitleLongerThan(length));
        */

        /* PROBLEM 10
        List<String> result = this.authorService.getAuthorsByBookCopiesCount();
        result.forEach(System.out::println);
        */

        /* PROBLEM 11
        String title = scanner.nextLine();
        String result = this.bookService.getBookDetailsByTitle(title);
        System.out.println(result);
        */
    }
}
