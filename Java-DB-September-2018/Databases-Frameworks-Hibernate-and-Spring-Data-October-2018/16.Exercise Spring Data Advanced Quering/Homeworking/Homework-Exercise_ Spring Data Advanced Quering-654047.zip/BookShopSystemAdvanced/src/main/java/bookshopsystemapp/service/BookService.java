package bookshopsystemapp.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public interface BookService {

    void seedBooks() throws IOException;

    List<String> getAllBooksTitlesAfter();

    Set<String> getAllAuthorsWithBookBefore();

    List<String> getAllBooksWithAgeRestriction(String ageGroup);

    List<String> getAllByCopiesIsLessThanAndEditionType(Integer copies, String editionType);

    List<String> getAllByPriceLessThanOrPriceGreaterThan(BigDecimal lessThan, BigDecimal moreThan);

    List<String> getNotReleasedBooks(String yearAsString);

    List<String> getAllBooksWithReleaseDateBefore(String dateAsString);

    List<String> getAllBooksByTitleContaining(String string);

    List<String> getBooksByAuthorsLastNameStartingWith(String string);

    Integer getCountOfBooksWithTitleLongerThan(Integer length);

    String getBookDetailsByTitle(String title);

}
