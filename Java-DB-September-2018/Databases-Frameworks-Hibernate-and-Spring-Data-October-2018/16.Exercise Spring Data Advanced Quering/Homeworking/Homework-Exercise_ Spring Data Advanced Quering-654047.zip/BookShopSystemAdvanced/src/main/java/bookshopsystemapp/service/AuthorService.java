package bookshopsystemapp.service;

import java.io.IOException;
import java.util.List;

public interface AuthorService {

    void seedAuthors() throws IOException;

    List<String> getAllAuthorsByFirstNameEndingWith(String string);

    List<String> getAuthorsByBookCopiesCount();
}
