package app.domain.entities;

public enum AgeRestriction {

    MINOR, TEEN, ADULT
}
