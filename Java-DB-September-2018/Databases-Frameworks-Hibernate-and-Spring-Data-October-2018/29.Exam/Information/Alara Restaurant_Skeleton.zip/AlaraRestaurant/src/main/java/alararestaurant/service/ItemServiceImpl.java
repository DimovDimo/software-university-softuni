package alararestaurant.service;

public class ItemServiceImpl implements ItemService {

    @Override
    public Boolean itemsAreImported() {
        // TODO : Implement me
        return null;
//        return this.itemRepository.count() > 0;
    }

    @Override
    public String readItemsJsonFile() {
        // TODO : Implement me
        return null;
    }

    @Override
    public String importItems(String items) {
        // TODO : Implement me
        return null;
    }
}
