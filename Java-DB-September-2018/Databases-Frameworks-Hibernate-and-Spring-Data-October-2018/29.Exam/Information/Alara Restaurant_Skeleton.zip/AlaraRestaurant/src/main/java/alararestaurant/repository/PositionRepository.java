package alararestaurant.repository;

public interface PositionRepository {
}
