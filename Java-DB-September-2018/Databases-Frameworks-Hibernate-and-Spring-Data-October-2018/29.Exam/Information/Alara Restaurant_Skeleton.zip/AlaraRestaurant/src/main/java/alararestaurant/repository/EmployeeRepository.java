package alararestaurant.repository;

public interface EmployeeRepository {
}
