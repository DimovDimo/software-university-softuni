package alararestaurant.repository;

public interface OrderRepository {
}
