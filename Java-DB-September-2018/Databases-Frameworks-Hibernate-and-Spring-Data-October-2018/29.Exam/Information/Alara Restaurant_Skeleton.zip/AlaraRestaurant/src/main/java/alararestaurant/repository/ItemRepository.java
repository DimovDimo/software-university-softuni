package alararestaurant.repository;

public interface ItemRepository {
}
