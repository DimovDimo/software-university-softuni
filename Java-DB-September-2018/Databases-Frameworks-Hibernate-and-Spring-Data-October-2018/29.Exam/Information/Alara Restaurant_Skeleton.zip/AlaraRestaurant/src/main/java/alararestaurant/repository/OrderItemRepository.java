package alararestaurant.repository;

public interface OrderItemRepository {
}
