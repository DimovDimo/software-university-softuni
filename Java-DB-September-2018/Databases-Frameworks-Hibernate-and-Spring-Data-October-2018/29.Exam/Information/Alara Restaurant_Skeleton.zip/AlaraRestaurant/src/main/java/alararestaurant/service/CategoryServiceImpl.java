package alararestaurant.service;

public class CategoryServiceImpl implements CategoryService {

    @Override
    public String exportCategoriesByCountOfItems() {
        // TODO : Implement me
        return null;
    }
}
