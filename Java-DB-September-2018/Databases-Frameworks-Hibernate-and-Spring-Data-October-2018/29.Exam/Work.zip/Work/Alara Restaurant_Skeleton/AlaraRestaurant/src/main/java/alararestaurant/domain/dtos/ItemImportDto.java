package alararestaurant.domain.dtos;

import com.google.gson.annotations.Expose;
import com.sun.istack.NotNull;

import java.math.BigDecimal;

public class ItemImportDto {
    /**
     * Item
     *     • id – integer, Primary Key
     *     • name – text with min length 3 and max length 30 (required, unique)
     *     • category – the item’s category (required)
     *     • price – decimal (non-negative, minimum value: 0.01, required)
     *     • orderItems – collection of type OrderItem
     *
     *     {
     *     "name": "Hamburger",
     *     "price": 0.00,
     *     "category": "Invalid"
     *   },
     */
    @Expose
    private String name;

    @Expose
    private BigDecimal price;

    @Expose
    private String category;

    public ItemImportDto() {
    }

    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotNull
    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    @NotNull
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
