package alararestaurant.domain.dtos.orders;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "orders")
@XmlAccessorType(XmlAccessType.FIELD)
public class OrderImportRootDto {
    /**
     * Order
     *     • id – integer, Primary Key
     *     • customer – text (required)
     *     • dateTime – date and time of the order (required)
     *     • type – OrderType enumeration with possible values: “ForHere, ToGo (default: ForHere)” (required)
     *     • employee – The employee who will process the order (required)
     *     • orderItems – collection of type OrderItem
     *
     *     <orders>
     *   <order>
     *     <customer>Garry</customer>
     *     <employee>Maxwell Shanahan</employee>
     *     <date-time>21/08/2017 13:22</date-time>
     *     <type>ForHere</type>
     *     <items>
     *       <item>
     *         <name>Quarter Pounder</name>
     *         <quantity>2</quantity>
     *       </item>
     *       <item>
     *         <name>Premium chicken sandwich</name>
     *         <quantity>2</quantity>
     *       </item>
     *       <item>
     *         <name>Chicken Tenders</name>
     *         <quantity>4</quantity>
     *       </item>
     *       <item>
     *         <name>Just Lettuce</name>
     *         <quantity>4</quantity>
     *       </item>
     *     </items>
     *   </order>
     */
    @XmlElement(name = "order")
    private OrderImportDto[] orderImportDtos;

    public OrderImportRootDto() {
    }

    public OrderImportDto[] getOrderImportDtos() {
        return orderImportDtos;
    }

    public void setOrderImportDtos(OrderImportDto[] orderImportDtos) {
        this.orderImportDtos = orderImportDtos;
    }
}
