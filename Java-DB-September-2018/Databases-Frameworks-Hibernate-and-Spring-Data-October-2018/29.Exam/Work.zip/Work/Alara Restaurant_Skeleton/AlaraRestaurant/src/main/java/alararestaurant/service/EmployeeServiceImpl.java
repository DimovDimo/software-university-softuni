package alararestaurant.service;

import alararestaurant.domain.dtos.EmployeeImportDto;
import alararestaurant.domain.entities.Employee;
import alararestaurant.domain.entities.Position;
import alararestaurant.repository.EmployeeRepository;
import alararestaurant.repository.PositionRepository;
import alararestaurant.util.FileUtil;
import alararestaurant.util.ValidationUtil;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Arrays;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final static String EMPLOYEES_JSON_FILE_PATH = System.getProperty("user.dir") + "/src/main/resources/files/employees.json";

    private final EmployeeRepository employeeRepository;
    private final PositionRepository positionRepository;
    private final FileUtil fileUtil;
    private final Gson gson;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public EmployeeServiceImpl(EmployeeRepository employeeRepository, PositionRepository positionRepository, FileUtil fileUtil, Gson gson, ValidationUtil validationUtil, ModelMapper modelMapper) {
        this.employeeRepository = employeeRepository;
        this.positionRepository = positionRepository;
        this.fileUtil = fileUtil;
        this.gson = gson;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public Boolean employeesAreImported() {
        return this.employeeRepository.count() > 0;
    }

    @Override
    public String readEmployeesJsonFile() throws IOException {
        return this.fileUtil.readFile(EMPLOYEES_JSON_FILE_PATH);
    }

    @Override
    public String importEmployees(String employees) {
        StringBuilder importResult = new StringBuilder();

        Arrays.stream(this.gson.fromJson(employees, EmployeeImportDto[].class)).forEach(employeeImportDto -> {

            if (!this.validationUtil.isValid(employeeImportDto)) {
                importResult.append("Invalid data format.").append(System.lineSeparator());

                return;
            }

            /**
             * Employee
             *     • id – integer, Primary Key
             *     • name – text with min length 3 and max length 30 (required)
             *     • age – integer in the range [15, 80] (required)
             *     • position – the employee’s position (required)
             *     • orders – the orders the employee has processed
             */

            Employee employeeEntity = this.modelMapper.map(employeeImportDto, Employee.class);
            Boolean employeeEntityIsValidNameLenght = 3 <= employeeEntity.getName().length() && employeeEntity.getName().length() <= 30;
            Boolean employeeEntityIsValidAgeRange = 15 <= employeeEntity.getAge() && employeeEntity.getAge() <= 80;
            /**
             * Position
             *     • id – integer, Primary Key
             *     • name – text with min length 3 and max length 30 (required, unique)
             *     • employees – Collection of type Employee
             */
            Boolean employeeEntityIsValidPositionLenght = 3 <= employeeImportDto.getPosition().length() && employeeImportDto.getPosition().length() <= 30;

            if (employeeEntityIsValidNameLenght == false ||
                    employeeEntityIsValidAgeRange == false ||
                    employeeEntityIsValidPositionLenght == false) {
                importResult.append("Invalid data format.").append(System.lineSeparator());

                return;
            }

            Position positionEntity = this.positionRepository.findByName(employeeImportDto.getPosition()).orElse(null);
            if (positionEntity == null){
                Position positionEntityToSave = this.modelMapper.map(employeeImportDto.getPosition(), Position.class);
                positionEntityToSave.setName(employeeImportDto.getPosition());
                this.positionRepository.saveAndFlush(positionEntityToSave);
                positionEntity = positionEntityToSave;
            }

            employeeEntity.setPosition(positionEntity);
            this.employeeRepository.saveAndFlush(employeeEntity);

            importResult
                    .append(String
                            .format("Record %s successfully imported.", employeeEntity.getName()))
                    .append(System.lineSeparator());
        });

        return importResult.toString().trim();
    }
}
