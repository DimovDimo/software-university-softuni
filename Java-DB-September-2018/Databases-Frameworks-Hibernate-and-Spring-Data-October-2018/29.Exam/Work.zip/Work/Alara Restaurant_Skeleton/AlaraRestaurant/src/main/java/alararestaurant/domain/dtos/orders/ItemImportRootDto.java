package alararestaurant.domain.dtos.orders;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "items")
@XmlAccessorType(XmlAccessType.FIELD)
public class ItemImportRootDto {
    /**
     * Item
     *     • id – integer, Primary Key
     *     • name – text with min length 3 and max length 30 (required, unique)
     *     • category – the item’s category (required)
     *     • price – decimal (non-negative, minimum value: 0.01, required)
     *     • orderItems – collection of type OrderItem
     *
     *          *     • quantity – the quantity of the item in the order (required, non-negative and non-zero)
     *
     *     <items>
     *       <item>
     *         <name>Quarter Pounder</name>
     *         <quantity>2</quantity>
     *       </item>
     */

    @XmlElement(name = "item")
    private ItemXmlImportDto[] itemXmlImportDtos;

    public ItemImportRootDto() {
    }

    public ItemXmlImportDto[] getItemXmlImportDtos() {
        return itemXmlImportDtos;
    }

    public void setItemXmlImportDtos(ItemXmlImportDto[] itemXmlImportDtos) {
        this.itemXmlImportDtos = itemXmlImportDtos;
    }
}
