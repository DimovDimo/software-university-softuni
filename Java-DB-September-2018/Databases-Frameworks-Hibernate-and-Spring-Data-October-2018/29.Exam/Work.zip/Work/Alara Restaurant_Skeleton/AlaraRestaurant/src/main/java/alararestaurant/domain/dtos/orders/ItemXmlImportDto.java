package alararestaurant.domain.dtos.orders;

import com.sun.istack.NotNull;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "item")
@XmlAccessorType(XmlAccessType.FIELD)
public class ItemXmlImportDto {
    /**
     * Item
     *     • id – integer, Primary Key
     *     • name – text with min length 3 and max length 30 (required, unique)
     *     • category – the item’s category (required)
     *     • price – decimal (non-negative, minimum value: 0.01, required)
     *     • orderItems – collection of type OrderItem
     *
     *          *     • quantity – the quantity of the item in the order (required, non-negative and non-zero)
     *
     *     <items>
     *       <item>
     *         <name>Quarter Pounder</name>
     *         <quantity>2</quantity>
     *       </item>
     */

    @XmlElement(name = "name")
    private String name;

    @XmlElement(name = "quantity")
    private Integer quantity;

    public ItemXmlImportDto() {
    }

    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotNull
    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}
