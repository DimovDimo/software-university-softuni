package alararestaurant.domain.dtos.orders;

import com.sun.istack.NotNull;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "order")
@XmlAccessorType(XmlAccessType.FIELD)
public class OrderImportDto {
    /**
     * Order
     *     • id – integer, Primary Key
     *     • customer – text (required)
     *     • dateTime – date and time of the order (required)
     *     • type – OrderType enumeration with possible values: “ForHere, ToGo (default: ForHere)” (required)
     *     • employee – The employee who will process the order (required)
     *     • orderItems – collection of type OrderItem
     *
     *     <orders>
     *   <order>
     *     <customer>Garry</customer>
     *     <employee>Maxwell Shanahan</employee>
     *     <date-time>21/08/2017 13:22</date-time>
     *     <type>ForHere</type>
     *     <items>
     *       <item>
     *         <name>Quarter Pounder</name>
     *         <quantity>2</quantity>
     *       </item>
     *       <item>
     *         <name>Premium chicken sandwich</name>
     *         <quantity>2</quantity>
     *       </item>
     *       <item>
     *         <name>Chicken Tenders</name>
     *         <quantity>4</quantity>
     *       </item>
     *       <item>
     *         <name>Just Lettuce</name>
     *         <quantity>4</quantity>
     *       </item>
     *     </items>
     *   </order>
     */
    @XmlElement(name = "customer")
    private String customer;

    @XmlElement(name = "employee")
    private String employee;

    @XmlElement(name = "date-time")
    private String dateTime;

    @XmlElement(name = "type")
    private String type;

    @XmlElement(name = "items")
    private ItemImportRootDto itemImportRootDto;

    public OrderImportDto() {
    }

    @NotNull
    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    @NotNull
    public String getEmployee() {
        return employee;
    }

    public void setEmployee(String employee) {
        this.employee = employee;
    }

    @NotNull
    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    @NotNull
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public ItemImportRootDto getItemImportRootDto() {
        return itemImportRootDto;
    }

    public void setItemImportRootDto(ItemImportRootDto itemImportRootDto) {
        this.itemImportRootDto = itemImportRootDto;
    }
}
