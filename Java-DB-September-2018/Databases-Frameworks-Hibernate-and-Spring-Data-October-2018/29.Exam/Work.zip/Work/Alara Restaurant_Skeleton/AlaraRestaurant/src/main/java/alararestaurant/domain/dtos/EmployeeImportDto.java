package alararestaurant.domain.dtos;

import com.google.gson.annotations.Expose;
import com.sun.istack.NotNull;

public class EmployeeImportDto {
    /**
     * Employee
     *     • id – integer, Primary Key
     *     • name – text with min length 3 and max length 30 (required)
     *     • age – integer in the range [15, 80] (required)
     *     • position – the employee’s position (required)
     *     • orders – the orders the employee has processed
     *
     *       {
     *     "name": "N",
     *     "age": 20,
     *     "position": "Invalid"
     *   },
     */
    @Expose
    private String name;

    @Expose
    private Integer age;

    @Expose
    private String position;

    public EmployeeImportDto() {
    }

    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotNull
    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    @NotNull
    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }
}
