package alararestaurant.service;

import alararestaurant.domain.dtos.EmployeeImportDto;
import alararestaurant.domain.dtos.ItemImportDto;
import alararestaurant.domain.entities.Category;
import alararestaurant.domain.entities.Item;
import alararestaurant.repository.CategoryRepository;
import alararestaurant.repository.ItemRepository;
import alararestaurant.util.FileUtil;
import alararestaurant.util.ValidationUtil;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;

@Service
public class ItemServiceImpl implements ItemService {

    private final static String ITEMS_JSON_FILE_PATH = System.getProperty("user.dir") + "/src/main/resources/files/items.json";

    private final ItemRepository itemRepository;
    private final CategoryRepository categoryRepository;
    private final FileUtil fileUtil;
    private final Gson gson;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public ItemServiceImpl(ItemRepository itemRepository, CategoryRepository categoryRepository, FileUtil fileUtil, Gson gson, ValidationUtil validationUtil, ModelMapper modelMapper) {
        this.itemRepository = itemRepository;
        this.categoryRepository = categoryRepository;
        this.fileUtil = fileUtil;
        this.gson = gson;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public Boolean itemsAreImported() {
        return this.itemRepository.count() > 0;
    }

    @Override
    public String readItemsJsonFile() throws IOException {
        return this.fileUtil.readFile(ITEMS_JSON_FILE_PATH);
    }

    @Override
    public String importItems(String items) {
        StringBuilder importResult = new StringBuilder();

        Arrays.stream(this.gson.fromJson(items, ItemImportDto[].class)).forEach(itemImportDto -> {

            /**
             * Constraints
             *     • If any validation errors occur (such as invalid item name or invalid category name), ignore the entity and print an error message.
             *     • If an item with the same name already exists, ignore the entity and do not import it.
             *     • If an item’s category doesn’t exist, create it along with the item.
             */

            Boolean itemImportDtoIsValidNameLenght = 3 <= itemImportDto.getName().length() && itemImportDto.getName().length() <= 30;
            Boolean itemImportDtoIsValidPrice = itemImportDto.getPrice().compareTo(new BigDecimal(0.01)) >= 0;
            Boolean itemImportDtoIsValidCategoryNameLenght = 3 <= itemImportDto.getCategory().length() && itemImportDto.getCategory().length() <= 30;

            Item itemEntity = this.itemRepository.findByName(itemImportDto.getName()).orElse(null);

            if (!this.validationUtil.isValid(itemImportDto) ||
                    itemImportDtoIsValidNameLenght == false ||
                    itemImportDtoIsValidPrice == false ||
                    itemImportDtoIsValidCategoryNameLenght == false ||
                    itemEntity != null) {
                importResult.append("Invalid data format.").append(System.lineSeparator());

                return;
            }

            Category categoryEntity = this.categoryRepository.findByName(itemImportDto.getCategory()).orElse(null);
            if (categoryEntity == null){
                Category categoryEntityToSave = this.modelMapper.map(itemImportDto.getCategory(), Category.class);
                categoryEntityToSave.setName(itemImportDto.getCategory());
                this.categoryRepository.saveAndFlush(categoryEntityToSave);
                categoryEntity = categoryEntityToSave;
            }

            Item itemEntityToSave = this.modelMapper.map(itemImportDto, Item.class);
            itemEntityToSave.setCategory(categoryEntity);
            this.itemRepository.saveAndFlush(itemEntityToSave);

            importResult
                    .append(String
                            .format("Record %s successfully imported.", itemEntityToSave.getName()))
                    .append(System.lineSeparator());
        });

        return importResult.toString().trim();
    }
}
