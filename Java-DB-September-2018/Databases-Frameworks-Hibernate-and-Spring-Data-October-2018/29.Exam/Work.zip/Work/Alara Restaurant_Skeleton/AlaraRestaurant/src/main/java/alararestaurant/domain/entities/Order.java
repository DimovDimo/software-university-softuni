package alararestaurant.domain.entities;

import alararestaurant.domain.entities.base.BaseEntity;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity(name = "orders")
public class Order extends BaseEntity {
    /**
     * Order
     *     • id – integer, Primary Key
     *     • customer – text (required)
     *     • dateTime – date and time of the order (required)
     *     • type – OrderType enumeration with possible values: “ForHere, ToGo (default: ForHere)” (required)
     *     • employee – The employee who will process the order (required)
     *     • orderItems – collection of type OrderItem
     */
    private String customer;
    private LocalDateTime dateTime;
    private String type;
    private Employee employee;
    private List<OrderItem> orderItems;

    public Order() {
//        this.orderItems = new ArrayList<>();
    }

    @Column(name = "customer", nullable = false, columnDefinition = "TEXT")
    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    @Column(name = "date_time", nullable = false)
    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    @Column(name = "type", nullable = false, columnDefinition = "ENUM('ForHere', 'ToGo') default 'ForHere'")
//    @Enumerated(value = EnumType.STRING)
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @ManyToOne(targetEntity = Employee.class)
    @JoinColumn(
            name = "employee_id",
            referencedColumnName = "id",
            nullable = false
    )
    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    @OneToMany(mappedBy = "order", targetEntity = OrderItem.class)
    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }
}
