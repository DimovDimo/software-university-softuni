package alararestaurant.service;

import alararestaurant.domain.dtos.orders.ItemXmlImportDto;
import alararestaurant.domain.dtos.orders.OrderImportRootDto;
import alararestaurant.domain.entities.Employee;
import alararestaurant.domain.entities.Item;
import alararestaurant.domain.entities.Order;
import alararestaurant.domain.entities.OrderItem;
import alararestaurant.repository.EmployeeRepository;
import alararestaurant.repository.ItemRepository;
import alararestaurant.repository.OrderItemRepository;
import alararestaurant.repository.OrderRepository;
import alararestaurant.util.FileUtil;
import alararestaurant.util.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    private final static String ORDERS_XML_FILE_PATH = System.getProperty("user.dir") + "/src/main/resources/files/orders.xml";

    private final OrderRepository orderRepository;
    private final EmployeeRepository employeeRepository;
    private final ItemRepository itemRepository;
    private final OrderItemRepository orderItemRepository;
    private final FileUtil fileUtil;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public OrderServiceImpl(OrderRepository orderRepository, EmployeeRepository employeeRepository, ItemRepository itemRepository, OrderItemRepository orderItemRepository, FileUtil fileUtil, ValidationUtil validationUtil, ModelMapper modelMapper) {
        this.orderRepository = orderRepository;
        this.employeeRepository = employeeRepository;
        this.itemRepository = itemRepository;
        this.orderItemRepository = orderItemRepository;
        this.fileUtil = fileUtil;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public Boolean ordersAreImported() {
        return this.orderRepository.count() > 0;
    }

    @Override
    public String readOrdersXmlFile() throws IOException {
        return this.fileUtil.readFile(ORDERS_XML_FILE_PATH);
    }

    @Override
    public String importOrders() throws JAXBException {
        StringBuilder importResult = new StringBuilder();

        OrderImportRootDto orderImportRootDto = this.parseXml(OrderImportRootDto.class, ORDERS_XML_FILE_PATH);

        Arrays.stream(orderImportRootDto.getOrderImportDtos()).forEach(orderImportDto -> {

            /**
             * Constraints
             *     • The order dates will be in the format “dd/MM/yyyy HH:mm”.
             *     • If the order’s employee doesn’t exist, do not import the order.
             *     • If any of the order’s items do not exist, do not import the order.
             *     • Every employee will have a unique name
             */
            Employee employeeEntity = this.employeeRepository.findByName(orderImportDto.getEmployee()).orElse(null);
            if (!validationUtil.isValid(orderImportDto) || employeeEntity == null) {
                importResult.append("Invalid data format.").append(System.lineSeparator());

                return;
            }

            Order orderEntity = this.modelMapper.map(orderImportDto, Order.class);
            List<OrderItem> orderItems = new ArrayList<>();
            for (ItemXmlImportDto itemXmlImportDto : orderImportDto.getItemImportRootDto().getItemXmlImportDtos()) {
                Item itemEntity = this.itemRepository.findByName(itemXmlImportDto.getName()).orElse(null);
                if (itemEntity == null) {
                    importResult.append("Invalid data format.").append(System.lineSeparator());

                    return;
                }

                OrderItem orderItemEntity = new OrderItem();
                orderItemEntity.setOrder(orderEntity);
                orderItemEntity.setItem(itemEntity);
                orderItems.add(orderItemEntity);
            }

            orderEntity.setEmployee(employeeEntity);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
            LocalDateTime dateTime = LocalDateTime.parse(orderImportDto.getDateTime(), formatter);
            orderEntity.setDateTime(dateTime);
            this.orderRepository.saveAndFlush(orderEntity);
//            this.orderItemRepository.saveAll(orderItems);

            importResult
                    .append(String
                            .format("Order for %s on %s added",
                                    orderImportDto.getCustomer(),
                                    orderImportDto.getDateTime()))
                    .append(System.lineSeparator());
        });

        return importResult.toString().trim();
    }

    @Override
    public String exportOrdersFinishedByTheBurgerFlippers() {
        // TODO : Implement me
        return null;
    }

    @SuppressWarnings("unchecked")
    public <O> O parseXml(Class<O> objectClass, String filePath) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(objectClass);
        Unmarshaller unmarshaller = context.createUnmarshaller();

        return (O) unmarshaller.unmarshal(new File(filePath));
    }
}
