package app.io;

import app.contracts.Writer;

public class ConsoleWriter implements Writer {
    public void write(String str) {
        System.out.println(str);
    }
}
