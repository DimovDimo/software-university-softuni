package app;

import app.contracts.Reader;
import app.contracts.Writer;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class Engine implements Runnable {
    private Connection connection;
    private Reader reader;
    private Writer writer;

    public Engine(Connection connection, Reader reader, Writer writer) {
        this.connection = connection;
        this.reader = reader;
        this.writer = writer;
    }

    public void run() {
        try {
            //this.getVillainsNames();
            //this.getMinionsNames();
            //this.addMinion();
            //this.changeTownNameCasing();
            //this.removeVillain();
            //this.printAlMinions();
            //this.increaseMinionsAge();
            this.increaseAgeStoredProcedure();
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Problem 2 Get Villains' names
     */
    private void getVillainsNames() throws SQLException {
        String query = "SELECT v.name, COUNT(mv.minion_id) AS minions FROM villains v LEFT JOIN minions_villains mv ON v.id = mv.villain_id GROUP BY v.id HAVING minions > ? ORDER BY minions DESC;";

        PreparedStatement preparedStatement = this.connection
                .prepareStatement(query);

        preparedStatement.setInt(1, 15);

        ResultSet rs = preparedStatement.executeQuery();

        while (rs.next()) {
            this.writer.write(String.format("%s %d", rs.getString("name"), rs.getInt("minions")));
        }
    }

    /**
     * Problem 3 get villain's minions
     */
    private void getMinionsNames() throws SQLException, IOException {
        this.writer.write("Please enter a Villain id");
        int villainId = Integer.parseInt(this.reader.readLine());
        String villainNameQuery = "SELECT name FROM villains\n" +
                "WHERE id = ?";
        String minionsQuery = "SELECT m.id, m.name, m.age FROM minions m\n" +
                "JOIN minions_villains mv on m.id = mv.minion_id\n" +
                "WHERE mv.villain_id = ?;\n";

        PreparedStatement villainNameStmt = this.connection.prepareStatement(villainNameQuery);
        villainNameStmt.setInt(1, villainId);

        PreparedStatement minionsStmt = this.connection.prepareStatement(minionsQuery);
        minionsStmt.setInt(1, villainId);

        //Print villain
        ResultSet villainNameResultSet = villainNameStmt.executeQuery();
        if(!villainNameResultSet.next()) {
            this.writer.write(String.format("No villain with ID %d exists in the database.", villainId));
            return;
        }
        //villainNameResultSet.next();
        this.writer.write(String.format("Villain: %s", villainNameResultSet.getString("name")));

        ResultSet minionsResultSet = minionsStmt.executeQuery();

        if(!minionsResultSet.next()) {
            this.writer.write("<no minions>");
            return;
        }

        minionsResultSet.beforeFirst();
        while (minionsResultSet.next()) {
            this.writer.write(String.format("%d. %s %d", minionsResultSet.getInt("id"),
                    minionsResultSet.getString("name"), minionsResultSet.getInt("age")));
        }
    }

    /**
     *  Problem 4 add minion
     */
    private void addMinion() throws IOException, SQLException {
       String[] minionTokens = this.reader.readLine().split("[: ]+");
       String[] villainTokens = this.reader.readLine().split("[: ]+");

       String minionName = minionTokens[1];
       int age = Integer.parseInt(minionTokens[2]);
       String town = minionTokens[3];

       String villainName = villainTokens[1];

       //this.writer.write(this.checkIfEntityExists(town, "towns") ? "Exists" : "Does not exist");
       if(!this.checkIfEntityExists(town, "towns")) {
           this.insertTown(town);
       }

       //this.writer.write(this.checkIfEntityExists(minionName, "minions") ? "Villain Exists" : "Does not exist");
        if(!this.checkIfEntityExists(villainName, "villains")) {
            this.insertVillain(villainName);
        }
       //this.writer.write(Integer.toString(this.getEntityId("towns", "Berlin")));
        int townId = this.getEntityId("towns", town);
        int villainId = this.getEntityId("villains", villainName);

        this.insertMinion(minionName, age, townId);
        int minionId = this.getEntityId("minions", minionName);

        this.insertIntoVillainsMinions(villainId, minionId, minionName, villainName);
    }

    private boolean checkIfEntityExists(String entityName, String tableName) throws SQLException {
        String query = "SELECT  * FROM " + tableName + "\n" +
                       "WHERE name = ?;";
        PreparedStatement ps  = this.connection.prepareStatement(query);
        ps.setString(1, entityName);

        ResultSet rs = ps.executeQuery();

        return rs.next();
    }

    private int getEntityId(String table, String name) throws SQLException {
        String query = "SELECT  id FROM " + table + "\n" +
                "WHERE name = ?;";

        PreparedStatement ps = this.connection.prepareStatement(query);
        ps.setString(1, name);

        ResultSet rs = ps.executeQuery();
        rs.next();

        return rs.getInt("id");
    }

    private void insertTown(String townName) throws SQLException {
        String query = "INSERT INTO towns(name, country)\n" +
                        "VALUES (?, NULL );";

        PreparedStatement ps = this.connection.prepareStatement(query);
        ps.setString(1, townName);

        ps.execute();

        this.writer.write(String.format("Town %s was added to the database.", townName));
    }

    private void insertVillain(String name) throws SQLException {
        String query = "INSERT INTO villains(name, evilness_factor)\n" +
                        "VALUES (?, 'evil');";
        PreparedStatement ps = this.connection.prepareStatement(query);
        ps.setString(1, name);

        ps.execute();

        this.writer.write(String.format("Villain %s was added to the database.", name));
    }

    private void insertMinion(String minionName, int age, int townId) throws SQLException {
        String query = "INSERT INTO minions(name, age, town_id)\n" +
                        "VALUES (?, ?, ?);";

        PreparedStatement ps = this.connection.prepareStatement(query);

        ps.setString(1, minionName);
        ps.setInt(2, age);
        ps.setInt(3, townId);

        ps.execute();

        //this.writer.write("Added minion");
    }

    private void insertIntoVillainsMinions(int villainId, int minionId, String minionName, String villainName) throws SQLException {
        String query = "INSERT INTO minions_villains (minion_id, villain_id) \n" +
                        "VALUES (?,?);";

        PreparedStatement ps = this.connection.prepareStatement(query);
        ps.setInt(1, minionId);
        ps.setInt(2, villainId);

        ps.execute();

        this.writer.write(String.format("Successfully added %s to be minion of %s.", minionName, villainName));
    }

    /**
     * Problem 5 Change town_name casing
     */
    private void changeTownNameCasing() throws IOException, SQLException {
        String countryName = reader.readLine();
        String query = "UPDATE towns t\n" +
                       "SET t.name = UPPER(t.name)\n" +
                       "WHERE t.country = ?;";
        PreparedStatement ps = this.connection.prepareStatement(query);
        ps.setString(1, countryName);

        int affectedRowsCount = ps.executeUpdate();

        if(affectedRowsCount == 0) {
            this.writer.write("No town names were affected.");
            return;
        }

        this.writer.write(String.format("%d town names were affected.", affectedRowsCount));

        List<String> towns = this.getAffectedTowns(countryName);
        this.writer.write(Arrays.toString(towns.toArray()));
    }

    private List<String> getAffectedTowns(String countryName) throws SQLException {
        List<String> results = new ArrayList<String>();
        String query = "SELECT * FROM towns\n" +
                        "WHERE country = ?;";
        PreparedStatement ps = this.connection.prepareStatement(query);
        ps.setString(1, countryName);

        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            results.add(rs.getString("name"));
        }

        return results;
    }

    /**
     * Problem 6 remove villain
     */
    private void removeVillain() throws IOException, SQLException {
        int villainId = Integer.parseInt(this.reader.readLine());
        this.connection.setAutoCommit(false);

        try {
            if(!this.checkIfVillainExists(villainId)) {
                this.writer.write("No such villain was found");
                return;
            }
            int minionCounter = this.countReleasedMinions(villainId);
            //this.writer.write(Integer.toString(this.countReleasedMinions(villainId)));

            if(minionCounter > 0) {
                this.releaseMinions(villainId);
            }

            String villainName = this.getVillainName(villainId);
            this.deleteVillain(villainId);

            this.writer.write(String.format("%s was deleted", villainName));
            this.writer.write(String.format("%d minions released", minionCounter));

            this.connection.commit();
        } catch (SQLException e) {
            this.connection.rollback();
            //e.printStackTrace();
            this.writer.write("Rollback");
        }
    }

    private int countReleasedMinions(int villainId) throws SQLException {
        String query = "SELECT COUNT(minion_id) FROM minions_villains\n" +
                        "GROUP BY villain_id\n" +
                        "HAVING villain_id = ?";
        PreparedStatement ps = this.connection.prepareStatement(query);
        ps.setInt(1, villainId);

        ResultSet rs = ps.executeQuery();

        if(!rs.isBeforeFirst()) {
            return 0;
        }

        rs.next();
        return rs.getInt(1);
    }

    private boolean checkIfVillainExists(int villainId) throws SQLException {
        String query = "SELECT * FROM villains\n" +
                        "WHERE id = ?;";
        PreparedStatement ps = this.connection.prepareStatement(query);
        ps.setInt(1, villainId);

        ResultSet rs = ps.executeQuery();

        return rs.isBeforeFirst();
    }

    private void releaseMinions(int villainId) throws SQLException {
        String query = "DELETE FROM minions_villains\n" +
                       "WHERE villain_id = ?;";

        PreparedStatement ps = this.connection.prepareStatement(query);
        ps.setInt(1, villainId);

        ps.executeUpdate();
    }

    private void deleteVillain(int villainId) throws SQLException {
        String query = "DELETE FROM villains\n" +
                       "WHERE id = ?;";
        PreparedStatement ps = this.connection.prepareStatement(query);
        ps.setInt(1, villainId);

        ps.executeUpdate();
    }

    private String getVillainName(int villainId) throws SQLException {
        String query = "SELECT name FROM villains\n" +
                       "WHERE id = ?;";
        PreparedStatement ps = this.connection.prepareStatement(query);
        ps.setInt(1, villainId);

        ResultSet rs = ps.executeQuery();
        rs.next();

        return rs.getString("name");
    }

    /**
     *  Problem 7
     */
    private void printAllMinions() throws SQLException {
        List<String> names = this.getNames();

        for (int i = 0; i < names.size() / 2; i++) {
            this.writer.write(names.get(i));
            this.writer.write(names.get(names.size() - 1 - i));
        }

        if(names.size() % 2 != 0) {
            this.writer.write(names.get(names.size() / 2));
        }
    }

    private List<String> getNames() throws SQLException {
        String query = "SELECT * FROM minions";

        PreparedStatement ps = this.connection.prepareStatement(query);

        ResultSet rs = ps.executeQuery();

        List<String> names = new ArrayList<String>();

        while (rs.next()) {
            names.add(rs.getString("name"));
        }

        return names;
    }

    /**
     *  Problem 8
     */
    private void increaseMinionsAge() throws IOException, SQLException {
        int[] minionsIds = Arrays.stream(this.reader.readLine().split("\\s+"))
                    .mapToInt(Integer::parseInt).toArray();
        this.updateMinions(minionsIds);
        this.printMinions();
    }

    private void updateMinions(int[] ids) throws SQLException {
        String query = String.format("UPDATE minions\n" +
                "SET age = age + 1, name = CONCAT(UPPER(LEFT(name, 1)), '', SUBSTRING(name, 2))\n" +
                "WHERE id IN (%s);", Arrays.toString(ids).replaceAll("[\\[\\]]", ""));
        PreparedStatement ps = this.connection.prepareStatement(query);

        ps.executeUpdate();
    }

    private void printMinions() throws SQLException {
        String query = "SELECT name, age FROM minions";
        PreparedStatement ps = this.connection.prepareStatement(query);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            this.writer.write(String.format("%s %d", rs.getString("name"), rs.getInt("age")));
        }
    }

    /**
     *  Problem 9
     */
    private void increaseAgeStoredProcedure() throws IOException, SQLException {
        int id = Integer.parseInt(this.reader.readLine());
        //this.printMinionById(id);
        CallableStatement callableStatement = this.connection.prepareCall("call usp_increase_minion_age(?)");
        callableStatement.setInt(1, id);
        callableStatement.executeQuery();
        this.printMinionById(id);
    }

    private void printMinionById(int id) throws SQLException {
        String query = "SELECT name, age FROM minions WHERE id = ?";
        PreparedStatement ps = this.connection.prepareStatement(query);
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if(!rs.isBeforeFirst()) {
            return;
        }

        rs.next();

        this.writer.write(String.format("%s %d", rs.getString("name"), rs.getInt("age")));
    }
}
