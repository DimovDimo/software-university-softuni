package app.io;

import app.contracts.Reader;

import java.io.BufferedReader;
import java.io.IOException;

public class ConsoleReader implements Reader {
    private BufferedReader bf;

    public ConsoleReader(BufferedReader bf) {
        this.bf = bf;
    }

    public String readLine() throws IOException {
        return this.bf.readLine();
    }
}
