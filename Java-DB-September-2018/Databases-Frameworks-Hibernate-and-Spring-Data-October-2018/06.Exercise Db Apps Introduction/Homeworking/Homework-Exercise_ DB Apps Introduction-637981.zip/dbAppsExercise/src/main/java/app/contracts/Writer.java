package app.contracts;

public interface Writer {
    void write(String str);
}
