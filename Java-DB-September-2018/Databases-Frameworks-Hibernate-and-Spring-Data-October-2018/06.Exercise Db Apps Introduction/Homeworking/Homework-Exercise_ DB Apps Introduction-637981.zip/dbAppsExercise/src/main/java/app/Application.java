package app;

import app.contracts.Reader;
import app.contracts.Writer;
import app.io.ConsoleReader;
import app.io.ConsoleWriter;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Application {
    public static void main(String[] args) throws SQLException {
        String user = "root";
        String password = "";

        Properties props = new Properties();

        props.setProperty("user", user);
        props.setProperty("password", password);


        Connection connection = DriverManager.
                getConnection("jdbc:mysql://localhost:3306/minions_db", props);

        Reader reader = new ConsoleReader(new BufferedReader(new InputStreamReader(System.in)));
        Writer writer = new ConsoleWriter();

        Engine engine = new Engine(connection, reader, writer);
        engine.run();

        connection.close();
    }
}
