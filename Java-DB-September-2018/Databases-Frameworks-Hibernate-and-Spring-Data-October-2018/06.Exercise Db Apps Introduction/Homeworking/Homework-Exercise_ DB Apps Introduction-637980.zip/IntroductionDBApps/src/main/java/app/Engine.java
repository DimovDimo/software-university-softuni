package app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Engine implements Runnable {
    private Connection connection;

    public Engine(Connection connection) throws IOException {
        this.connection = connection;
    }

    public void run() {
        try {
            this.increaseAgeStoredProcedure();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
    * Problem 2 - Get Villains’ Names
    */
    private void getVillainceNames() throws SQLException {
        String query = "SELECT v.name, COUNT(v2.minion_id) FROM villains v JOIN minions_villains v2 on v.id = v2.villain_id GROUP BY v.name having COUNT(v2.minion_id)>? order by COUNT(v2.minion_id) desc";
        PreparedStatement preparedStatement = this.connection.prepareStatement(query);
        preparedStatement.setInt(1,3);

        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()){
            System.out.println(String.format("%s %d", resultSet.getString(1), resultSet.getInt(2)));
        }
    }

    /**
     * Problem 3 - Get Minion Names
     */
    private void getMinionNames() throws SQLException, IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int villainIdInput = Integer.parseInt(reader.readLine());

        String queryMinions = "SELECT v.name, mi.name, mi.age FROM villains v JOIN minions_villains m on v.id = m.villain_id JOIN minions mi on mi.id = m.minion_id WHERE v.id = ? order by mi.name asc, mi.age asc";
        PreparedStatement preparedStatementMinions = this.connection.prepareStatement(queryMinions);
        preparedStatementMinions.setInt(1,villainIdInput);

        ResultSet resultSetMinions = preparedStatementMinions.executeQuery();

        String queryVillains = "SELECT v.name FROM villains v WHERE v.id = ?";
        PreparedStatement preparedStatementVillains = this.connection.prepareStatement(queryVillains);
        preparedStatementVillains.setInt(1,villainIdInput);

        ResultSet resultSetVillains = preparedStatementVillains.executeQuery();

        if (!resultSetVillains.next()) {
            System.out.println("No villain with ID " + villainIdInput + " exists in the database.");
        } else {
            System.out.println("Villain: " + resultSetVillains.getString(1));
        }

        int counter = 1;

        if (!resultSetMinions.next()) {
            System.out.println("<no minions>");
        } else {
            while (resultSetMinions.next()) {
                System.out.println(counter++ + ". " + resultSetMinions.getString(2) + " " + resultSetMinions.getInt(3));
            }
        }
    }

    /**
     * Problem 4 - Add Minion
     */
    private void addMinions() throws SQLException {
        Scanner input = new Scanner(System.in);

        String[] minionParams = input.nextLine().split("\\s+");
        String[] villainParams = input.nextLine().split("\\s+");

        String minionName = minionParams[1];
        int minionAge = Integer.parseInt(minionParams[2]);
        String minionTown = minionParams[3];
        String villainName = villainParams[1];

        if(!this.checkIfEntityExists(minionTown, "towns")){
            this.insetTowns(minionTown);
        }
        if(!this.checkIfEntityExists(villainName, "villains")){
            this.insetVillain(villainName);
        }

        int townId = this.getEntityId(minionTown,"towns");
        this.insertMinion(minionName,minionAge,townId);
        System.out.println(String.format("Successfully added %s to be minion of %s",minionName,villainName));

        int minionId = this.getEntityId(minionName,"minions");
        int villainId = this.getEntityId(villainName,"villains");

        this.hireMinion(minionId,villainId);
    }

    private boolean checkIfEntityExists(String name, String tableName) throws SQLException {
        String query = "SELECT * FROM " + tableName + " WHERE name = ?";
        PreparedStatement preparedStatement = this.connection.prepareStatement(query);
        preparedStatement.setString(1,name);

        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()){
            return true;
        }
        return false;
    }

    private void insetTowns(String townName) throws SQLException {
        String query = "INSERT INTO towns(name,country) VALUES('" + townName + "', NULL)";
        PreparedStatement statement = this.connection.prepareStatement(query);
        statement.execute(query);

        System.out.println(String.format("Town %s was added to the database.\n", townName));
    }

    private void insetVillain(String villainName) throws SQLException {
        String query = String.format("INSERT INTO villains (name , evilness_factor) VALUES('%s','evil')",villainName);
        PreparedStatement statement = this.connection.prepareStatement(query);
        statement.execute(query);

        System.out.println(String.format("Villain %s was added to the database.\n", villainName));
    }

    private int getEntityId(String name, String tableName) throws SQLException {
        String query = String.format("SELECT id FROM %s WHERE name = '%s'", tableName,name);
        PreparedStatement statement = this.connection.prepareStatement(query);

        ResultSet resultSet = statement.executeQuery();
        resultSet.next();

        return resultSet.getInt(1);
    }

    private void insertMinion(String minionName, int age, int townId) throws SQLException {
        String query = String.format("INSERT INTO minions (name , age, town_id) VALUES('%s', %d, %d)",minionName,age,townId);
        PreparedStatement statement = this.connection.prepareStatement(query);
        statement.execute();
    }

    private void hireMinion(int minionId, int villainId) throws SQLException {
        String query = String.format("INSERT INTO minions_villains (minion_id, villain_id) VALUES(%d, %d)", minionId,villainId);
        PreparedStatement statement = this.connection.prepareStatement(query);
        statement.execute();
    }

    /**
     * Problem 5 - Change Town Names Casing
     */
    private void changeTownNamesCasing() throws IOException, SQLException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String country = reader.readLine();

        String queryCountry = "SELECT t.name from towns t where t.country =?; ";
        PreparedStatement preparedStatementCountry = this.connection.prepareStatement(queryCountry);
        preparedStatementCountry.setString(1,country);

        ResultSet resultSetCountry = preparedStatementCountry.executeQuery();

        List<String> towns = new ArrayList<>();

        if (!resultSetCountry.next()) {
            System.out.println("No town names were affected.");
        } else {
            while (resultSetCountry.next()) {
                towns.add(resultSetCountry.getString(1).toUpperCase());
            }

            PreparedStatement updateTowns = connection.prepareStatement("UPDATE towns AS t SET t.name = UPPER(t.name) WHERE t.country = ?;");
            updateTowns.setString(1, country);
            updateTowns.executeUpdate();
            updateTowns.close();

            if(towns.size()==0){
                System.out.println("No town names were affected.");
            }else{
                System.out.println(towns.size() + " town names were affected.");
                System.out.println(towns.toString());
            }
        }
        resultSetCountry.close();
        preparedStatementCountry.close();
        connection.close();
    }

    /**
     * Problem 7 - Print All Minion Names
     */
    private void printAllMinionNames() throws SQLException {
        List<String> minionNames = new ArrayList<>();

        String query = "SELECT m.name from minions m";
        PreparedStatement preparedStatement = this.connection.prepareStatement(query);

        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            minionNames.add(resultSet.getString("name"));
        }

        for (int i = 0; i < minionNames.size() / 2; i++) {
            System.out.println(minionNames.get(i));
            System.out.println(minionNames.get(minionNames.size() - i - 1));
        }
    }

    /**
     * Problem 8 - Increase Minions Age
     */
    private void increaseMinionsAge() throws IOException, SQLException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        List<Integer> ids = Arrays.stream(reader.readLine().split(" ")).map(Integer::valueOf).collect(Collectors.toList());

        PreparedStatement increaseAge = connection.prepareStatement("UPDATE minions AS m SET m.age = m.age + 1 WHERE m.id = ?");

        PreparedStatement changeNames = connection.prepareStatement("UPDATE minions AS m SET m.name = CONCAT(UPPER(LEFT(m.name, 1)), SUBSTR(m.name, 2)) WHERE m.id = ?");

        for (int id : ids) {
            increaseAge.setInt(1, id);
            increaseAge.executeUpdate();

            changeNames.setInt(1, id);
            changeNames.executeUpdate();
        }

        Statement getAllMinions = connection.createStatement();
        String query = "SELECT m.name, m.age FROM minions AS m";
        ResultSet resultSet = getAllMinions.executeQuery(query);

        while (resultSet.next()) {
            System.out.println(resultSet.getString("name") + " " + resultSet.getInt("age"));
        }
    }

    /**
     * Problem 9 - Increase Age Stored Procedure
     */
    private void increaseAgeStoredProcedure() throws IOException, SQLException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int id = Integer.parseInt(reader.readLine());

        CallableStatement callableStatement = connection.prepareCall("CALL usp_get_older(?)");
        callableStatement.setInt(1, id);
        callableStatement.execute();

        PreparedStatement getResult = connection.prepareStatement("SELECT name, age from minions WHERE  id= ?");
        getResult.setInt(1,id);
        ResultSet resultSet = getResult.executeQuery();
        resultSet.beforeFirst();
        while (resultSet.next()){
            System.out.printf("%s %d", resultSet.getString("name"), resultSet.getInt("age"));
        }

    }
}
