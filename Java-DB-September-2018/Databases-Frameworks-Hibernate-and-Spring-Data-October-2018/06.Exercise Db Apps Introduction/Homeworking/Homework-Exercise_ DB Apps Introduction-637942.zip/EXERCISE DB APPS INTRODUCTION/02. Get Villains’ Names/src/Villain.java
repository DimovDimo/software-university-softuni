public class Villain {
    public String name;
    public long minionsCount;

    public Villain(String name, long minionsCount){
        this.name = name;
        this.minionsCount = minionsCount;
    }
}
