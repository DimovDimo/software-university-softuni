public class Minion {
    public String name;

    public Minion(String name){
        this.name = name;
    }
}
