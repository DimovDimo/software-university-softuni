package DBApplications.problem1;

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Engine implements Runnable {
    private Connection connection;

    public Engine(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void run() {
        try {
            this.addMinion();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    /**
     * problem 2  GetVillains'Names
     */
    private void getVillainsNames() throws SQLException {
        String query = "SELECT v.name, count(m.name) AS counter FROM villains AS v JOIN minions_villains as mv ON v.id = mv.villain_id JOIN minions AS m ON m.id = mv.minion_id GROUP BY v.name HAVING counter > ? ORDER BY counter DESC";
        PreparedStatement preparedStatement = this.connection.prepareStatement(query);
        preparedStatement.setInt(1, 10);
        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            System.out
                    .println(String.format("%s %d",
                            resultSet.getString(1),
                            resultSet.getInt(2)));
        }
    }

    /**
     * problem 3 Get Minion Names
     */
    public void getMinionNames() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        String query = "SELECT v.name,m.name,m.age FROM villains AS v JOIN minions_villains AS mv ON v.id = mv.villain_id JOIN minions m ON mv.minion_id = m.id WHERE v.id = ?";
        PreparedStatement preparedStatement = this.connection.prepareStatement(query);
        preparedStatement.setInt(1, Integer.parseInt(scanner.nextLine()));
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            System.out.printf(
                    "Villain: %s%n" + "1. %s %d%n",
                    resultSet.getString(1),
                    resultSet.getString(2),
                    resultSet.getInt(3));


            int row = 2;
            while (resultSet.next()) {
                System.out.println(String.format(
                        "%d. %s %d",
                        row,
                        resultSet.getString(2),
                        resultSet.getInt(3)));
                row++;

            }
        }else {
            System.out.printf("No villain with ID %d exists in the database.",scanner);
        }


    }

    /**
     * Problem 4 AddMinion
     */
    private void addMinion() throws SQLException {
        Scanner scanner = new Scanner(System.in);

        String[] minionParams = scanner.nextLine().split("\\s+");
        String[] villainParams = scanner.nextLine().split("\\s+");

        String minionName = minionParams[1];
        int age = Integer.parseInt(minionParams[2]);
        String townName = minionParams[3];
        String villainName = villainParams[1];
        if (!this.checkEntity(townName,"towns")){
            this.addTown(townName);
        }
        if (!checkEntity(villainName,"villains")){
            this.addVillain(villainName);
        }
        int townId = this.getId("towns",townName);
        this.setMinion(minionName,age,townId);
        int minionId = this.getId("minions", minionName);
        int villainId = this.getId("villains",villainName);
        this.insertMappingTable(minionId,villainId);

        System.out.printf("Successfully added %s to be minion of %s%n",minionName,villainName);



    }
    boolean checkEntity(String name, String tableName) throws SQLException {
        String query = String.format("SELECT * FROM %s WHERE name = '%s'",tableName,name);
        PreparedStatement preparedStatement = this.connection.prepareStatement(query);


        ResultSet resultSet = preparedStatement.executeQuery(query);
        if (resultSet.next()){
            return true;
        }
        return false;
    }
    private void addTown(String townName) throws SQLException {
        String query = String.format("INSERT INTO towns(name,country) VALUES('%s',NULL)",townName);
        PreparedStatement statement = this.connection.prepareStatement(query);
        statement.execute();
        System.out.println(String.format("Town %s was added to the database.",townName));

    }
    private void addVillain(String villainName) throws SQLException {
        String query = String.format("INSERT INTO villains(name,evilness_factor) VALUES('%s','evil')",villainName);
        PreparedStatement preparedStatement = this.connection.prepareStatement(query);
        preparedStatement.execute();
        System.out.printf("Villain %s was added to the database.%n",villainName);
    }
    private int getId(String tableName, String name) throws SQLException {
        String query = String.format("SELECT id FROM %s WHERE name = '%s'",tableName,name);
        PreparedStatement preparedStatement = this.connection.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();
        resultSet.next();

        return resultSet.getInt(1);
    }
    private void setMinion(String name,int age,int town_id) throws SQLException {
        String query = String.format("INSERT INTO minions(name,age,town_id) VALUES('%s',%d,%d)",name,age,town_id);
        PreparedStatement preparedStatement = this.connection.prepareStatement(query);
        preparedStatement.execute();
    }
    private void insertMappingTable(int minionId, int villainId) throws SQLException {
        String query = String.format("INSERT INTO minions_villains(minion_id,villain_id) VALUES('%d','%d')",minionId,villainId);
        PreparedStatement preparedStatement = this.connection.prepareStatement(query);

    }
    /**
     * Problem 5 Change Town Name Casing
     */


}


