package DBApplications.problem1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Application {
    public static void main(String[] args) throws SQLException {


        String connectionString = "jdbc:mysql://localhost:3306/minions_db";
        Connection connection = DriverManager.getConnection(connectionString, "root", "0000");

        Engine engine = new Engine(connection);
        engine.run();
    }
}
