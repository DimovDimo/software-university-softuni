package app;

import entities.*;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Tuple;
import javax.persistence.criteria.Root;
import java.math.BigDecimal;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Engine implements Runnable {

    private EntityManager entityManager;

    public Engine(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public void run() {
        p13();
    }


    //2.	Remove Objects
    private void p2() {
        this.entityManager.getTransaction().begin();
        List<Town> towns = this.entityManager.createNativeQuery("SELECT * FROM soft_uni.towns", Town.class).getResultList();
        towns.forEach(town -> {
            if (town.getName().length() < 5) {
                this.entityManager.detach(town);
                String townName = town.getName().toLowerCase();
                town.setName(townName);
                this.entityManager.merge(town);
                this.entityManager.flush();
            }
        });
        this.entityManager.getTransaction().commit();
        return;
    }

    //3.	Contains Employee
    private void p3() {
        Scanner console = new Scanner(System.in);
        String input = console.nextLine();
        this.entityManager.getTransaction().begin();
        try {
            Employee employee = this.entityManager.createQuery("FROM Employee WHERE concat(firstName, ' ', lastName) = :name", Employee.class).setParameter("name", input).getSingleResult();
            this.entityManager.getTransaction().commit();
            System.out.println("Yes");
        } catch (NoResultException e) {
            System.out.println("No");
        }
    }

    //4.	Employees with Salary Over 50 000
    private void p4() {
        this.entityManager.getTransaction().begin();
        List<Employee> employees = this.entityManager.createQuery("FROM Employee WHERE salary > 50000", Employee.class).getResultList();
        this.entityManager.getTransaction().commit();
        employees.forEach(employee -> System.out.println(employee.getFirstName()));

    }

    //5.	Employees from Department
    private void p5() {
        this.entityManager.getTransaction().begin();
        List<Employee> employees = this.entityManager.createQuery("FROM Employee WHERE department.name = 'Research and Development' ORDER BY salary ASC, id ASC", Employee.class).getResultList();
        this.entityManager.getTransaction().commit();
        employees.forEach(employee -> System.out.println(String.format("%s %s from %s - $%.2f", employee.getFirstName(), employee.getLastName(), employee.getDepartment().getName(), employee.getSalary())));
    }

    //6.	Adding a New Address and Updating Employee
    private void p6() {
        Scanner console = new Scanner(System.in);
        String input = console.nextLine();

        Address address = new Address();
        address.setText("Vitoshka 15");

        this.entityManager.getTransaction().begin();
        Town town = this.entityManager.createQuery("FROM Town WHERE name = 'Sofia'", Town.class).getSingleResult();
        address.setTown(town);
        this.entityManager.persist(address);
        this.entityManager.getTransaction().commit();

        this.entityManager.getTransaction().begin();
        Employee employee = this.entityManager.createQuery("FROM Employee WHERE lastName = :input", Employee.class).setParameter("input", input).getSingleResult();
        this.entityManager.getTransaction().commit();

        this.entityManager.getTransaction().begin();
        this.entityManager.detach(employee);
        employee.setAddress(address);
        this.entityManager.merge(employee);
        this.entityManager.flush();
        this.entityManager.getTransaction().commit();

    }

    //7.	Addresses with Employee Count
    private void p7() {
        this.entityManager.getTransaction().begin();
        List<Address> adds = this.entityManager.createQuery("FROM Address ORDER BY employees.size DESC, id ASC", Address.class).setMaxResults(10).getResultList();
        adds.forEach(a -> System.out.println(String.format("%s, %s - %d employees", a.getText(), a.getTown().getName(), a.getEmployees().size())));
    }

    //8.	Get Employee with Project
    private void p8() {
        Scanner console = new Scanner(System.in);
        int input = Integer.parseInt(console.nextLine());
        this.entityManager.getTransaction().begin();
        Employee employee = this.entityManager.find(Employee.class, input);
        System.out.println(String.format("%s - %s", String.format("%s %s", employee.getFirstName(), employee.getLastName()), employee.getJobTitle()));
        List<Project> projects = employee.getProjects().stream().sorted(Comparator.comparing(Project::getName)).collect(Collectors.toList());
        projects.forEach(p -> System.out.println(p.getName()));
    }

    //9.	Find Latest 10 Projects
    private void p9() {
        this.entityManager.getTransaction().begin();
        List<Project> a = this.entityManager.createQuery("FROM Project ORDER BY startDate DESC, name ASC", Project.class).setMaxResults(10).getResultList();
        a.forEach(p -> System.out.println(String.format("Project name: %s%n     Project Description: %s%n     Project Start Date: %s%n     Project End Date: %s", p.getName(), p.getDescription(), p.getStartDate(), p.getEndDate())));
    }

    //10.	Increase Salaries
    private void p10() {
        this.entityManager.getTransaction().begin();
        List<Employee> employees = this.entityManager.createQuery("FROM Employee WHERE department.name IN ('Engineering', 'Marketing', 'Tool Design', 'Information Services')", Employee.class).getResultList();
        System.out.println();
        employees.forEach(e -> {
            this.entityManager.detach(e);
            BigDecimal salary = e.getSalary();
            BigDecimal newSalary = salary.multiply(new BigDecimal(1.12));
            e.setSalary(newSalary);
            this.entityManager.merge(e);
            this.entityManager.flush();
        });
        this.entityManager.getTransaction().commit();
    }

    //11.	Remove Towns
    private void p11() {
        Scanner console = new Scanner(System.in);
        String input = console.nextLine();
        this.entityManager.getTransaction().begin();
        Town town = this.entityManager.createQuery("FROM Town WHERE name = :input", Town.class).setParameter("input", input).getSingleResult();
        List<Address> addresses = this.entityManager.createQuery("FROM Address WHERE town.id = :id", Address.class).setParameter("id", town.getId()).getResultList();
        addresses.forEach(a -> {
            List<Employee> employees = this.entityManager.createQuery("FROM Employee WHERE address.id = :id", Employee.class).setParameter("id", a.getId()).getResultList();
            employees.forEach(e -> this.entityManager.remove(e));
            this.entityManager.remove(a);
        });
        System.out.println(String.format("%d address in %s deleted", addresses.size(), town.getName()));
        this.entityManager.remove(town);
        this.entityManager.flush();
        this.entityManager.getTransaction().commit();
    }

    //12.	Find Employees by First Name
    private void p12() {
        Scanner console = new Scanner(System.in);
        String input = console.nextLine();
        this.entityManager.getTransaction().begin();
        String param = input + "%";
        List<Employee> employees = this.entityManager.createQuery("FROM Employee WHERE firstName LIKE :param", Employee.class).setParameter("param", param).getResultList();
        employees.forEach(e -> System.out.println(String.format("%s %s - %s - ($%.2f)", e.getFirstName(), e.getLastName(), e.getJobTitle(), e.getSalary())));
    }

    //13.	Employees Maximum Salaries
    private void p13() {
        this.entityManager.getTransaction().begin();
        List<Department> departments = this.entityManager.createQuery("FROM Department", Department.class).getResultList();
        departments.forEach(d -> d.getEmployees()
                .stream()
                .collect(Collectors.toList())
                .stream()
                .filter(employee -> employee.getSalary().compareTo(new BigDecimal(30000)) > 0 || employee.getSalary().compareTo(new BigDecimal(70000)) < 0)
                .sorted((e1, e2) -> e2.getSalary().compareTo(e1.getSalary()))
                .limit(1)
                .forEach(e -> System.out.println(String.format("%s - %.2f", d.getName(), e.getSalary()))));
    }
}
