package app;

import app.entities.Address;
import app.entities.Employee;
import app.entities.Town;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Engine implements  Runnable {
    public  final EntityManager entityManager;

    public Engine(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public void run() {
        //this.removeObjects(); /** problem 02**/
        //this.containsEmployee();  /*Problem 03*/
        //this.employeesWithSalaryOver(); /*Problem 04*/
        //this.employeesFromDepartment();  /*Problem 05*/
        //Problem 06
        /*try {
            this.addingNewAddressAndUpdatingEmployee();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
        //Problem 07
        this.AddressWithEmployeeCount();
    }

    /** Problem 02 Remove objects **/
    private void removeObjects () {
        this.entityManager.getTransaction().begin();
        List<Town> towns = this.entityManager.createQuery("select t  from Town t where length(t.name) >5")
                .getResultList();
        for(Town town : towns) {
            this.entityManager.detach(town);
            town.setName(town.getName().toLowerCase());
            this.entityManager.merge(town);
        }
        this.entityManager.getTransaction().commit();

    }

    /** Problem 03 Contains Employee**/
    private  void containsEmployee () {
        Scanner scanner = new Scanner(System.in);
        String name = scanner.nextLine();

        this.entityManager.getTransaction().begin();

        try {
            Employee employee = this.entityManager.createQuery("FROM Employee WHERE concat(first_name, ' ', last_name) = :name", Employee.class)
                    .setParameter("name", name)
                    .getSingleResult();
            System.out.println("Yes");
        } catch (NoResultException nre) {
            System.out.println("No");
        }

        this.entityManager.getTransaction().commit();

    }

    //Problem 04
    private  void employeesWithSalaryOver () {
        this.entityManager.getTransaction().begin();
        List<Employee> employeeList = this.entityManager.createQuery("FROM Employee WHERE salary > 50000", Employee.class)
                .getResultList();
        employeeList.stream().forEach(x-> System.out.println(x.getFirstName()));
        this.entityManager.getTransaction().commit();
    }

    // Problem 05
    private  void employeesFromDepartment() {
        this.entityManager.getTransaction().begin();
        List<Employee> employeeList = entityManager.createQuery("Select e from Employee e where e.department.name = 'Research and Development' order by e.salary asc, e.id asc", Employee.class)
                .getResultList();
        employeeList.stream().forEach(e-> {
            String output = String.format("%s %s from Research and Development - $%.2f", e.getFirstName(), e.getLastName(), e.getSalary() );
            System.out.println(output);
        });
        this.entityManager.getTransaction().commit();
    }

    //Problem 06
    private void addingNewAddressAndUpdatingEmployee() throws IOException {
        entityManager.getTransaction().begin();
        Address newAddress = new Address();
        newAddress.setText("Vitoshka 15");
        Town town = this.entityManager.createQuery("FROM Town where name = 'Sofia'", Town.class)
                .getSingleResult();
        newAddress.setTown(town);
        entityManager.persist(newAddress);

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String lastName = reader.readLine();

        Employee employee = entityManager.createQuery("Select e from Employee e WHERE e.lastName = :name", Employee.class)
                .setParameter("name", lastName)
                .getSingleResult();

        employee.setAddress(newAddress);
        entityManager.persist(employee);
        entityManager.getTransaction().commit();

        //There is absolutely no need to detach the employee prior persist it as trainer show.
    }
    //Problem 07
    private  void AddressWithEmployeeCount  () {
        entityManager.getTransaction().begin();
        List<Address> addresses
                = entityManager.createQuery("FROM Address  order by employees.size desc, town_id asc " , Address.class)
                .setMaxResults(10)
                .getResultList();
        addresses.stream().forEach(a->{
            String output = String.format("%s, %s - %d employees", a.getText(), a.getTown().getName(), a.getEmployees().size());
            System.out.println(output);
        });

        entityManager.getTransaction().commit();

    }



}
