package problems;


import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.List;


public class P13EmployeesMaximumSalary {
	public static void resolveP13EmployeesMaximumSalary(EntityManager entityManager) {
		String query = "SELECT d.name, MAX (e.salary) " +
				"FROM Employee e JOIN e.department d " +
				"WHERE e.salary NOT BETWEEN 30000 AND 70000 " +
				"GROUP BY d.name ";
		
		List resultList = entityManager
				.createQuery(query)
				.getResultList();
		
		for (int i = 0; i < resultList.size(); i++) {
			Object[] row = (Object[]) resultList.get(i);
			String departmentName = ((String) row[0]);
			double maxSalary = ((BigDecimal) row[1]).doubleValue();
			System.out.println(departmentName + " - " + maxSalary);
		}
		
	}
}
