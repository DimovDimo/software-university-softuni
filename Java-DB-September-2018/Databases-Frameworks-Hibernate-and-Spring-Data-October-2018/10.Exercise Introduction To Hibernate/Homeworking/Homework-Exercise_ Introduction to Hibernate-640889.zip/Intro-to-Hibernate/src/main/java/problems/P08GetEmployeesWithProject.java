package problems;

import entities.Employee;
import entities.Project;

import javax.persistence.EntityManager;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class P08GetEmployeesWithProject {
	public static void resolveP08GetEmployeesWithProject(EntityManager entityManager){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter employee id: ");
		int id = Integer.parseInt(scanner.nextLine());
		
		String query = "SELECT e FROM Employee e JOIN e.projects p " +
				"WHERE e.id = :id ";
		
		Employee employee = entityManager
				.createQuery(query,Employee.class)
				.setParameter("id",id)
				.getSingleResult();
		
		System.out.printf("%s %s - %s\n",
				employee.getFirstName(),employee.getLastName(),employee.getJobTitle());
		employee.getProjects().stream()
				.sorted(Comparator.comparing(Project::getName))
				.forEach(project -> System.out.println("     "+project.getName()));
		
	}
	
	
}
