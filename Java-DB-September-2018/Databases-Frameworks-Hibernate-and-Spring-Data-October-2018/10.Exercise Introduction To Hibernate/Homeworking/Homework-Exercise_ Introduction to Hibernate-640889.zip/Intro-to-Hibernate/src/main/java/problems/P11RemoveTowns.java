package problems;

import entities.Address;

import javax.persistence.EntityManager;

import java.util.List;
import java.util.Scanner;

public class P11RemoveTowns {
	public static void resolveP11RemoveTowns(EntityManager entityManager){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter town name: ");
		String townName = scanner.nextLine();
		
		entityManager.getTransaction().begin();
		
		String queryGetAddresses = "SELECT a FROM Address a " +
				"JOIN a.employees e JOIN a.town t " +
				"WHERE t.name = :townName";
		
		List<Address> addresses = entityManager
				.createQuery(queryGetAddresses,Address.class)
				.setParameter("townName",townName)
				.getResultList();
		
		addresses.forEach(address -> {
			address.getEmployees().forEach(employee -> {
				employee.setAddress(null);
			});
			address.setTown(null);
			entityManager.remove(address);
		});
		entityManager.flush();
		
		String queryGetTownId = "DELETE FROM Town t WHERE t.name = :townName";
		
		entityManager
				.createQuery(queryGetTownId)
				.setParameter("townName",townName)
				.executeUpdate();
		
		System.out.printf("%d address in %s deleted\n",addresses.size(),townName);
		
		entityManager.getTransaction().commit();
	}
}
