package problems;

import entities.Employee;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import java.util.Scanner;

public class P03ContainsEmployee {
	public static void resolveP03ContainsEmployee(EntityManager entityManager){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter emloyee full name: ");
		String inputName = scanner.nextLine().trim();
		
		try {
			Employee emloyee = entityManager
					.createQuery("FROM Employee WHERE concat(first_name, ' ',last_name)= :name",
							Employee.class)
					.setParameter("name",inputName)
					.getSingleResult();
			System.out.println("Yes");
		} catch (NoResultException e) {
			System.out.println("No");
		}
		
	}
}
