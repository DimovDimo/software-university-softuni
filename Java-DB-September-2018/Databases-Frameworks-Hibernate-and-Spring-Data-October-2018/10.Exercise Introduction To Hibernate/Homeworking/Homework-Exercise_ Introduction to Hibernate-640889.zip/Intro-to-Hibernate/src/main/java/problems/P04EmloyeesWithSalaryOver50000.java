package problems;

import entities.Employee;

import javax.persistence.EntityManager;
import java.util.List;

public class P04EmloyeesWithSalaryOver50000 {
	public static void resolveP04EmplooyeesWithSalaryOver50000(EntityManager entityManager){
		entityManager.getTransaction().begin();
		
		List<Employee> emloyees = entityManager
				.createQuery("FROM Employee WHERE salary > 50000",Employee.class)
				.getResultList();
		emloyees.forEach(employee -> System.out.println(employee.getFirstName()));
	
		entityManager.getTransaction().commit();
	}
}
