package problems;

import entities.Employee;

import javax.persistence.EntityManager;
import java.util.List;
import java.util.Scanner;

public class P12FindEmployeesByFirstName {
	public static void resolveP12FindEmployeesByFirstName(EntityManager entityManager){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter pattern for first name to begin with: ");
		String pattern = scanner.nextLine().trim().toLowerCase();
		
		String query = "SELECT e FROM Employee e WHERE LOWER(e.firstName) LIKE :pattern";
		List<Employee> employees = entityManager
				.createQuery(query,Employee.class)
				.setParameter("pattern", pattern+"%")
				.getResultList();
		
		employees.forEach(employee -> System.out.printf("%s %s - %s - (%.2f)\n",
				employee.getFirstName(),employee.getLastName(),
				employee.getJobTitle(),employee.getSalary()));
		
	}
	
}
