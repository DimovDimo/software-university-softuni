package problems;

import entities.Address;
import entities.Employee;
import entities.Town;

import javax.persistence.EntityManager;
import java.util.Scanner;

public class P06AddNewAdressAndUpdateEmployee {
	public static final String addressText = "Vitoshka 15";
	
	public static void resolveP06AddNewAddressAndUpdateEmployee(EntityManager entityManager){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter employee last name: ");
		String lastName = scanner.nextLine();
		String querySelect = "FROM Employee WHERE last_name = :name";
		
		entityManager.getTransaction().begin();
		
		Town town = entityManager
				.createQuery("from Town where name = 'Sofia'",Town.class)
				.getSingleResult();
		
		Address address = new Address();
		address.setText(addressText);
		address.setTown(town);
		entityManager.persist(address);
		
		Employee employee = entityManager
				.createQuery(querySelect,Employee.class)
				.setParameter("name",lastName)
				.getSingleResult();
		
		employee.setAddress(address);
		
		entityManager.persist(employee);
		
		
		entityManager.getTransaction().commit();
	}
}
