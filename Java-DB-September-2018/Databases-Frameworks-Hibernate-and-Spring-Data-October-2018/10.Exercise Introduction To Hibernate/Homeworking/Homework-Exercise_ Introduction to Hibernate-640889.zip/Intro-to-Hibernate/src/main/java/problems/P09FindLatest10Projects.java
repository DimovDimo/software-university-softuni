package problems;

import entities.Project;

import javax.persistence.EntityManager;
import java.util.Comparator;
import java.util.List;

public class P09FindLatest10Projects {
	public static void resolveP09FindLatest10Projects(EntityManager entityManager){
		String query = "FROM Project p ORDER BY p.startDate DESC";
		List<Project> projects = entityManager
				.createQuery(query,Project.class)
				.setMaxResults(10)
				.getResultList();
		 
		projects.stream()
				.sorted(Comparator.comparing(Project::getName))
				.forEach(p -> System.out.printf(
						"Project name: %s\n" +
						"       Project Description: %s\n" +
						"       Project Start Date: %s\n" +
						"       Project Start Date: %s\n",
						p.getName(),p.getDescription(),
						p.getStartDate(),p.getEndDate()
				));
		
	}
	
}
