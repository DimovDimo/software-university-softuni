package problems;

import entities.Employee;

import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.List;

public class P10IncreaseSalary {
	public static void resolveP10IncreaseSalary(EntityManager entityManager){
		entityManager.getTransaction().begin();
		String query = "SELECT e FROM Employee e JOIN e.department d " +
				"WHERE d.name IN ('Engineering','Tool Design','Marketing','Information Services')";
		List<Employee> employees = entityManager
				.createQuery(query,Employee.class)
				.getResultList();
		employees.forEach(e -> {
			e.setSalary(BigDecimal.valueOf(e.getSalary().doubleValue()*1.12));
			System.out.printf("%s %s ($%.2f)\n",e.getFirstName(),e.getLastName(),e.getSalary());
		});
		
		entityManager.flush();
		entityManager.getTransaction().commit();
	}
	
}
