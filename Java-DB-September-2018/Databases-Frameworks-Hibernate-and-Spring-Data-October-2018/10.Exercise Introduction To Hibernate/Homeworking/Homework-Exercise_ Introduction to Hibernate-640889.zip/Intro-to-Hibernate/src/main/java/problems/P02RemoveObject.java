package problems;

import entities.Town;

import javax.persistence.EntityManager;
import java.util.List;

public class P02RemoveObject {
	public static void resolveP02RemoveObject(EntityManager entityManager){
		entityManager.getTransaction().begin();
		
		List<Town> towns = entityManager
				.createQuery("FROM Town",Town.class)
				.getResultList();
		towns.forEach(town -> {
			if (town.getName().length()>5){
				entityManager.detach(town);
			}else {
				town.setName(town.getName().toLowerCase());
				entityManager.persist(town);
			}
		});
		
		entityManager.getTransaction().commit();
	}
	
}
