package problems;

import javax.persistence.EntityManager;
import java.util.List;

public class P07AddressesWithEmployeeCount {
	public static void resolveP07AddressesWithEmloyeeCount(EntityManager entityManager){
		String query = "SELECT a.text,t.name,count(e.id) " +
				"FROM Employee e JOIN e.address a JOIN a.town t " +
				"GROUP BY a.text ORDER BY count(e.id) DESC, t.id ASC";
		List resultList = entityManager.createQuery(query)
				.setMaxResults(10)
				.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			Object[] result = (Object[]) resultList.get(i);
			String address = ((String) result[0]);
			String town = result[1].toString();
			long count = (long) result[2];
			System.out.printf("%s, %s - %d employees\n",
					address,town,count);
		}
		
	}
}
