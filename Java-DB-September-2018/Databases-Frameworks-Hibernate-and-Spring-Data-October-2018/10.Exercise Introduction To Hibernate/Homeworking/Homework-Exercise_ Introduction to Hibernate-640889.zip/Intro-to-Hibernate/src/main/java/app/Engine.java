package app;

import problems.*;

import javax.persistence.EntityManager;
import java.util.Scanner;

public class Engine implements Runnable {
	
	private static EntityManager entityManager;
	
	public Engine(EntityManager entityManager) {
		Engine.entityManager = entityManager;
	}
	
	@Override
	public void run() {
		while (true) {
			Scanner scanner = new Scanner(System.in);
			System.out.print("\n2 -> P02RemoveObject\n" +
					"3 -> P03ContainsEmployee\n" +
					"4 -> P04EmloyeesWithSalaryOver50000\n" +
					"5 -> P05EmployeesFromDepartment\n" +
					"6 -> P06AddNewAdressAndUpdateEmployee\n" +
					"7 -> P07AddressesWithEmployeeCount\n" +
					"8 -> resolveP08GetEmployeesWithProject\n" +
					"9 -> P09FindLatest10Projects\n" +
					"10 -> P10IncreaseSalary\n" +
					"11 -> P11RemoveTowns\n" +
					"12 -> P12FindEmployeesByFirstName\n" +
					"13 -> P13EmployeesMaximumSalary\n" +
					"Enter number from 2 to 13 to run problem solution\n" +
					"or 'q' for quit: ");
			String input = scanner.nextLine();
			if (input.equalsIgnoreCase("q")) {
				System.exit(0);
			}
			
			chooseAction(input);
		}
		
	}
	
	private static void chooseAction (String command){
		
		switch (command) {
			case "2":
				P02RemoveObject
						.resolveP02RemoveObject(entityManager);
				break;
			case "3":
				P03ContainsEmployee
						.resolveP03ContainsEmployee(entityManager);
				break;
			case "4":
				P04EmloyeesWithSalaryOver50000
						.resolveP04EmplooyeesWithSalaryOver50000(entityManager);
				break;
			case "5":
				P05EmployeesFromDepartment
						.resolveP05EmployeesFromDepartment(entityManager);
				break;
			case "6":
				P06AddNewAdressAndUpdateEmployee
						.resolveP06AddNewAddressAndUpdateEmployee(entityManager);
				break;
			case "7":
				P07AddressesWithEmployeeCount
						.resolveP07AddressesWithEmloyeeCount(entityManager);
				break;
			case "8":
				P08GetEmployeesWithProject
						.resolveP08GetEmployeesWithProject(entityManager);
				break;
			case "9":
				P09FindLatest10Projects
						.resolveP09FindLatest10Projects(entityManager);
				break;
			case "10":
				P10IncreaseSalary
						.resolveP10IncreaseSalary(entityManager);
				break;
			case "11":
				P11RemoveTowns
						.resolveP11RemoveTowns(entityManager);
				break;
			case "12":
				P12FindEmployeesByFirstName
						.resolveP12FindEmployeesByFirstName(entityManager);
				break;
			case "13":
				P13EmployeesMaximumSalary
						.resolveP13EmployeesMaximumSalary(entityManager);
				break;
			default:
				System.out.println("Invalid input");
				break;
		}
	}
}

