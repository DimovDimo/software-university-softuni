package problems;

import entities.Employee;

import javax.persistence.EntityManager;
import java.util.List;

public class P05EmployeesFromDepartment {
	public static void resolveP05EmployeesFromDepartment(EntityManager entityManager){
		String query = "SELECT e FROM Employee e JOIN e.department d" +
				" WHERE d.name = :department" +
				" ORDER BY e.salary,e.id";
		
		
		List<Employee> employees = entityManager
				.createQuery(query,Employee.class)
				.setParameter("department","Research and Development")
				.getResultList();
		
		employees.forEach(employee -> {
			System.out.printf("%s %s from %s - $%s\n",
					employee.getFirstName(),employee.getLastName(),
					employee.getDepartment().getName(),employee.getSalary());
		});
		
	}
}
