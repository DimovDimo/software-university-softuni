package C03_Ferrari;

public interface Car {

    String getModel();

    String getDriver();

    void brakes();

    void gasPedal();
}
