package B02_MultipleImplementation;

public interface Identifiable {

    String getId();
}
