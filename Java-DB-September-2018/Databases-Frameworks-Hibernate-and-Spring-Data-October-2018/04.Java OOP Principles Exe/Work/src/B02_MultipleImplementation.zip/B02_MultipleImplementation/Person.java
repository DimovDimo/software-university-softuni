package B02_MultipleImplementation;

public interface Person {

    String getName();

    int getAge();
}
