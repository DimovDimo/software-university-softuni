package B02_MultipleImplementation;

public interface Birthable {

    String getBirthdate();
}
