package D04_Telephony;

public interface Callable {
    void call(String[] phones);
}
