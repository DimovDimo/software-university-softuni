package D04_Telephony;

public interface Browsable {
    void browse(String[] sites);
}
