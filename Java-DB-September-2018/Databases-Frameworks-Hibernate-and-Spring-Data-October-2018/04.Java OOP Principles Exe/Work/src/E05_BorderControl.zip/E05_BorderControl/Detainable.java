package E05_BorderControl;

public interface Detainable {

    void dataine(String endOfId);
}
