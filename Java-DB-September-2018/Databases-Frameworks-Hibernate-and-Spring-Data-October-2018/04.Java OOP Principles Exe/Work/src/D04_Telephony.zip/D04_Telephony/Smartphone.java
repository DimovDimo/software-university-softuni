package D04_Telephony;

import java.util.regex.Pattern;

public class Smartphone implements Callable, Browsable {
    @Override
    public void browse(String[] sites) {
        for (String site : sites) {
            if (Pattern.matches("[0-9]+", site)){
                System.out.println("Invalid URL!");
            } else {
                System.out.printf("Browsing: %s%n", site);
            }
        }
    }

    @Override
    public void call(String[] phones) {
        for (String phone : phones) {
            if (Pattern.matches("[^0-9]+", phone)){
                System.out.println("Invalid number!");
            } else {
                System.out.printf("Calling... %s%n", phone);
            }
        }
    }
}
