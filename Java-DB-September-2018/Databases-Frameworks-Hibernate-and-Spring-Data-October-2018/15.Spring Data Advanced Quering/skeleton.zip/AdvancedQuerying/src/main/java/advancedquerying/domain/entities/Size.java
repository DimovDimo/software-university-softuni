package advancedquerying.domain.entities;

public enum Size {

    SMALL, MEDIUM, LARGE;
}
