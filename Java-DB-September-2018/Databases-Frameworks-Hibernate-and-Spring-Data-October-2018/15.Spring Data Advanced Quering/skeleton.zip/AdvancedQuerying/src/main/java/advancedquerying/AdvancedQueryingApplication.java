package advancedquerying;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvancedQueryingApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdvancedQueryingApplication.class, args);
    }
}
