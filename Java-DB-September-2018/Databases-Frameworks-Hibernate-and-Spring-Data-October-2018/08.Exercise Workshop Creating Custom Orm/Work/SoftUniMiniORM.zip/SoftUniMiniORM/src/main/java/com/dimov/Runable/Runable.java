package com.dimov.Runable;

public interface Runable {
    void run();
}
