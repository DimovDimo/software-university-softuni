package entities;

import db.annotations.Column;
import db.annotations.Entity;
import db.annotations.PrimaryKey;

@Entity(name="managers")
public class Manager {
   @PrimaryKey(name="id")
    private long id;
   @Column(name="first_name")
    private String name;
    @Column(name="family_name")
    private String familyName;
    @Column(name="position")
    private String position;

    public Manager(String name, String familyName, String position) {
        this.name = name;
        this.familyName = familyName;
        this.position = position;
    }

    public long getId() {
        return this.id;
    }
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFamilyName() {
        return this.familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getPosition() {
        return this.position;
    }

    public void setPosition(String position) {
        this.position = position;
    }
}