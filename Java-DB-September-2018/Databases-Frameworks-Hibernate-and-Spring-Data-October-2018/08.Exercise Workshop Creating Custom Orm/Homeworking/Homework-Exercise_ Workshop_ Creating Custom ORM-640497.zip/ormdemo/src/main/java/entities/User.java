package entities;

import db.annotations.Column;
import db.annotations.Entity;
import db.annotations.PrimaryKey;

@Entity(name = "employees")
public class User {
    @PrimaryKey(name = "id")
    private long id;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "age")
    private int age;

    @Column(name="ucn")
    private String ucn;

    public User() {

    }

    public User(String firstName, String lastName,int age,String ucn) {
        this.setFirstName(firstName);
        this.setLastName(lastName);
        this.setAge(age);
        this.setUcn(ucn);
    }

    public long getId() {
        return this.id;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return this.age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getUcn() {
        return this.ucn;
    }

    public void setUcn(String ucn) {
        this.ucn = ucn;
    }

    @Override
    public String toString() {
        return String.format("%d | %s | %s | %d | %s ",
                this.getId(), this.getFirstName(), this.getLastName(),this.getAge(),this.getUcn());
    }
}
