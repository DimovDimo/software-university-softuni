import db.EntityDbContext;
import db.base.DbContext;
import entities.Department;
import entities.User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class App {
    private static final String CONNECTION_STRING =
            "jdbc:mysql://localhost:3306/soft_uni_simple";

    public static void main(String[] args) throws SQLException, IllegalAccessException, InstantiationException, NoSuchFieldException {
        Connection connection = getConnection();

   //     DbContext<Manager> managerDbContext = getDbContext(connection,Manager.class);
//        Manager manager = new Manager("Big","Boss","General Manager");
//        managerDbContext.persist(manager);


        DbContext<User> usersDbContext =
                getDbContext(connection, User.class);// employees db context
        DbContext<Department> departmentsDbContext =
                getDbContext(connection, Department.class); // departments db context
        //        DbContext<Department> departmentDbContext
//                = getDbContext(connection, Department.class);
//        departmentDbContext.find()
//                .forEach(System.out::println);
/*
test for persist method - insert + update
 */
//        User user = new User("Edelvays", "Petrovich",55,"234566");
//        User user2 = new User("Ideal", "Petrov2",33,"456789_upd");
//        usersDbContext.persist(user);
//        usersDbContext.persist(user2);
/*
find all
 */
        usersDbContext.find()
                .forEach(System.out::println);

        /* Test for find where
         */
        System.out.println("--------- find where ----------");
        //usersDbContext.find("age<30")
        // usersDbContext.find("ucn IS NULL")
        usersDbContext.find("first_name LIKE 'D%'")
                .forEach(System.out::println);
        /* find first

         */
        System.out.println("--------- find first ----------");
        // User user3 = ;
        System.out.println(usersDbContext.findFirst());

        /* find first where
         */
        System.out.println("--------- find first where ----------");
        User user4 = usersDbContext.findFirst("first_name LIKE 'D%'");
        System.out.println(user4);
        /* find By Id and persist-update
         */
        System.out.println("--------- find By Id and update----------");
        User upd_user = usersDbContext.findById(2);
        System.out.println(upd_user);
        upd_user.setAge(4);
        usersDbContext.persist(upd_user);
        System.out.println(upd_user);
        upd_user.setUcn("777777777");
        usersDbContext.persist(upd_user);
        System.out.println(upd_user);
        /* delete
         */
        System.out.println("--------- delete where ----------");
        usersDbContext.delete("id=13");
        usersDbContext.find()
                .forEach(System.out::println);

        connection.close();
    }

    private static <T> DbContext<T> getDbContext(Connection connection, Class<T> klass) throws SQLException {
        return new EntityDbContext<>(connection, klass);
    }

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                CONNECTION_STRING,
                "root",
                ""
        );
    }
}
