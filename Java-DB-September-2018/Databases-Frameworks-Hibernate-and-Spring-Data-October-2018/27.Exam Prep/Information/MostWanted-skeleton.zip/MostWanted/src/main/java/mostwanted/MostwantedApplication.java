package mostwanted;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MostwantedApplication {

    public static void main(String[] args) {
        SpringApplication.run(MostwantedApplication.class, args);
    }
}
