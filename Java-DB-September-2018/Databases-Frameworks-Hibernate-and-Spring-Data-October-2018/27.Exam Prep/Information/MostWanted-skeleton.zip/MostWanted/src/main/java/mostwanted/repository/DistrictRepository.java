package mostwanted.repository;

public interface DistrictRepository  {
    // TODO : Implement me
}
