package mostwanted.repository;

public interface RaceRepository {
    // TODO : Implement me
}
