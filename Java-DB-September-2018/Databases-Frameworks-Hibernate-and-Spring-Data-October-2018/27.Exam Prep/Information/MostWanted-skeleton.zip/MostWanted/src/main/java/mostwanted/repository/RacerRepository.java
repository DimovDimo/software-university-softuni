package mostwanted.repository;

public interface RacerRepository {
    // TODO : Implement me
}
