let Person = require('./persons');

let p = new Person('Pesho');
console.log(p.toString());

result.Person = Person;