package munchkin.web.servlets;

import munchkin.domain.entities.Cat;
import munchkin.service.htmlreader.HTMLReader;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.stream.Collectors;

@WebServlet("/cats/all")
public class AllCatsServlet extends HttpServlet {

    private final HTMLReader htmlReader;

    @Inject
    public AllCatsServlet(HTMLReader htmlReader) {
        this.htmlReader = htmlReader;
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        LinkedHashMap<String, Cat> allCats = ((LinkedHashMap<String, Cat>) req.getSession().getAttribute("cats"));

        String html;
        if (allCats == null || allCats.isEmpty()) {
            html = htmlReader.readHTML(req, "views\\no-cats.html");
        } else {
            String catListing = htmlReader.readHTML(req, "views\\cat-listing.html");
            String cats = allCats.values().stream()
                    .map(cat -> catListing.replace("{{name}}", cat.getName()))
                    .collect(Collectors.joining());

            html = htmlReader.readHTML(req, "views\\all-cats.html").replace("{{cats}}", cats);
        }
        resp.getWriter().println(html);
    }
}
