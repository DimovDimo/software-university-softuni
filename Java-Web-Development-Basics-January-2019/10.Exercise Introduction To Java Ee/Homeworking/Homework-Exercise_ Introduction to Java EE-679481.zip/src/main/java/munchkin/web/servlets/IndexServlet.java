package munchkin.web.servlets;

import munchkin.service.htmlreader.HTMLReader;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/")
public class IndexServlet extends HttpServlet {

    private final HTMLReader htmlReader;

    @Inject
    public IndexServlet(HTMLReader htmlReader) {
        this.htmlReader = htmlReader;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String html = htmlReader.readHTML(req, "views\\index.html");
        resp.getWriter().println(html);
    }
}
