package munchkin.web.servlets;

import munchkin.domain.entities.Cat;
import munchkin.service.htmlreader.HTMLReader;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedHashMap;

@WebServlet("/cats/profile")
public class CatsProfileServlet extends HttpServlet {

    private final HTMLReader htmlReader;

    @Inject
    public CatsProfileServlet(HTMLReader htmlReader) {
        this.htmlReader = htmlReader;
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String catName = req.getParameter("catName");
        Cat cat = ((LinkedHashMap<String, Cat>) req.getSession().getAttribute("cats")).get(catName);

        String html;
        if (cat == null) {
            html = htmlReader.readHTML(req, "views\\nonexistant-cat-profile.html")
                    .replace("{{name}}", catName);
        } else {
            html = htmlReader.readHTML(req, "views\\cat-profile.html")
                    .replace("{{name}}", catName)
                    .replace("{{breed}}", cat.getBreed())
                    .replace("{{color}}", cat.getColor())
                    .replace("{{legs}}", String.valueOf(cat.getNumberOfLegs()));
        }

        resp.getWriter().println(html);
    }
}
