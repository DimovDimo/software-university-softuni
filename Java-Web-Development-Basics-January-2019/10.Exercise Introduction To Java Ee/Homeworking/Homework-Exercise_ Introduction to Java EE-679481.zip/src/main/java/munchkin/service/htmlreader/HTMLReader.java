package munchkin.service.htmlreader;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public interface HTMLReader {
    String readHTML(HttpServletRequest req, String path) throws IOException;
}
