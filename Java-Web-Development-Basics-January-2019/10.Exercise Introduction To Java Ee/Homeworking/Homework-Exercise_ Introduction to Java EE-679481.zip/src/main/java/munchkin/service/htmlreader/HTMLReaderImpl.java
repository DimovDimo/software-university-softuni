package munchkin.service.htmlreader;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class HTMLReaderImpl implements HTMLReader {

    @Override
    public String readHTML(HttpServletRequest req, String path) throws IOException {
        String fullPath = getBasePath(req) + path;

        // Won't work if java version is < 11
        return Files.readString(Paths.get(fullPath));
    }

    private String getBasePath(HttpServletRequest req) {
        String projectPath = req.getServletContext().getRealPath("/");
        return projectPath + "WEB-INF\\classes\\";
    }
}
