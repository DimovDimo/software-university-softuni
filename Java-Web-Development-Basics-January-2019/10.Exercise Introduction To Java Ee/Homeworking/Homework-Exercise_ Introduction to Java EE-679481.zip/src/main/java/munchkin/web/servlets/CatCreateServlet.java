package munchkin.web.servlets;

import munchkin.domain.entities.Cat;
import munchkin.service.htmlreader.HTMLReader;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedHashMap;

@WebServlet("/cats/create")
public class CatCreateServlet extends HttpServlet {

    private final HTMLReader htmlReader;

    @Inject
    public CatCreateServlet(HTMLReader htmlReader) {
        this.htmlReader = htmlReader;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String html = htmlReader.readHTML(req, "views\\cat-create.html");
        resp.getWriter().println(html);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Cat cat = new Cat();

        String catName = req.getParameter("name");

        cat.setName(req.getParameter("name"));
        cat.setBreed(req.getParameter("breed"));
        cat.setColor(req.getParameter("color"));
        cat.setNumberOfLegs(Integer.parseInt(req.getParameter("legs")));

        if (req.getSession().getAttribute("cats") == null) {
            req.getSession().setAttribute("cats", new LinkedHashMap<>());
        }
        ((LinkedHashMap<String, Cat>) req.getSession().getAttribute("cats")).put(catName, cat);

        resp.sendRedirect(String.format("/cats/profile?catName=%s", catName));
    }
}
