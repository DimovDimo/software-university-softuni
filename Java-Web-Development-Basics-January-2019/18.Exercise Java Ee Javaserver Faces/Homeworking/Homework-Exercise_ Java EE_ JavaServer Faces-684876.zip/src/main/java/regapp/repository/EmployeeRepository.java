package regapp.repository;

import regapp.domain.entities.Employee;

import java.math.BigDecimal;

public interface EmployeeRepository extends GenericRepository<Employee, String> {
}
