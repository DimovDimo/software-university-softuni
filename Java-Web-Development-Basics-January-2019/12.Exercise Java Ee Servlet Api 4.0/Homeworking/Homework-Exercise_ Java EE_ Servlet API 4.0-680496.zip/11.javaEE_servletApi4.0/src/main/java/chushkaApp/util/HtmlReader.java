package chushkaApp.util;

import java.io.*;

public class HtmlReader {

    public String readHtmlFile(String filePath) throws IOException {
        BufferedReader buff = new BufferedReader(new InputStreamReader(new FileInputStream(new File(filePath))));
        StringBuilder htmlFileContent = new StringBuilder();
        String currentLine;
        while ((currentLine = buff.readLine()) != null) {
            htmlFileContent.append(currentLine).append(System.lineSeparator());
        }

        return htmlFileContent.toString().trim();
    }
}
