package chushkaApp.web.servlets;

import chushkaApp.domain.models.view.AllProductsViewModel;
import chushkaApp.service.ProductService;
import chushkaApp.util.HtmlReader;
import chushkaApp.util.ModelMapper;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@WebServlet("/")
public class indexServlet extends HttpServlet {

    private static final String INDEX_HTML_FILE_PATH = "C:\\Todor\\softuni\\SoftUni\\javaWeb2019\\javaWebDevelopmentBasic\\11.javaEE_servletApi4.0\\src\\main\\resources\\views\\index.html";
    private final ProductService productService;
    private final HtmlReader htmlReader;
    private final ModelMapper modelMapper;

    @Inject
    public indexServlet(ProductService productService, HtmlReader htmlReader, ModelMapper modelMapper) {
        this.productService = productService;
        this.htmlReader = htmlReader;
        this.modelMapper = modelMapper;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String htmlFileContent = this.htmlReader.readHtmlFile(INDEX_HTML_FILE_PATH)
                .replace("{{itemsList}}", this.formatListItems());

        resp.getWriter().println(htmlFileContent);
    }

    private String formatListItems() {
        List<AllProductsViewModel> allProductsViewModels = this.productService.findAllProducts()
                .stream()
                .map(productServiceModel -> this.modelMapper.map(productServiceModel, AllProductsViewModel.class))
                .collect(Collectors.toList());
        StringBuilder listItems = new StringBuilder();
        allProductsViewModels
                .forEach(p -> listItems.append(String.format("<li><a href=\"/products/details?name=%s\">%s</li>", p.getName(), p.getName()))
                        .append(System.lineSeparator()));
        return listItems.toString().trim();
    }
}
