package chushkaApp.domain.models.view;

public class ProductDetailsViewModel {
    private String name;
    private String description;
    private String type;

    public ProductDetailsViewModel() {
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
