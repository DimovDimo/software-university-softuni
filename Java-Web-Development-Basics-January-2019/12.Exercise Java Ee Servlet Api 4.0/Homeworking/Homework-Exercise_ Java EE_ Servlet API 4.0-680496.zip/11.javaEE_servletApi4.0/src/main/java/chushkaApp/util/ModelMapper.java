package chushkaApp.util;

public class ModelMapper extends org.modelmapper.ModelMapper {
}
