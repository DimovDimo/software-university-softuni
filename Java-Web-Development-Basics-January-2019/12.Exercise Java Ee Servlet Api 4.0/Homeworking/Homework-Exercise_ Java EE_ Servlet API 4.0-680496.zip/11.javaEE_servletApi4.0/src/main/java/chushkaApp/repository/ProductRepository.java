package chushkaApp.repository;

import chushkaApp.domain.entities.Product;
import chushkaApp.web.servlets.ProductDetailsServlet;

public interface ProductRepository extends GenericRepository<Product, String> {

   Product findByName(String name);
}
