package chyshka.models.view;

public class AllProductsViewModel {
    private String name ;

    public AllProductsViewModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
