package util;

import java.io.IOException;

public interface HtmlReader {
    String readHtmlFile(String path) throws IOException;
}
