package domain.enums;

public enum Type {
    Food, Domestic, Health, Cosmetic, Other
}
