package chushka.service;

import chushka.domain.models.service.ProductServiceModel;
import chushka.domain.models.view.ProductDetailsViewModel;

import java.util.List;

public interface ProductService {
    void save(ProductServiceModel productServicemodel);
    public List<ProductServiceModel> findAll();
    public ProductServiceModel findByName(String name);
}
