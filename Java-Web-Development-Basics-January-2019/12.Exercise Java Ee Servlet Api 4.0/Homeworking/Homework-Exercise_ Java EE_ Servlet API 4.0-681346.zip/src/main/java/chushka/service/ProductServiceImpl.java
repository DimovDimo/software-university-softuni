package chushka.service;

import chushka.domain.entities.Product;
import chushka.domain.entities.Type;
import chushka.domain.models.service.ProductServiceModel;
import chushka.repository.ProductRepository;
import chushka.util.ModelMapper;


import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

public class ProductServiceImpl implements ProductService {
    private final ProductRepository productRepository;
   private final ModelMapper modelMapper;
    @Inject
    public ProductServiceImpl(ProductRepository productRepository,ModelMapper modelMapper) {
       this.productRepository = productRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public void save(ProductServiceModel productServiceModel) {
        Product product =this.modelMapper.map(productServiceModel, Product.class);
        product.setType(Type.valueOf(productServiceModel.getType()));
        this.productRepository.save(product);
    }
    @Override
    public List<ProductServiceModel> findAll(){
        List<Product> products=this.productRepository.findAll();
        List<ProductServiceModel> product=new ArrayList<>();
        for (Product product1 : products) {
            ProductServiceModel ps=this.modelMapper.map(product1,ProductServiceModel.class);
          product.add (ps);
        }
        return product;
    }
    @Override
    public ProductServiceModel findByName(String name){
     Product product=this.productRepository.findByName(name);
       ProductServiceModel productServiceModel=this.modelMapper.map(product,ProductServiceModel.class);
       productServiceModel.setType(product.getType().name());
        return productServiceModel;
    }
}
