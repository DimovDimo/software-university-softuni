package chushka.web.servlets;

import chushka.domain.models.view.ProductDetailsViewModel;
import chushka.service.ProductService;
import chushka.util.HtmlReader;
import chushka.util.ModelMapper;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/products/details")
public class ProductDetailsServlet extends HttpServlet {
    private final String FILE_PATH="D:\\000000 PROGRAMMING COURSE\\10 JAVA WEB MODULE\\01 Java Web Development Basics - January 2019\\05 JAVA EE SERVLET API  4.0\\Exercises_chushka\\src\\main\\resources\\views\\details-product.html";
    private final HtmlReader htmlReader;
    private final ProductService productService;
    private final ModelMapper modelMapper;
    @Inject
    public ProductDetailsServlet(HtmlReader htmlReader, ProductService productService, ModelMapper modelMapper) {
        this.htmlReader = htmlReader;
        this.productService = productService;
        this.modelMapper = modelMapper;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
String file=this.htmlReader.readerHtmlFile(FILE_PATH);
   String name= req.getQueryString().split("=")[1];
   ProductDetailsViewModel products= this.modelMapper.map(productService.findByName(name),ProductDetailsViewModel.class);
file=file.replace("{{name}}",products.getName()).replace("{{description}}",products.getDescription())
        .replace("{{type}}",products.getType());
        resp.getWriter().println(file);
    }
}
