package chushka.domain.entities;

public enum Type {
Food,Domestic,Health,Cosmetic,Other;
}
