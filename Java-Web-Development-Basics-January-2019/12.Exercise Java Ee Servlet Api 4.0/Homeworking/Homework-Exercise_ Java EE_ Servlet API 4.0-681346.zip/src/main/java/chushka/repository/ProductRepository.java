package chushka.repository;

import chushka.domain.entities.Product;

import java.util.List;

public interface ProductRepository extends GenericRepository<Product,String> {
    public Product findByName(String name);
}
