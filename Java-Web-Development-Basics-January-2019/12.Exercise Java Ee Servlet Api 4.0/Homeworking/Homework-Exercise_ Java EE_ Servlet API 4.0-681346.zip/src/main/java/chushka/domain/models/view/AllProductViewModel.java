package chushka.domain.models.view;

public class AllProductViewModel {
    private String name;

    public AllProductViewModel() {
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
