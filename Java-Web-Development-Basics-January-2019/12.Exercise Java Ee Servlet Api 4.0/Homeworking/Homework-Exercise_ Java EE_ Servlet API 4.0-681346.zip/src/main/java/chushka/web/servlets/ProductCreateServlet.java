package chushka.web.servlets;

import chushka.domain.entities.Type;
import chushka.domain.models.service.ProductServiceModel;
import chushka.domain.models.view.ProductDetailsViewModel;
import chushka.service.ProductService;
import chushka.util.HtmlReader;
import chushka.util.ModelMapper;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/products/create")
public class ProductCreateServlet extends HttpServlet {
    private final String FILE_PATH="D:\\000000 PROGRAMMING COURSE\\10 JAVA WEB MODULE\\01 Java Web Development Basics - January 2019\\05 JAVA EE SERVLET API  4.0\\Exercises_chushka\\src\\main\\resources\\views\\create-product.html";
    private final HtmlReader htmlReader;
    private final ModelMapper modelMapper;
    private final ProductService productService;

    @Inject
    public ProductCreateServlet(HtmlReader htmlReader, ModelMapper modelMapper, ProductService productService) {
        this.htmlReader = htmlReader;
        this.modelMapper = modelMapper;
        this.productService = productService;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String file=this.htmlReader.readerHtmlFile(FILE_PATH);
        StringBuilder sb= new StringBuilder();

        for (Type type : Type.values() ) {
            sb.append("<option>").append(type).append("</option>");
        }
        ;
        file=file.replace("{{typeOptions}}",sb.toString());
        resp.getWriter().println(file);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ProductDetailsViewModel ps =new ProductDetailsViewModel();
        ps.setName(req.getParameter("name"));
        ps.setDescription(req.getParameter("description"));
        ps.setType(req.getParameter("type"));
        ProductServiceModel psService=this.modelMapper.map(ps,ProductServiceModel.class);
        this.productService.save(psService);
        resp.sendRedirect("/products/all");
    }
}
