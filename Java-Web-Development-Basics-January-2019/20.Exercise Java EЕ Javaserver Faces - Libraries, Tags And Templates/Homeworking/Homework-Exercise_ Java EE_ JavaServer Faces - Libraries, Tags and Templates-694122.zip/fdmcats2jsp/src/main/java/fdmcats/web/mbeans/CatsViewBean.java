package fdmcats.web.mbeans;

import fdmcats.domain.models.service.CatsServiceModel;
import fdmcats.domain.models.view.CatsViewModel;
import fdmcats.service.CatsService;
import org.modelmapper.ModelMapper;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Named
@RequestScoped
public class CatsViewBean {

    private CatsViewModel catsViewModel;
    private CatsService catsService;
    private ModelMapper modelMapper;
    private List<CatsViewModel> cats;

    public CatsViewBean() {
        this.cats = new ArrayList<>();
        this.catsViewModel = new CatsViewModel();
    }

    @Inject
    public CatsViewBean(CatsService catsService, ModelMapper modelMapper) {
        this();
        this.catsService = catsService;
        this.modelMapper = modelMapper;
        this.initCats();
    }

    private void initCats() {
        List<CatsServiceModel> allCats = this.catsService.findAllCats();

        List<CatsViewModel> catsViewModels = allCats.stream()
                .map(c -> this.modelMapper.map(c, CatsViewModel.class))
                .collect(Collectors.toList());

        this.cats = catsViewModels;
    }

    public CatsViewModel getCatsViewModel() {
        return catsViewModel;
    }

    public void setCatsViewModel(CatsViewModel catsViewModel) {
        this.catsViewModel = catsViewModel;
    }

    public List<CatsViewModel> getCats() {
        return cats;
    }

    public void setCats(List<CatsViewModel> cats) {
        this.cats = cats;
    }
}
