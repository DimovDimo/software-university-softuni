package fdmcats.service;

import fdmcats.domain.models.service.CatsServiceModel;

import java.util.List;

public interface CatsService {

    void createCat(CatsServiceModel catsServiceModel);

    List<CatsServiceModel> findAllCats();
}
