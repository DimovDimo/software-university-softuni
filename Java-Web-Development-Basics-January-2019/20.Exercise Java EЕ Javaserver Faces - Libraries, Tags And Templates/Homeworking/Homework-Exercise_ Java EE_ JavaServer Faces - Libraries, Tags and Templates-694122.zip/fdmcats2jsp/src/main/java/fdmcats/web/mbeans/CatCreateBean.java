package fdmcats.web.mbeans;

import fdmcats.domain.models.binding.CatCreateBindingModel;
import fdmcats.domain.models.service.CatsServiceModel;
import fdmcats.service.CatsService;
import org.modelmapper.ModelMapper;

import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;

@Named
@RequestScoped
public class CatCreateBean {

    private CatCreateBindingModel catCreateBindingModel;
    private CatsService catsService;
    private ModelMapper modelMapper;

    public CatCreateBean() {
        this.catCreateBindingModel = new CatCreateBindingModel();
    }

    @Inject
    public CatCreateBean(CatsService catsService, ModelMapper modelMapper) {
        this();
        this.catsService = catsService;
        this.modelMapper = modelMapper;
    }

    public CatCreateBindingModel getCatCreateBindingModel() {
        return catCreateBindingModel;
    }

    public void setCatCreateBindingModel(CatCreateBindingModel catCreateBindingModel) {
        this.catCreateBindingModel = catCreateBindingModel;
    }

    public void createCat() throws IOException {

        this.catsService.createCat(this.modelMapper
                .map(this.catCreateBindingModel, CatsServiceModel.class));

        FacesContext.getCurrentInstance().getExternalContext().redirect("/faces/jsf/all-cats.xhtml");
    }
}
