package fdmcats.repository;

import fdmcats.domain.entities.Cat;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.List;

public class CatsRepositoryImpl implements CatsRepository {
    private final EntityManager entityManager;

    @Inject
    public CatsRepositoryImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public Cat save(Cat entity) {
        this.entityManager.getTransaction().begin();
        this.entityManager.persist(entity);
        this.entityManager.getTransaction().commit();

        return entity;
    }

    @Override
    public List<Cat> findAll() {
        return this.entityManager
                .createQuery("SELECT c FROM cats c", Cat.class)
                .getResultList();
    }

    @Override
    public Cat findById(String id) {
        return this.entityManager
                .createQuery("SELECT c FROM cats c WHERE c.id = :id", Cat.class)
                .setParameter("id", id)
                .getSingleResult();
    }

    @Override
    public Long size() {
        return this.entityManager
                .createQuery("SELECT count(c) FROM cats c", Long.class)
                .getSingleResult();
    }
}
