package fdmcats.service;

import fdmcats.domain.entities.Cat;
import fdmcats.domain.models.service.CatsServiceModel;
import fdmcats.repository.CatsRepository;
import org.modelmapper.ModelMapper;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.List;

public class CatsServiceImpl implements CatsService {
    private final CatsRepository catsRepository;
    private final ModelMapper modelMapper;

    @Inject
    public CatsServiceImpl(CatsRepository catsRepository, ModelMapper modelMapper) {
        this.catsRepository = catsRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public void createCat(CatsServiceModel catsServiceModel) {
        this.catsRepository.save(this.modelMapper.map(catsServiceModel, Cat.class));
    }

    @Override
    public List<CatsServiceModel> findAllCats() {
        List<CatsServiceModel> catsServiceModels = Arrays.asList(this.modelMapper
                .map(this.catsRepository.findAll(), CatsServiceModel[].class));

        return catsServiceModels;
    }
}
