package fdmcats.repository;

import fdmcats.domain.entities.Cat;

public interface CatsRepository extends GenericRepository<Cat, String> {

}
