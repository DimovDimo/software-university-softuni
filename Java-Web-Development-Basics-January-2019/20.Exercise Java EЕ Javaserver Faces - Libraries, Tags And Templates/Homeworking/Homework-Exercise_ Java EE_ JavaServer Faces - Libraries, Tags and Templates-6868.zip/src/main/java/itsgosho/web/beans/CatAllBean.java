package itsgosho.web.beans;

import itsgosho.domain.models.view.CatAllViewModel;
import itsgosho.service.CatServices;

import javax.faces.bean.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

@Named
@RequestScoped
public class CatAllBean {

    private List<CatAllViewModel> catAllViewModel;

    private CatServices catServices;

    public CatAllBean() {
        this.catAllViewModel = new ArrayList<>();
    }

    @Inject
    public CatAllBean(CatServices catServices) {
        this();
        this.catServices = catServices;
        this.catAllViewModel = this.catServices.getAll();
    }

    public List<CatAllViewModel> getCatAllViewModel() {
        return catAllViewModel;
    }

    public void setCatAllViewModel(List<CatAllViewModel> catAllViewModel) {
        this.catAllViewModel = catAllViewModel;
    }
}
