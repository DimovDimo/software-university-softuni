package itsgosho.config;

import itsgosho.utils.ValidationUtil;
import itsgosho.utils.ValidationUtilImp;
import org.modelmapper.ModelMapper;

import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class ApplicationBeanConfiguration {

    private static EntityManager entityManager;

    @Produces
    public EntityManager entityManager(){
        if(entityManager==null){
            entityManager = Persistence.createEntityManagerFactory("java-ee-jsf").createEntityManager();
        }
        return entityManager;
    }

    @Produces
    public ModelMapper modelMapper(){
        return new ModelMapper();
    }

    @Produces
    public ValidationUtil validationUtil(){
        return new ValidationUtilImp();
    }
}
