package itsgosho.service;

import itsgosho.domain.entities.Cat;
import itsgosho.domain.models.binding.CatCreateBindingModel;
import itsgosho.domain.models.view.CatAllViewModel;
import itsgosho.repository.CatRepository;
import itsgosho.utils.ValidationUtil;
import itsgosho.utils.ValidationUtilImp;
import org.modelmapper.ModelMapper;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class CatServicesImp implements CatServices {

    private CatRepository catRepository;
    private ModelMapper modelMapper;
    private ValidationUtil validationUtil;

    @Inject
    public CatServicesImp(CatRepository catRepository, ModelMapper modelMapper, ValidationUtilImp validationUtil){
        this.catRepository = catRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
    }

    @Override
    public Cat create(CatCreateBindingModel catCreateBindingModel) {

        if(!this.validationUtil.isValid(catCreateBindingModel)){
            return null;
        }

        Cat cat = this.modelMapper.map(catCreateBindingModel,Cat.class);
        this.catRepository.save(cat);

        return cat;
    }

    @Override
    public List<CatAllViewModel> getAll() {
        List<CatAllViewModel> result = new ArrayList<>();

        this.catRepository.findAll().stream()
                .forEach(x->{
                    CatAllViewModel catAllViewModel = this.modelMapper.map(x,CatAllViewModel.class);
                    result.add(catAllViewModel);
                });

        return result;
    }
}
