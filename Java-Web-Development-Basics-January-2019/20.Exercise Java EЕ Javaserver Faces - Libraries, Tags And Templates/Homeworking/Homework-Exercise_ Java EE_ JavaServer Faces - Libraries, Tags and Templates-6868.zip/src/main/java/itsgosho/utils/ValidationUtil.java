package itsgosho.utils;

public interface ValidationUtil {

   <E> boolean isValid(E entity);
}
