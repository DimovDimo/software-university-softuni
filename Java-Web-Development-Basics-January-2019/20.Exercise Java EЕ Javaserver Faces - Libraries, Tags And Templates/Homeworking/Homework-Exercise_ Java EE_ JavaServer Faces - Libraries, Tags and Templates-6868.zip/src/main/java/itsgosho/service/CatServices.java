package itsgosho.service;

import itsgosho.domain.entities.Cat;
import itsgosho.domain.models.binding.CatCreateBindingModel;
import itsgosho.domain.models.view.CatAllViewModel;

import java.util.List;

public interface CatServices {

    Cat create(CatCreateBindingModel catCreateBindingModel);

    List<CatAllViewModel> getAll();
}
