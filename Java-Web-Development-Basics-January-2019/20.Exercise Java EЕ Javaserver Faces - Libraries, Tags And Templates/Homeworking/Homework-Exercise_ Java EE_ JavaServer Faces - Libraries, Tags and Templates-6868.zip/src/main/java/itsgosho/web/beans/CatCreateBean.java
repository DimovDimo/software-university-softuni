package itsgosho.web.beans;

import itsgosho.domain.models.binding.CatCreateBindingModel;
import itsgosho.service.CatServices;

import javax.faces.bean.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;

@Named
@RequestScoped
public class CatCreateBean implements Serializable {

    private CatCreateBindingModel catCreateBindingModel;

    private CatServices catServices;

    public CatCreateBean() {
        this.catCreateBindingModel = new CatCreateBindingModel();
    }

    @Inject
    public CatCreateBean(CatServices catServices) {
        this();
        this.catServices = catServices;
    }

    public void create() {
        this.catServices.create(this.catCreateBindingModel);
    }

    public CatCreateBindingModel getCatCreateBindingModel() {
        return catCreateBindingModel;
    }

    public void setCatCreateBindingModel(CatCreateBindingModel catCreateBindingModel) {
        this.catCreateBindingModel = catCreateBindingModel;
    }
}
