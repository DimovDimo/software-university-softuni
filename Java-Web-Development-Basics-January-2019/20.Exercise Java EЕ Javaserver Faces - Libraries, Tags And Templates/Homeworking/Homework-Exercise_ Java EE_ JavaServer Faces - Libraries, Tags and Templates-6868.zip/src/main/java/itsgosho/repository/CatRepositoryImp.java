package itsgosho.repository;

import itsgosho.domain.entities.Cat;
import org.modelmapper.ModelMapper;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.List;

public class CatRepositoryImp implements CatRepository {

    private EntityManager entityManager;

    @Inject
    public CatRepositoryImp(EntityManager entityManager){
        this.entityManager = entityManager;
    }

    @Override
    public Cat save(Cat entity) {
        this.entityManager.getTransaction().begin();
        this.entityManager.persist(entity);
        this.entityManager.getTransaction().commit();
        return entity;
    }

    @Override
    public List<Cat> findAll() {
        List<Cat> result = this.entityManager.createQuery("select c from Cat as c",Cat.class).getResultList();
        return result;
    }

    @Override
    public Cat findById(Long aLong) {
        Cat result = this.entityManager.createQuery("select c from Cat as c where c.id = :id",Cat.class)
                .setParameter("id",aLong)
                .getSingleResult();
        return result;
    }
}
