package itsgosho.repository;

import itsgosho.domain.entities.Cat;

public interface CatRepository extends GenericRepository<Cat,Long> {

}
