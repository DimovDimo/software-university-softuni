package fdmcv2.repository;

import fdmcv2.domain.entities.Cat;

public interface CatRepository extends GenericRepository<Cat, String> {
}
