package fdmcv2.domain.models.view;

public class CatCreateViewModel {
}
