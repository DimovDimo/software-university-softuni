package fdmcv2.service;

import fdmcv2.domain.models.service.CatServiceModel;

import java.util.Arrays;
import java.util.List;

public interface CatService {


    List<CatServiceModel> findAll();

    boolean saveCat(CatServiceModel cat);
}