package fdmcv2.repository;

import fdmcv2.domain.entities.Cat;
import fdmcv2.domain.models.service.CatServiceModel;

import java.util.List;

public interface CatRepository extends GenericRepository<Cat, String> {

}