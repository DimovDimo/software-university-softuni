package fdmcv2.web.beans;

import fdmcv2.domain.models.binding.CatCreateBindingModel;
import fdmcv2.domain.models.service.CatServiceModel;
import fdmcv2.domain.models.view.CatCreateViewModel;
import fdmcv2.service.CatService;
import org.modelmapper.ModelMapper;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;

@Named
@RequestScoped
public class CatCreateBean {

    private CatCreateBindingModel model;

    private CatService catService;
    private ModelMapper modelMapper;

    public CatCreateBean() {
    }

    @Inject
    public CatCreateBean(CatService catService, ModelMapper modelMapper) {
        this.catService = catService;
        this.modelMapper = modelMapper;
        this.model = new CatCreateBindingModel();
    }

    public void create() throws IOException {

        CatServiceModel catServiceModel = this.modelMapper
                .map(this.model, CatServiceModel.class);

        this.catService.saveCat(catServiceModel);

        FacesContext.getCurrentInstance()
                .getExternalContext()
                .redirect("/view/all-cats.xhtml");
    }

    @PostConstruct
    public void init(){

    }

    public CatCreateBindingModel getModel() {
        return model;
    }

    public void setModel(CatCreateBindingModel model) {
        this.model = model;
    }
}