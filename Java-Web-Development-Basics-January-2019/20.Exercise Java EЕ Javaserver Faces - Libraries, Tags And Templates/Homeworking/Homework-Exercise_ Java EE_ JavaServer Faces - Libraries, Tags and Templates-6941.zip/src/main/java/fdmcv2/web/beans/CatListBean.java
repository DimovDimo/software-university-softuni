package fdmcv2.web.beans;

import fdmcv2.domain.models.view.CatListViewModel;
import fdmcv2.service.CatService;
import org.modelmapper.ModelMapper;

import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Named
@RequestScoped
public class CatListBean {

    private List<CatListViewModel> cats;

    private CatService catService;
    private ModelMapper modelMapper;

    public CatListBean() {
    }

    @Inject
    public CatListBean(CatService catService, ModelMapper modelMapper) throws IOException {
        this.catService = catService;
        this.modelMapper = modelMapper;
        this.cats = this.catService.findAll().stream()
                .map(c -> this.modelMapper.map(c, CatListViewModel.class))
                .collect(Collectors.toList());

//        FacesContext.getCurrentInstance()
//                .getExternalContext()
//                .redirect("/view/all-cats.xhtml");
    }


    public List<CatListViewModel> getCats() {
        return cats;
    }

    public void setCats(List<CatListViewModel> cats) {
        this.cats = cats;
    }
}
