package fdmcv2.repository;

import fdmcv2.domain.entities.Cat;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;

public class CatRepositoryImpl implements CatRepository {

    private final EntityManager entityManager;

    @Inject
    public CatRepositoryImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public void save(Cat entity) {
        entityManager.getTransaction().begin();
        entityManager.persist(entity);
        entityManager.getTransaction().commit();
    }

    @Override
    public List<Cat> findAll() {
        List<Cat> cats = new ArrayList<>();
        entityManager.getTransaction().begin();
        cats = entityManager.createQuery("SELECT c FROM Cat c", Cat.class).getResultList();
        entityManager.getTransaction().commit();
        return cats;
    }

    @Override
    public Cat findById(String s) {
        return null;
    }

    @Override
    public Long size() {
        return null;
    }
}