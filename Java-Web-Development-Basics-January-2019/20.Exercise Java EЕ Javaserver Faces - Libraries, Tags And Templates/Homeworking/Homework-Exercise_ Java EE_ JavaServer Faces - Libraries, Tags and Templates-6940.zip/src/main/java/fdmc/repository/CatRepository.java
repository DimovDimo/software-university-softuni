package fdmc.repository;

import fdmc.domain.entities.Cat;

public interface CatRepository extends GenericRepository<Cat, String> {

}
