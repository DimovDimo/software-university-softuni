public interface HttpCookie {
    String getKey();
    String getValue();
}
