import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Application {

    private static BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));;

    public static void main(String[] args) throws IOException {
        List<String> validUrls = getValidUrls();
        String request = getRequest();

        HttpRequest httpRequest = new HttpRequestImpl(request);
        httpRequest.getCookies().stream().forEach(cookie->{
            System.out.println(String.format("%s <-> %s",cookie.getKey(),cookie.getValue()));
        });

    }

    private static List<String> getValidUrls() throws IOException {
        List<String> validUrls = new ArrayList<>();
        Arrays.stream(bufferedReader.readLine().split("\\s+")).forEach(url->{
            validUrls.add(url);
        });
        return validUrls;
    }

    private static String getRequest() throws IOException {
        StringBuilder request = new StringBuilder();
        String line;
        while((line = bufferedReader.readLine())!=null && !line.isEmpty()){
            request.append(line);
        }
        request.append(System.lineSeparator());
        if((line = bufferedReader.readLine()) !=null && !line.isEmpty()){
            request.append(line);
        }
        return String.join(System.lineSeparator(),request);
    }
    private static boolean urlIsValid(List<String> validUrls,HttpRequest httpRequest){
        if(validUrls.contains(httpRequest.getRequestUrl()))
            return true;
        return false;
    }
}
