package app.http;

public interface HttpCookie {

    String getKey();

    String getValue();
}
