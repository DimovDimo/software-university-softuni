package main.java.app.contracts;

/**
 * Created by Nino Bonev - 25.1.2019 г., 10:52
 */
public interface HttpCookie {

    String getKey();

    String getValue();

}
