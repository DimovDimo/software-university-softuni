package statemng.http.api;

public interface HttpCookie {

    String getKey();
    String getValue();
}
