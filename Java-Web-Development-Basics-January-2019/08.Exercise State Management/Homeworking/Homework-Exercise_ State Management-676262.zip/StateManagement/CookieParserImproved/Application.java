package StateManagement.CookieParserImproved;

import StateManagement.CookieParserImproved.http.HttpRequest;
import StateManagement.CookieParserImproved.http.HttpRequestImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Application {

    private static final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) throws IOException {
        String request = readHttpRequest();
        HttpRequest httpRequest = new HttpRequestImpl(request);
        StringBuilder response = new StringBuilder();
        httpRequest.getCookies().forEach(cookie -> response
                .append(cookie.getKey())
                .append(" <-> ")
                .append(cookie.getValue())
                .append(System.lineSeparator()));
        System.out.println(response);
    }

    private static String readHttpRequest() throws IOException {
        StringBuilder request = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            request.append(line).append(System.lineSeparator());
            if (line.isEmpty()) {
                break;
            }
        }
        request.append(reader.readLine());
        return request.toString();
    }
}
