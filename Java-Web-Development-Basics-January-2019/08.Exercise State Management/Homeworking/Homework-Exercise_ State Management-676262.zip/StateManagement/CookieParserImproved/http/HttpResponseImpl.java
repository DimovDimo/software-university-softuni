package StateManagement.CookieParserImproved.http;

import StateManagement.CookieParserImproved.http.enums.HttpStatus;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class HttpResponseImpl implements HttpResponse {

    private Map<String, String> headers;
    private byte[] content;
    private HttpStatus httpStatus;

    public HttpResponseImpl() {
        content = new byte[0];
        headers = new LinkedHashMap<>();
    }

    @Override
    public Map<String, String> getHeaders() {
        return Collections.unmodifiableMap(headers);
    }

    @Override
    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    @Override
    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    @Override
    public byte[] getContent() {
        return content.clone();
    }

    @Override
    public void setContent(byte[] content) {
        this.content = content.clone();
    }

    @Override
    public byte[] getBytes() {
        StringBuilder response = new StringBuilder()
                .append("HTTP/1.1")
                .append(" ")
                .append(httpStatus.getCode())
                .append(" ")
                .append(httpStatus.getName())
                .append(System.lineSeparator());
        headers.forEach((key, value) -> response
                .append(key)
                .append(": ")
                .append(value)
                .append(System.lineSeparator()));
        response.append(System.lineSeparator())
                .append(new String(content));

        return response.toString().getBytes();
    }

    @Override
    public void addHeader(String header, String value) {
        headers.put(header, value);
    }
}
