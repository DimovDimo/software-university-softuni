package StateManagement.CookieParserImproved.http;

import StateManagement.CookieParserImproved.http.enums.HttpMethod;

import java.util.*;

public class HttpRequestImpl implements HttpRequest {

    private Map<String, String> headers;
    private Map<String, String> bodyParameters;
    private HttpMethod method;
    private String requestUrl;
    private List<HttpCookie> cookies;

    public HttpRequestImpl(String request) {
        headers = new LinkedHashMap<>();
        bodyParameters = new HashMap<>();
        cookies = new ArrayList<>();
        init(request);
    }

    private void init(String request) {
        List<String> lines = Arrays.asList(request.split(System.lineSeparator()));
        if (lines.isEmpty()) {
            return;
        }

        String[] requestLineTokens = lines.get(0).split(" ");
        setMethod(HttpMethod.valueOf(requestLineTokens[0]));
        setRequestUrl(requestLineTokens[1]);

        for (int index = 1; index < lines.size() && !lines.get(index).isEmpty(); index++) {
            String[] headerKvp = lines.get(index).split(": ");
            addHeader(headerKvp[0], headerKvp[1]);
        }

        if (!lines.get(lines.size() - 1).isEmpty()) {
            Arrays.stream(lines.get(lines.size() - 1).split("&"))
                    .map(a -> a.split("="))
                    .forEach(parameterKvp -> addBodyParameter(parameterKvp[0], parameterKvp[1]));
        }

        if (headers.containsKey("Cookie")) {
            Arrays.stream(headers.get("Cookie").split("; "))
                    .map(a -> a.split("="))
                    .forEach(cookieKvp -> addCookie(cookieKvp[0], cookieKvp[1]));
        }
    }

    @Override
    public Map<String, String> getHeaders() {
        return headers;
    }

    @Override
    public Map<String, String> getBodyParameters() {
        return bodyParameters;
    }

    @Override
    public HttpMethod getMethod() {
        return method;
    }

    @Override
    public void setMethod(HttpMethod method) {
        this.method = method;
    }

    @Override
    public String getRequestUrl() {
        return requestUrl;
    }

    @Override
    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }

    @Override
    public void addHeader(String header, String value) {
        headers.put(header, value);
    }

    @Override
    public void addBodyParameter(String parameter, String value) {
        bodyParameters.put(parameter, value);
    }

    @Override
    public boolean isResource() {
        return requestUrl.contains(".");
    }

    @Override
    public void addCookie(String key, String value) {
        cookies.add(new HttpCookie(key, value));
    }

    @Override
    public List<HttpCookie> getCookies() {
        return Collections.unmodifiableList(cookies);
    }
}
