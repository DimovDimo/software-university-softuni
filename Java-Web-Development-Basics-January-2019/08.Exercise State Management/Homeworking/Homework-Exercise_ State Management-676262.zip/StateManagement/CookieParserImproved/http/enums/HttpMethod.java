package StateManagement.CookieParserImproved.http.enums;

public enum HttpMethod {
    GET, POST
}
