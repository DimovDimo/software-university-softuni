package StateManagement.CookieParserImproved.http;

import StateManagement.CookieParserImproved.http.enums.HttpStatus;

import java.util.Map;

public interface HttpResponse {

    Map<String, String> getHeaders();

    HttpStatus getHttpStatus();

    void setHttpStatus(HttpStatus httpStatus);

    byte[] getContent();

    void setContent(byte[] content);

    byte[] getBytes();

    void addHeader(String header, String value);
}
