package StateManagement.CookieParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class HttpCookieParser {
    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            Map<String, String> headers = parseHeaders(reader);

            Map<String, String> cookies = parseCookies(headers.get("Cookie"));

            StringBuilder responseBuilder = new StringBuilder();

            cookies.forEach((key, value) -> responseBuilder
                    .append(key).append(" <-> ").append(value)
                    .append(System.lineSeparator()));

            System.out.println(responseBuilder.toString());
        } catch (IOException | IllegalArgumentException e) {
        }
    }

    private static Map<String, String> parseCookies(String cookiesStr) {
        Map<String, String> cookies = new LinkedHashMap<>();
        if (cookiesStr != null) {
            Arrays.stream(cookiesStr.split("; "))
                    .map(a -> a.split("="))
                    .forEach(kvp -> cookies.put(kvp[0], kvp[1]));
        }
        return cookies;
    }

    private static Map<String, String> parseHeaders(BufferedReader reader) throws IOException {
        Map<String, String> headers = new LinkedHashMap<>();
        String header;
        Pattern pattern = Pattern.compile("^([^ :]+): (.+)$");
        while ((header = reader.readLine()) != null && header.length() > 0) {
            Matcher matcher = pattern.matcher(header);
            if (matcher.matches() && matcher.group(1).equals("Cookie")) {
                String key = matcher.group(1);
                String value = matcher.group(2);
                headers.put(key, value);
            }
        }
        return headers;
    }
}