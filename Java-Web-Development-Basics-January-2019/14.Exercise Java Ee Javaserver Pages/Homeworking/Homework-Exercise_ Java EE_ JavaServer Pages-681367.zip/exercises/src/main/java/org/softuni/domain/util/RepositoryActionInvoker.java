package org.softuni.domain.util;

public interface RepositoryActionInvoker {
    void invoke(RepositoryActionResult repositoryActionResult);
}
