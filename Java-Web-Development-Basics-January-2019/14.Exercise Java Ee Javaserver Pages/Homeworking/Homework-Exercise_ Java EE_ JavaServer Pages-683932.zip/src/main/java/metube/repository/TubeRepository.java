package metube.repository;

import metube.domain.entities.Tube;
import metube.repository.base.DataRepository;

import java.util.Optional;

public interface TubeRepository extends DataRepository<Tube, String> {

    Optional<Tube> findByName(String name);
}
