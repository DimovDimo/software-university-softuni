package metube.repository.base;

import java.util.List;
import java.util.Optional;

public interface DataRepository<T, I> {

    List<T> getAll();

    void save(T object);

    Optional<T> findById(I id);
}
