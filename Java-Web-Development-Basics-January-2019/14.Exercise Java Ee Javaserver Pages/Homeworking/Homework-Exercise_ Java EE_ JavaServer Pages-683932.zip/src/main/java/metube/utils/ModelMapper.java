package metube.utils;

public class ModelMapper extends org.modelmapper.ModelMapper {
}
