package metube.repository;

import metube.domain.entities.Tube;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaQuery;
import java.util.List;
import java.util.Optional;

public class TubeRepositoryImpl implements TubeRepository {

    private EntityManager entityManager;

    public TubeRepositoryImpl() {
        this.entityManager = Persistence.createEntityManagerFactory("metube").createEntityManager();
    }

    @Override
    public Optional<Tube> findByName(String name) {
        try {
            return Optional.of(this.entityManager.createQuery("SELECT t FROM tubes t WHERE t.name = :name", Tube.class)
                    .setParameter("name", name).getSingleResult());
        } catch (NoResultException e) {
            return Optional.empty();
        }
    }

    @Override
    public List<Tube> getAll() {
        CriteriaQuery<Tube> criteriaQuery = this.entityManager.getCriteriaBuilder().createQuery(Tube.class);
        criteriaQuery.from(Tube.class);
        return this.entityManager.createQuery(criteriaQuery).getResultList();
    }

    @Override
    public void save(Tube object) {
        this.entityManager.getTransaction().begin();
        this.entityManager.persist(object);
        this.entityManager.getTransaction().commit();
    }

    @Override
    public Optional<Tube> findById(String id) {
        try {
            return Optional.of(this.entityManager.find(Tube.class, id));
        } catch (NoResultException e) {
            return Optional.empty();
        }
    }
}
