package metube.domain.models.view;

/**
 * Created by IntelliJ IDEA.
 * User: LAPD
 * Date: 31.1.2019 г.
 * Time: 22:23 ч.
 */
public class TubeAllViewModel {

    private String name;

    public TubeAllViewModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}