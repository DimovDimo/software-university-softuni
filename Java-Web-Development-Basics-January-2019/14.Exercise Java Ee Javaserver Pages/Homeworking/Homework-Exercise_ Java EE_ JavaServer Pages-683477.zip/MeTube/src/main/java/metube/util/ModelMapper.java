package metube.util;

public class ModelMapper extends org.modelmapper.ModelMapper {
}
