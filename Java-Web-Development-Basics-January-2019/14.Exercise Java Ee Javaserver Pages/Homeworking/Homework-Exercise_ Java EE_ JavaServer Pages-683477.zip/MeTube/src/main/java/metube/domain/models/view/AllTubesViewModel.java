package metube.domain.models.view;

public class AllTubesViewModel {

    private String name;

    public AllTubesViewModel() {
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
