package org.softuni.exam.repository;

import org.softuni.exam.domain.entities.Problem;

public interface ProblemRepository extends GenericRepository<Problem, String> {
}
