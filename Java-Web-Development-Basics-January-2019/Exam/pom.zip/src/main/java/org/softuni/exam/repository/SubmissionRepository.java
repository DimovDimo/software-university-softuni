package org.softuni.exam.repository;

import org.softuni.exam.domain.entities.Submission;

public interface SubmissionRepository extends GenericRepository<Submission, String> {
}
