package main.java;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Application {
    private static BufferedReader buffReader = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) throws IOException {

        List<String> validUrls = getValidUrls();
        List<String> httpRequests = getHttpRequests();
        String method = getMethod(httpRequests.get(0));
        String url = getUrl(httpRequests.get(0));

        Map<String, String> headers = getHeaders(httpRequests);
        Map<String, String> bodyParams = getBody(httpRequests);

        StringBuilder httpResponse = new StringBuilder();
        if (!validUrls.contains(url)) {
            httpResponse.append("HTTP/1.1 404 Not Found").append(System.lineSeparator());

            getHeadersResponse(headers, httpResponse);

            httpResponse.append(System.lineSeparator());
            httpResponse.append("The requested functionality was not found.");
        } else if (!headers.containsKey("Authorization")) {
            httpResponse.append("HTTP/1.1 401 Unauthorized").append(System.lineSeparator());

            getHeadersResponse(headers, httpResponse);

            httpResponse.append(System.lineSeparator());
            httpResponse.append("You are not authorized to access the requested functionality.");
        } else if (method.equals("POST") && bodyParams.size() == 0) {
            httpResponse.append("HTTP/1.1 400 Bad Request").append(System.lineSeparator());

            getHeadersResponse(headers, httpResponse);

            httpResponse.append(System.lineSeparator());
            httpResponse.append("There was an error with the requested functionality due to malformed request.");
        } else if(method.equals("POST")&&headers.containsKey("Authorization")){
            httpResponse.append("HTTP/1.1 200 OK").append(System.lineSeparator());

            getHeadersResponse(headers, httpResponse);
            httpResponse.append(System.lineSeparator());

            String username = new String(Base64.getDecoder().decode(headers.get("Authorization").split("\\s+")[1]));
            String[] placeHolderData = new String[3];
            getPlaceHolderData(bodyParams, placeHolderData);
            String bodyResponse = String.format(
                    "Greetings %s! You have successfully created %s with %s, %s.",
                    username,
                    placeHolderData[0], placeHolderData[1], placeHolderData[2]);

            httpResponse.append(bodyResponse);
        }

        System.out.println(httpResponse.toString());
    }

    private static void getPlaceHolderData(Map<String, String> bodyParams, String[] placeHolderData) {
        int cnt = 0;
        for (Map.Entry<String, String> kvp : bodyParams.entrySet()) {
            switch (cnt) {
                case 0:
                    placeHolderData[cnt] = kvp.getValue();
                    break;
                case 1:
                    placeHolderData[cnt] = String.format("%s - %s", kvp.getKey(), kvp.getValue());
                    break;
                case 2:
                    placeHolderData[cnt] = String.format("%s - %s", kvp.getKey(), kvp.getValue());
                    break;
            }
            cnt += 1;
        }
    }

    private static void getHeadersResponse(Map<String, String> headers, StringBuilder httpResponse) {
        for (Map.Entry<String, String> kvp : headers.entrySet()) {

            if (kvp.getKey().equals("Date") || kvp.getKey().equals("Host") || kvp.getKey().equals("Content-Type")) {
                httpResponse.append(kvp.getKey())
                        .append(": ")
                        .append(kvp.getValue())
                        .append(System.lineSeparator());
            }
        }
    }

    private static Map<String, String> getBody(List<String> httpRequests) {
        Map<String, String> bodyParamsMap = new LinkedHashMap<>();

        if (httpRequests.get(httpRequests.size() - 1).equals(System.lineSeparator())) {
            return bodyParamsMap;
        }
        Arrays.stream(httpRequests.get(httpRequests.size() - 1)
                .split("&"))
                .forEach(bodyParameters -> {
                    String[] kvp = bodyParameters.split("=");
                    bodyParamsMap.put(kvp[0], kvp[1]);
                });
        return bodyParamsMap;
    }

    private static Map<String, String> getHeaders(List<String> httpRequests) {
        Map<String, String> headersMap = new LinkedHashMap<>();

        httpRequests.stream()
                .skip(1)
                .filter(h -> h.contains(": "))
                .forEach(line -> {
                    String[] kvp = line.split(": ");
                    headersMap.put(kvp[0], kvp[1]);
                });
        return headersMap;
    }

    private static String getUrl(String line) {
        return line.split("\\s+")[1];
    }

    private static String getMethod(String line) {
        return line.split("\\s+")[0];
    }

    private static List<String> getHttpRequests() throws IOException {
        String line;
        List<String> requests = new ArrayList<>();
        while ((line = buffReader.readLine()) != null && line.length() > 0) {
            requests.add(line);
        }
        requests.add(System.lineSeparator());
        if ((line = buffReader.readLine()) != null && line.length() > 0) {
            requests.add(line);
        }
        return requests;
    }

    private static List<String> getValidUrls() throws IOException {
        return Arrays.asList(buffReader.readLine().split("\\s+"));
    }
}
