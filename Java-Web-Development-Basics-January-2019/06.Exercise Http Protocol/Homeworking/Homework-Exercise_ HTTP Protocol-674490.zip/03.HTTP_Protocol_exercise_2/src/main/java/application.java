package main.java;

import main.java.http.RequestImpl;
import main.java.http.ResponseImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class application {

    private static BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) throws IOException {

        List<String> validUrls = getValidUrls();
        List<String> inputLines = readAllLines();

        RequestImpl requestImpl = new RequestImpl(inputLines.get(0));
        addHeaders(inputLines, requestImpl);
        addBodyParams(inputLines, requestImpl);

        ResponseImpl responseImpl = new ResponseImpl(requestImpl.getHeaders(), requestImpl.getBodyParameters());
        setStatusCode(validUrls, requestImpl, responseImpl);

        System.out.println(responseImpl.getResponse());

    }

    private static void setStatusCode(List<String> validUrls, RequestImpl requestImpl, ResponseImpl responseImpl) {
        if (!validUrls.contains(requestImpl.getRequestUrl())) {
            responseImpl.setStatusCode(404);
        } else if (!responseImpl.getHeaders().containsKey("Authorization")) {
            responseImpl.setStatusCode(401);
        } else if (requestImpl.getMethod().toLowerCase().equals("post") &&
                requestImpl.getBodyParameters().size() == 0) {
            responseImpl.setStatusCode(400);
        } else if (requestImpl.getMethod().toLowerCase().equals("post") &&
                responseImpl.getHeaders().containsKey("Authorization")) {
            responseImpl.setStatusCode(200);
        }
    }


    private static void addBodyParams(List<String> inputLines, RequestImpl requestImpl) {
        if (!(inputLines.get(inputLines.size() - 1).equals(System.lineSeparator()))) {
            Arrays.stream(inputLines.get(inputLines.size() - 1)
                    .split("&")).forEach(line -> {
                String[] kvp = line.split("=");
                requestImpl.addBodyParameter(kvp[0], kvp[1]);
            });

        }
    }

    private static void addHeaders(List<String> lines, RequestImpl requestImpl) {
        lines.stream().filter(line -> line.contains(": ")).forEach(line -> {
            String[] kvp = line.split(": ");
            requestImpl.addHeader(kvp[0], kvp[1]);
        });
    }

    private static List<String> getValidUrls() throws IOException {
        return Arrays.asList(buff.readLine().split("\\s+"));
    }

    private static List<String> readAllLines() throws IOException {
        List<String> input = new ArrayList<>();
        String line;
        while ((line = buff.readLine()) != null && line.length() > 0) {
            input.add(line);
        }
        input.add(System.lineSeparator());

        while ((line = buff.readLine()) != null && line.length() > 0) {
            input.add(line);
        }
        return input;
    }
}
