package main.java.interfaces;


import java.util.Map;

public interface HttpResponse {

    Map<String, String> getBodyParameters();

    void addBodyParameter(String parameter, String value);

    Map<String, String> getHeaders();

    int getStatusCode();

//    byte[] getContent();

//    byte[] getBytes();

    void setStatusCode(int statusCode);

//    void setContent(byte[] content);

    void addHeader(String header, String value);
}
