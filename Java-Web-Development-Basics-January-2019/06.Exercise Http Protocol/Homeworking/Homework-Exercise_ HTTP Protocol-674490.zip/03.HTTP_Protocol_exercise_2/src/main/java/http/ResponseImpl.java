package main.java.http;

import main.java.interfaces.HttpResponse;

import java.util.*;

public class ResponseImpl implements HttpResponse {
    private Map<String, String> headers;
    private Map<String, String> bodyParameters;
    private int statusCode;

    public ResponseImpl(Map<String, String> headers, Map<String, String> bodyParameters) {
        this.headers = headers;
        this.bodyParameters = bodyParameters;
        this.statusCode = 0;
    }

    @Override
    public Map<String, String> getBodyParameters() {
        return Collections.unmodifiableMap(this.bodyParameters);
    }

    @Override
    public void addBodyParameter(String parameter, String value) {
        this.bodyParameters.put(parameter, value);
    }

    @Override
    public Map<String, String> getHeaders() {
        return Collections.unmodifiableMap(this.headers);
    }

    @Override
    public int getStatusCode() {
        return this.statusCode;
    }

//    @Override
//    public byte[] getContent() {
//        return null;
//
//    }

//    @Override
//    public byte[] getBytes() {
//        return new byte[0];
//    }

    @Override
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

//    @Override
//    public void setContent(byte[] content) {
//
//    }

    @Override
    public void addHeader(String header, String value) {
        this.headers.put(header, value);
    }

    public String getResponse() {
        StringBuilder response = new StringBuilder();

        switch (this.statusCode) {
            case 404:
                response.append("HTTP/1.1 404 Not Found").append(System.lineSeparator());
                addHeadersToResponseResult(response);
                response.append(System.lineSeparator());
                response.append("The requested functionality was not found.");
                break;
            case 401:
                response.append("HTTP/1.1 401 Unauthorized").append(System.lineSeparator());
                addHeadersToResponseResult(response);
                response.append(System.lineSeparator());
                response.append("You are not authorized to access the requested functionality.");
                break;
            case 400:
                response.append("HTTP/1.1 400 Bad Request").append(System.lineSeparator());
                addHeadersToResponseResult(response);
                response.append(System.lineSeparator());
                response.append("There was an error with the requested functionality due to malformed request.");
                break;
            case 200:
                response.append("HTTP/1.1 200 OK").append(System.lineSeparator());
                addHeadersToResponseResult(response);
                response.append(System.lineSeparator());
                response.append(this.getBodyResponse());
                break;
        }

        return response.toString();
    }

    private String getBodyResponse() {

        String user = new String(Base64.getDecoder().decode(this.headers.get("Authorization").split(" ")[1]));
        Deque<String> placeHolderData = new ArrayDeque<>();
        int cnt = 0;
        for (Map.Entry<String, String> kvp : this.bodyParameters.entrySet()) {
            switch (cnt) {
                case 0:
                    placeHolderData.add(kvp.getValue());
                    break;
                case 1:
                    placeHolderData.add(String.format("%s - %s", kvp.getKey(), kvp.getValue()));
                    break;
                case 2:
                    placeHolderData.add(String.format("%s - %s", kvp.getKey(), kvp.getValue()));
                    break;
            }
            cnt += 1;
        }
        return String.format("Greetings %s! You have successfully created %s with %s, %s.",
                user,
                placeHolderData.pop(),
                placeHolderData.pop(),
                placeHolderData.pop());
    }

    private void addHeadersToResponseResult(StringBuilder response) {
        for (Map.Entry<String, String> kvp : this.headers.entrySet()) {

            if (kvp.getKey().equals("Date") || kvp.getKey().equals("Host") || kvp.getKey().equals("Content-Type")) {
                response.append(kvp.getKey())
                        .append(": ")
                        .append(kvp.getValue())
                        .append(System.lineSeparator());
            }
        }
    }


}
