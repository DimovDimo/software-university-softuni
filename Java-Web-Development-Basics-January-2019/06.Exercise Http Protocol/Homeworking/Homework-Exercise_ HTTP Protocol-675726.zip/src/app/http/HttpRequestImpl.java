package app.http;

import java.util.*;

public class HttpRequestImpl implements HttpRequest {

    private String method;
    private String requestUrl;
    private Map<String, String> headers;
    private Map<String, String> bodyParameters;
    private List<HttpCookie> cookies;
    private boolean isResource;

    public HttpRequestImpl(String request) {
        this.init(request);
    }

    private void init(String request) {

        this.setMethod(request.split("\\s+")[0]);
        this.setRequestUrl(request.split("\\s+")[1]);
        this.headers = new LinkedHashMap<>();
        this.bodyParameters = new LinkedHashMap<>();
        this.cookies = new ArrayList<>();

        Arrays.stream(request.split(System.lineSeparator()))
                .skip(1)
                .filter(headerKvp -> headerKvp.contains(": "))
                .forEach(headerKVP -> {
                    String[] header = headerKVP.split(": ");

                        this.addHeader(header[0], header[1]);
                        if (header[0].equals("Cookie")){
                            String[] cookieValues = header[1].split(";\\s+");
                            Arrays.stream(cookieValues).forEach(v->{
                                String key = v.split("=")[0] ;
                                String value = v.split("=")[1];
                                HttpCookie cookie = new HttpCookieImpl(key,value);
                                this.addCookie(cookie);
                            });

                        }
                });

        String[] requestParams = request.split(System.lineSeparator());

        if (!requestParams[requestParams.length - 1].isEmpty()) {
            Arrays.stream(requestParams[requestParams.length - 1].split("&"))
                    .forEach(p -> {
                        String[] rp = p.split("=");
                        this.addBodyParameter(rp[0], rp[1]);
                    });

        }
    }

    @Override
    public Map<String, String> getHeaders() {
        return this.headers;
    }

    @Override
    public Map<String, String> getBodyParameters() {
        return this.bodyParameters;
    }

    @Override
    public List<HttpCookie> getCookies() {
        return this.cookies;
    }

    @Override
    public String getMethod() {
        return this.method;
    }

    @Override
    public void setMethod(String method) {
        this.method = method;

    }

    @Override
    public String getRequestUrl() {
        return this.requestUrl;
    }

    @Override
    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;

    }

    @Override
    public void addHeader(String header, String value) {
        this.headers.put(header, value);

    }

    @Override
    public void addBodyParameter(String parameter, String value) {
        this.bodyParameters.put(parameter, value);
    }

    @Override
    public boolean isResource() {
        return this.getRequestUrl().contains(".");
    }

    @Override
    public void addCookie(HttpCookie cookie) {
        this.cookies.add(cookie);

    }
}
