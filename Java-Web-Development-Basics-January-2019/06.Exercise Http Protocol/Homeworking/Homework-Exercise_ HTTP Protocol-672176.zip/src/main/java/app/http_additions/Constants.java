package app.http_additions;

public final class Constants {

	private Constants() {
		
	}
	
	public static final String HTTP1 = "HTTP/1.1";
	
}
