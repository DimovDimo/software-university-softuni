package main.java;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class HttpRequestImpl implements HttpRequest {
    private Map<String, String> headers;
    private Map<String, String> bodyParameters;
    private String method;
    private String requestUrl;

    public HttpRequestImpl(List<String> httpRequest) {
        this.setHeaders(httpRequest);
        this.setBodyParameters(httpRequest);
        this.setMethod(httpRequest.get(1));
        this.setRequestUrl(httpRequest.get(1));
    }

    @Override
    public Map<String, String> getHeaders() {
        return this.headers;
    }

    @Override
    public Map<String, String> getBodyParameters() {
        return this.bodyParameters;
    }

    @Override
    public String getMethod() {
        return this.method;
    }

    @Override
    public void setMethod(String method) {
        this.method = method.split("\\s+")[0];
    }

    @Override
    public String getRequestUrl() {
        return this.requestUrl;
    }

    @Override
    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl.split("\\s+")[1];
    }

    @Override
    public void addHeader(String header, String value) {
        this.headers.put(header, value);
    }

    @Override
    public void addBodyParameter(String parameter, String value) {
        this.bodyParameters.put(parameter, value);
    }

    private void setHeaders(List<String> httpRequest) {
        this.headers = httpRequest.stream().skip(1).filter(line -> line.contains(": "))
                .map(line -> line.split(": ")).
                        collect(LinkedHashMap::new, (map, arr) -> map.put(arr[0], arr[1]), Map::putAll);

    }

    private void setBodyParameters(List<String> httpRequest) {
        if (httpRequest.get(httpRequest.size() - 1).equals("\r\n")) {
            this.bodyParameters = new LinkedHashMap<>();
        } else {
            this.bodyParameters = Arrays.stream(httpRequest.get(httpRequest.size() - 1).split("&"))
                    .map(line -> line.split("=")).
                            collect(LinkedHashMap::new, (map, line) -> map.put(line[0], line[1]), Map::putAll);
        }
    }
}
