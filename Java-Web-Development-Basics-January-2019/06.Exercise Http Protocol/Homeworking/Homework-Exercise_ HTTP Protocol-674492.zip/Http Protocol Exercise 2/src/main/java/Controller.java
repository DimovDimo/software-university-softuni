package main.java;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Base64;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Controller {
    private static final List<String> validHeaders = new LinkedList<>() {{
        add("Date");
        add("Host");
        add("Content-Type");
    }};
    private BufferedReader reader;
    private HttpRequest httpRequest;
    private HttpResponse httpResponse;

    public Controller(BufferedReader reader) {
        this.reader = reader;

    }

    public void run() throws IOException {
        List<String> inputrequest = new LinkedList<>();
        String line;
        while ((line = reader.readLine()) != null && line.length() > 0) {
            inputrequest.add(line);
        }
        inputrequest.add(System.lineSeparator());

        if ((line = reader.readLine()) != null && line.length() > 0) {
            inputrequest.add(line);
        }
        this.httpRequest = new HttpRequestImpl(inputrequest);
        this.httpResponse = new HttpResponseImpl();

        StringBuilder httpResponseContent = new StringBuilder();
        if (!inputrequest.get(0).contains(httpRequest.getRequestUrl())) {
            httpResponse.setStatusCode(404);
            httpResponseContent.append("HTTP/1.1 ").append(httpResponse.getStatusCode()).append(" Not Found")
                    .append(System.lineSeparator());
            appendHeaders(httpResponseContent);
            httpResponseContent.append("The requested functionality was not found.");
            httpResponse.setContent(httpResponseContent.toString().getBytes());
        } else if (!httpRequest.getHeaders().keySet().contains("Authorization")) {
            httpResponse.setStatusCode(401);
            httpResponseContent.append("HTTP/1.1 ").append(httpResponse.getStatusCode()).append(" Unauthorized")
                    .append(System.lineSeparator());
            appendHeaders(httpResponseContent);
            httpResponseContent.append("You are not authorized to access the requested functionality.");
            httpResponse.setContent(httpResponseContent.toString().getBytes());
        } else if (httpRequest.getMethod().equals("POST") && httpRequest.getBodyParameters().size() == 0) {
            httpResponse.setStatusCode(400);
            httpResponseContent.append("HTTP/1.1 ").append(httpResponse.getStatusCode()).append(" Bad Request")
                    .append(System.lineSeparator());
            appendHeaders(httpResponseContent);
            httpResponseContent.append("There was an error with the requested functionality due to malformed request.");
            httpResponse.setContent(httpResponseContent.toString().getBytes());
        } else {
            httpResponse.setStatusCode(200);
            httpResponseContent.append("HTTP/1.1 ").append(httpResponse.getStatusCode()).append(" OK")
                    .append(System.lineSeparator());
            appendHeaders(httpResponseContent);
            final int[] count = {0};
            List<String> responseBodyParameters = httpRequest.getBodyParameters().entrySet().stream().map((kvp) -> {
                if (count[0] == 0) {
                    count[0]++;
                    return kvp.getValue();
                }
                return kvp.getKey().concat(" - ").concat(kvp.getValue());
            }).collect(Collectors.toList());
            String response = String.format("Greetings %s! You have successfully created %s with %s, %s.",
                    new String(Base64.getDecoder().decode(httpRequest.getHeaders().get("Authorization").split("\\s+")[1])),
                    responseBodyParameters.get(0),
                    responseBodyParameters.get(1),
                    responseBodyParameters.get(2));
            httpResponseContent.append(response);
            httpResponse.setContent(httpResponseContent.toString().getBytes());
        }
        System.out.println(new String(httpResponse.getContent()));
    }

    private void appendHeaders(StringBuilder httpResponseContent) {
        httpRequest.getHeaders().entrySet().stream().filter(Controller::filterHeaders).forEach(entry ->
                httpResponseContent.append(entry.getKey()).append(": ").append(entry.getValue())
                        .append(System.lineSeparator()));
        httpResponseContent.append(System.lineSeparator());
    }

    private static boolean filterHeaders(Map.Entry<String, String> entry) {
        return validHeaders.contains(entry.getKey());
    }
}
