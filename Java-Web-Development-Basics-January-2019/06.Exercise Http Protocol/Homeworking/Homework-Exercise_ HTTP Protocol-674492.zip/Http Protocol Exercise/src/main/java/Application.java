package main.java;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.stream.Collectors;

public class Application {
    private static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) throws IOException {
        List<String> validUrls = getValidUrls();
        List<String> httpRequest = getHttpRequest();
        String method = getMethod(httpRequest.get(0));
        String url = getUrl(httpRequest.get(0));
        Map<String, String> headers = getHeaders(httpRequest);
        Map<String, String> requestBody = getRequestBody(httpRequest);

        StringBuilder httpResponse = new StringBuilder();
        if (!validUrls.contains(url)) {
            httpResponse.append("HTTP/1.1 404 Not Found")
                    .append(System.lineSeparator());
            httpResponse.append("The requested functionality was not found.")
                    .append(System.lineSeparator());
        } else if (!headers.keySet().contains("Authorization")) {
            httpResponse.append("HTTP/1.1 401 Unauthorized")
                    .append(System.lineSeparator());
            appendSuitableHeaders(headers, httpResponse);
            httpResponse.append("You are not authorized to access the requested functionality.")
                    .append(System.lineSeparator());
        } else if (method.equals("POST") && requestBody.size() == 0) {
            httpResponse.append("HTTP/1.1 401 Unauthorized")
                    .append(System.lineSeparator());
            appendSuitableHeaders(headers, httpResponse);
            httpResponse.append("There was an error with the requested functionality due to malformed request.")
                    .append(System.lineSeparator());
        } else {
            httpResponse.append("HTTP/1.1 200 OK")
                    .append(System.lineSeparator());
            appendSuitableHeaders(headers, httpResponse);
            final int[] count = {0};
            List<String> responseBodyParameters = requestBody.entrySet().stream().map((kvp) -> {
                if (count[0] == 0) {
                    count[0]++;
                    return kvp.getValue();
                }
                return kvp.getKey().concat(" - ").concat(kvp.getValue());
            }).collect(Collectors.toList());
            String response = String.format("Greetings %s! You have successfully created %s with %s, %s.",
                    new String(Base64.getDecoder().decode(headers.get("Authorization").split("\\s+")[1])),
                    responseBodyParameters.get(0),
                    responseBodyParameters.get(1),
                    responseBodyParameters.get(2));
            httpResponse.append(response)
                    .append(System.lineSeparator());
        }
        System.out.println(httpResponse.toString());

    }

    private static void appendSuitableHeaders(Map<String, String> headers, StringBuilder httpResponse) {
        headers.forEach((key, value) -> {
            if (key.equals("Date") || key.equals("Host") || key.equals("Content-Type")) {
                httpResponse.append(key).append(": ").append(value)
                        .append(System.lineSeparator());
            }
        });
    }

    private static Map<String, String> getRequestBody(List<String> httpRequest) {
        if (httpRequest.get(httpRequest.size() - 1).equals("\r\n")) {
            return new LinkedHashMap<>();
        }
        return Arrays.stream(httpRequest.get(httpRequest.size() - 1).split("&"))
                .map(line -> line.split("=")).
                        collect(LinkedHashMap::new, (map, line) -> map.put(line[0], line[1]), Map::putAll);
    }

    private static Map<String, String> getHeaders(List<String> httpRequest) {
        return httpRequest.stream().skip(1).filter(line -> line.contains(": "))
                .map(line -> line.split(": ")).
                        collect(LinkedHashMap::new, (map, arr) -> map.put(arr[0], arr[1]), Map::putAll);

    }

    private static String getUrl(String line) {
        return line.split("\\s+")[1];
    }

    private static String getMethod(String line) {
        return line.split("\\s+")[0];
    }

    private static List<String> getValidUrls() throws IOException {
        return Arrays.asList(reader.readLine().split("\\s+"));
    }

    private static List<String> getHttpRequest() throws IOException {
        List<String> request = new LinkedList<>();
        String line;
        while ((line = reader.readLine()) != null && line.length() > 0) {
            request.add(line);
        }
        request.add(System.lineSeparator());

        if ((line = reader.readLine()) != null && line.length() > 0) {
            request.add(line);
        }
        return request;
    }
}
