package javache.http.impl;

import javache.http.api.HttpSession;
import javache.http.api.HttpSessionStorage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class HttpSessionStorageImpl implements HttpSessionStorage {

    private HashMap<String, HttpSession> allSessions;

    public HttpSessionStorageImpl() {
        this.allSessions = new HashMap<>();
    }


    public HttpSession getById(String sessionId){

        if(!this.allSessions.containsKey(sessionId)){

            return null;
        }

        return this.allSessions.get(sessionId);
    }


    public void addSession(HttpSession session){

        this.allSessions.putIfAbsent(session.getId(),session);
    }

    public void refreshSession(){
        List<String> idsToRemove = new ArrayList<>();

        for (HttpSession session : this.allSessions.values()) {

            if(!session.isValid()){

                idsToRemove.add(session.getId());
            }
        }
    }

    public HashMap<String, HttpSession> getAllSessions() {
        return allSessions;
    }
}
