package javache.http.api;

public interface HttpCookie {

   String getName();

   String getValue();



}
