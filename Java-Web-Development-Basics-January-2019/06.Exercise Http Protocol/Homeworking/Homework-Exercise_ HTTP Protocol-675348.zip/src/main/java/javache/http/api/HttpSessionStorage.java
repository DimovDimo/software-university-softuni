package javache.http.api;

import java.util.HashMap;

public interface HttpSessionStorage {

    HttpSession getById(String sessionId);

    void addSession(HttpSession session);

    void refreshSession();

    HashMap<String, HttpSession> getAllSessions();
}
