package javache.http.api;

import javache.http.enums.HttpMethod;

import java.util.HashMap;
import java.util.Map;

public interface HttpRequest {


    HashMap<String,HttpCookie> getCookies();

    Map<String, String> getHeaders();

    String getName();

    String getPassword();

    String getSecondPassword();

    Map<String, String> getBodyParameters();

    HttpMethod getMethod();

    String getRequestUrl();

    boolean isResource();
}
