package javache.io;

import javache.constants.HttpConstants;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public final class Reader {

    private Reader() {
    }

    public static String readAllLines(final InputStream inputStream) throws IOException {
        final BufferedReader bufferedReader = new BufferedReader(
                new InputStreamReader(inputStream, HttpConstants.SERVER_ENCODING));

        final StringBuilder result = new StringBuilder();



        while (bufferedReader.ready()) {

            result.append((char) bufferedReader.read());

        }

        if(!result.toString().equalsIgnoreCase("")){
            System.out.println(result.toString());
        }

        return result.toString();
    }
}
