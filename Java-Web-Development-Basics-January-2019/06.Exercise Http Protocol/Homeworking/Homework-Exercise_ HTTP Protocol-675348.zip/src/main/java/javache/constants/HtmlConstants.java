package javache.constants;

public final class HtmlConstants {

    public static final String PLEASE_REGISTER= "<!DOCTYPE html>" +
            "<html lang=\"en\">" +
            "<head>" +
            "<meta charset=\"UTF-8\">" +
            "</head>" +
            "<body>" +
            "<h3>" +
            "You are not in the system!! Please Register" +
            "!</h3><hr/>" +
            "<p><a href=\"/index\">To Home</a></p>" +
            "<p><a href=\"login\">To Login page</a></p>"+
            "<p><a href=\"register\">To Register page</a></p>"+
            "</body></html>";

    public static final String UNMATCHED_PASSWORD= "<!DOCTYPE html>" +
            "<html lang=\"en\">" +
            "<head>" +
            "<meta charset=\"UTF-8\">" +
            "<title>Unmatched passwords</title>" +
            "</head>" +
            "<body>" +
            "<h3>" +
            "Check your passwords"+
            "!</h3><hr/>" +
            "<p><a href=\"/register\">To Register</a></p>" +
            "</body></html>";
}
