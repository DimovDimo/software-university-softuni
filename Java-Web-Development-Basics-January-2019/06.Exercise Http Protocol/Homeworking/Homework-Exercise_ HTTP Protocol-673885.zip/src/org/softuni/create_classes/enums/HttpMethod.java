package org.softuni.create_classes.enums;

public enum HttpMethod {
    GET,
    POST,
    DELETE,
    PUT
}
