package org.softuni.parsing_http_requests;

public enum HttpMethod {
    GET, POST
}
