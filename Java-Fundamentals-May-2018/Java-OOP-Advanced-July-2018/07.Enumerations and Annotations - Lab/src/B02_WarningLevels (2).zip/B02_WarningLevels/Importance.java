package B02_WarningLevels;

public enum Importance {
    HIGH,
    MEDIUM,
    NORMAL,
    LOW;
}
