package B02_WarningLevels;

public enum Importance {
    LOW, NORMAL, MEDIUM, HIGH;
}
