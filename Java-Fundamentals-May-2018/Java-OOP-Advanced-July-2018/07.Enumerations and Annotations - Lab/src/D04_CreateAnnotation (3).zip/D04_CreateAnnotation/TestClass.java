package D04_CreateAnnotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Subject(categories = {"Test", "Annotations"})
public class TestClass {
}
