package E05_CodingTracker;

public class Tracker {
    @Author(name = "Pesho")
    public static void main(String[] args) {
        Tracker.printMethodsByAuthor(Tracker.class);
    }

    @Author(name = "Pesho")
    public static void printMethodsByAuthor(Class<?> cl){
//        cl.
    }
}
