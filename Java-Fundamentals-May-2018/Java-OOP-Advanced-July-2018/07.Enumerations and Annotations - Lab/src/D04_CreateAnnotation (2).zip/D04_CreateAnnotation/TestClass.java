package D04_CreateAnnotation;

@Subject(categories = {"Test", "Annotations"})
public class TestClass {
}
