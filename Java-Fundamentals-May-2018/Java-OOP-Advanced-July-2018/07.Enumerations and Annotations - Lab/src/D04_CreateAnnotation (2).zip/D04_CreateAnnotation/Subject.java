package D04_CreateAnnotation;

public @interface Subject {
    String[] categories() default "";
}
