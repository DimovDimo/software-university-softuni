package C03_Mediator.enums;

public enum LogType {
    ATTACK, MAGIC, TARGET, ERROR, EVENT;
}
