package C03_Mediator.interfaces;

public interface Command {
    void execute();
}
