package C03_Mediator.interfaces;

public interface Executor {
    void executeCommand(Command command);
}
