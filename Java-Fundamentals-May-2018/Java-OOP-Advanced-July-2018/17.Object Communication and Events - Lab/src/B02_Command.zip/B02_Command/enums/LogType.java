package B02_Command.enums;

public enum LogType {
    ATTACK, MAGIC, TARGET, ERROR, EVENT;
}
