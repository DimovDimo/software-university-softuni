package B02_Command.interfaces;

public interface Target {
    void receiveDamage(int dmg);
    boolean isDead();
}