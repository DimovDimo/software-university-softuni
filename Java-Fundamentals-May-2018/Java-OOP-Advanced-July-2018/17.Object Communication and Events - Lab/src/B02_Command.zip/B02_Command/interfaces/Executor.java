package B02_Command.interfaces;

public interface Executor {
    void executeCommand(Command command);
}
