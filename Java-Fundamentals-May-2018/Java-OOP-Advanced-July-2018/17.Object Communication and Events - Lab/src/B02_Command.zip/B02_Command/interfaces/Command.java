package B02_Command.interfaces;

public interface Command {
    void execute();
}
