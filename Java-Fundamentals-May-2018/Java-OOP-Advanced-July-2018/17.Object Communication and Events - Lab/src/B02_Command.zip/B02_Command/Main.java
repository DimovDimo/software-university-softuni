package B02_Command;

import B02_Command.inplementations.Warrior;
import B02_Command.interfaces.Attacker;
import B02_Command.interfaces.Target;
import B02_Command.abstracts.Logger;
import B02_Command.enums.LogType;
import B02_Command.inplementations.commands.AttackCommand;
import B02_Command.inplementations.commands.CommandExecutor;
import B02_Command.inplementations.commands.TargetCommand;
import B02_Command.inplementations.loggers.CombatLogger;
import B02_Command.inplementations.loggers.ErrorLogger;
import B02_Command.inplementations.loggers.EventLogger;
import B02_Command.interfaces.Command;
import B02_Command.interfaces.Executor;
import B02_Command.interfaces.Target;

public class Main {
    public static void main(String[] args) {
        Logger combatLog = new CombatLogger();
        Logger eventLog = new EventLogger();

        combatLog.setSuccessor(eventLog);

//        Attacker warrior = new Warrior("Gosho", 10, combatLog);
//        Target target = (Target) new Dragon("Dragon", 5, 10, combatLog);

//        warrior.setTarget(target);
//        warrior.attack();

//        Executor executor = new CommandExecutor();
//        Command targetCommand = new TargetCommand(warrior, target);
//        Command attackrgetCommand = new AttackCommand(warrior);
//
//        executor.executeCommand(targetCommand);
//        executor.executeCommand(attackrgetCommand);
    }
}
