package A01_Logger.enums;

public enum LogType {
    ATTACK, MAGIC, TARGET, ERROR, EVENT;
}
