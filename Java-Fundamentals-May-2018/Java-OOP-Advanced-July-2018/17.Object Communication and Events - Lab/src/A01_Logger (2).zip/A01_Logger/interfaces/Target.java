package A01_Logger.interfaces;

public interface Target {
    void receiveDamage(int dmg);
    boolean isDead();
}