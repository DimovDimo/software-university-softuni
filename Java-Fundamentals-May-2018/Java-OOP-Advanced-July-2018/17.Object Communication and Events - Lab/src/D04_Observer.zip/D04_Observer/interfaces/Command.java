package D04_Observer.interfaces;

public interface Command {
    void execute();
}
