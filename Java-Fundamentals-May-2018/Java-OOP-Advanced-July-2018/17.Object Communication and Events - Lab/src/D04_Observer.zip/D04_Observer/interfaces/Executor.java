package D04_Observer.interfaces;

public interface Executor {
    void executeCommand(Command command);
}
