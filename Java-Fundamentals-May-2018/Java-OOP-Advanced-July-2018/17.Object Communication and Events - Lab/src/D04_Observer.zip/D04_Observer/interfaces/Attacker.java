package D04_Observer.interfaces;

public interface Attacker {
    void attack();
    void setTarget(Target target);
}
