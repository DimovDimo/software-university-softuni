package D04_Observer.enums;

public enum LogType {
    ATTACK, MAGIC, TARGET, ERROR, EVENT;
}
