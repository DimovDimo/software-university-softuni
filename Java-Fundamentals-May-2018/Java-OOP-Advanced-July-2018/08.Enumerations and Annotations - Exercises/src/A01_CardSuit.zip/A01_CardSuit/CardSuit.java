package A01_CardSuit;

public enum CardSuit {
    CLUBS,
    DIAMINDS,
    HEARTS,
    SPADES;

    CardSuit() {
    }
}
