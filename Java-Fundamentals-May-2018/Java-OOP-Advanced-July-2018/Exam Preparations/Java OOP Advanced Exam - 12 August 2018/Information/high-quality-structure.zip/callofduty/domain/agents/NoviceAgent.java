package callofduty.domain.agents;

public class NoviceAgent extends BaseAgent {
    public NoviceAgent(String id, String name) {
        super(id, name);
    }
}
