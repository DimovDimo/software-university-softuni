package panzer.contracts;

public interface OutputWriter {
    void println(String output);

    void print(String output);
}
