package enumeration;

public enum EngineType
{
    Jet,
    Sterndrive
}
