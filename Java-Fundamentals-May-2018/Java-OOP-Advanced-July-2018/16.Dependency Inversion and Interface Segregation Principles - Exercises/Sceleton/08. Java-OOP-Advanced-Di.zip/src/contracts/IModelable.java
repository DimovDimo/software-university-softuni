package contracts;

public interface IModelable {
    String getModel();
}
