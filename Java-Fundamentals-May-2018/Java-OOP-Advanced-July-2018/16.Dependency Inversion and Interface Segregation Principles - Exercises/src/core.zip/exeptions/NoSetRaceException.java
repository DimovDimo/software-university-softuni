package exeptions;

public class NoSetRaceException extends Exception{
    public NoSetRaceException(String message) {
        super(message);
    }
}
