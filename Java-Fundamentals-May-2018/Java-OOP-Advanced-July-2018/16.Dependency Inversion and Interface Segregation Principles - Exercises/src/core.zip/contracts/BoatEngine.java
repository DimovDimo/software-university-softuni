package contracts;

public interface BoatEngine extends Madable {
}
