package contracts;

public interface Madable {
}
