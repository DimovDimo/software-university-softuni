package contracts;

public interface Boat extends Madable {
}
