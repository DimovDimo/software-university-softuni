package interfaces;

public interface Behavior {

}
