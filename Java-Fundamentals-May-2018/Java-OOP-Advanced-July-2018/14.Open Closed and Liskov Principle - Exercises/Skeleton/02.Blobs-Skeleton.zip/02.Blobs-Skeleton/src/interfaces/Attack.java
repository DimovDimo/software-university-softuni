package interfaces;

public interface Attack {

}
