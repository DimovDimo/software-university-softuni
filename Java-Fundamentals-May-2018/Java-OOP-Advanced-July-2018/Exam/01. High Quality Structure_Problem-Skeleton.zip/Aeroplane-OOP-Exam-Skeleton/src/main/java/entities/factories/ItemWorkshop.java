package entities.factories;

import entities.factories.interfaces.ItemFactory;
import entities.items.interfaces.Item;

public class ItemWorkshop implements ItemFactory {
    @Override
    public Item createItem(String type) {
        return null;
    }
}
