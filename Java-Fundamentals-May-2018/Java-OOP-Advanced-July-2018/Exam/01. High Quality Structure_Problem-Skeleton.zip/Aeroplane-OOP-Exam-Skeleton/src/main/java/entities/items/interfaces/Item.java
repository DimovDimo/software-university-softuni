package entities.items.interfaces;

public interface Item {
    int getValue();
}

