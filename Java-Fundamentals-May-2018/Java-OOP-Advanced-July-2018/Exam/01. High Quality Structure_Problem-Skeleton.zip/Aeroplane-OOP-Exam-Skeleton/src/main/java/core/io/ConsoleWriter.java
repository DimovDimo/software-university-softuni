package core.io;

import core.io.interfacese.Writer;

public class ConsoleWriter implements Writer {

    @Override
    public void writeLine(String contents) {

    }

    @Override
    public void write(String contents) {

    }
}
