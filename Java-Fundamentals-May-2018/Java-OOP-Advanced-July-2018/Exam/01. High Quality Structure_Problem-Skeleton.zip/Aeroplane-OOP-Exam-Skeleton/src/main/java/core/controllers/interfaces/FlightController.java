package core.controllers.interfaces;

public interface FlightController {
    String takeOff();
}
