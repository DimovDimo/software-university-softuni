package core.controllers;

public class FlightManagerTest {
    //TODO ADD YOUR TESTS HERE
}