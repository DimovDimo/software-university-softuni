package entities.items;

public class Colombian extends BaseItem {
    public Colombian() {
        super(50000);
    }
}
