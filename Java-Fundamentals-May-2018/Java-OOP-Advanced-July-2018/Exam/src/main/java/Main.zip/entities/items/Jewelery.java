package entities.items;

public class Jewelery extends BaseItem {
    public Jewelery() {
        super(300);
    }
}
