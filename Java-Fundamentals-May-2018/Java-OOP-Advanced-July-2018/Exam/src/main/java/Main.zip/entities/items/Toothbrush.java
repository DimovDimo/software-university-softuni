package entities.items;

public class Toothbrush extends BaseItem {
    public Toothbrush() {
        super(3);
    }
}
