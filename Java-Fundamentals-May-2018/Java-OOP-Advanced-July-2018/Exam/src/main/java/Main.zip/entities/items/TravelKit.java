package entities.items;

public class TravelKit extends BaseItem {
    public TravelKit() {
        super(30);
    }
}
