package entities.airplanes;

public class MediumAirplane extends Airplane {
    public MediumAirplane() {
        super(10, 14);
    }
}
