package core.io.interfacese;

public interface Writer {
    void writeLine(String contents);

    void write(String contents);
}
