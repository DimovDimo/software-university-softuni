package hell;

import hell.entities.miscellaneous.HeroInventory;
import hell.entities.miscellaneous.heroes.Assassin;
import hell.entities.miscellaneous.heroes.Barbarian;
import hell.entities.miscellaneous.heroes.Wizard;
import hell.entities.miscellaneous.items.CommonItem;
import hell.interfaces.Hero;
import hell.interfaces.InputReader;
import hell.interfaces.Item;
import hell.interfaces.OutputWriter;
import hell.io.ConsoleInputReader;
import hell.io.ConsoleOutputWriter;

import java.util.Arrays;
import java.util.Map;

public class Main {
    private static Map<String, Hero> heroes;
    public static void main(String[] args) {
        InputReader inputReader = new ConsoleInputReader();
        OutputWriter outputWriter = new ConsoleOutputWriter();

        while (true){
            String line = inputReader.readLine();
            String[] tokens = line.split("\\s+");

            String command = tokens[0];
            String[] arguments = Arrays.stream(tokens).skip(1).toArray(String[]::new);

            String result = interpetCommand(command, arguments);

            outputWriter.writeLine(result);

            if ("Quit".equals(line)){
                break;
            }
        }
    }

    private static String interpetCommand(String command, String[] arguments) {
        Hero hero;
        switch (command){
            case "Hero":
                hero = createHero(arguments[0], arguments[1]);

                heroes.put(hero.getName(), hero);

                return String.format("Created %s - %s", hero.getClass().getSimpleName(), hero.getName());

            case "Item":
                hero = heroes.get(arguments[1]);
                Item item = new CommonItem(
                        arguments[0],
                        Integer.parseInt(arguments[2]),
                        Integer.parseInt(arguments[3]),
                        Integer.parseInt(arguments[4]),
                        Integer.parseInt(arguments[5]),
                        Integer.parseInt(arguments[6]));

                hero.addItem(item);

                return String.format("Added item - %s to Hero - %s", item.getName(), hero.getName());

            case "Recipe":

            case "Inspect":

            case "Quit":

        }

        return null;
    }

    private static Hero createHero(String name, String type) {
        switch (type){
            case "Barbarian":
                return new Barbarian(name, new HeroInventory());
            case "Assassin":
                return new Assassin(name, new HeroInventory());
            case "Wizard":
                return new Wizard(name, new HeroInventory());
        }

        return null;
    }
}