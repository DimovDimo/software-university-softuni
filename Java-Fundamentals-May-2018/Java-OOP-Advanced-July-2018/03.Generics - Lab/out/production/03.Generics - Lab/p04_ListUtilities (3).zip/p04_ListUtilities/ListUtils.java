package p04_ListUtilities;

import java.util.List;

public class ListUtils<T extends Comparable<T>> {

    public void checkItems(List<T> items) {
        if (items.size() == 0){
            throw new IllegalArgumentException();
        }
    }

    public T getMax(List<T> list){
        checkItems(list);
        T max = list.get(0);
        for (int i = 0; i < list.size(); i++) {
            if (max.compareTo(list.get(i)) < 0){
                max = list.get(i);
            }
        }

        return max;
    }

    public T getMix(List<T> list){
        checkItems(list);
        T min = list.get(0);
        for (int i = 0; i < list.size(); i++) {
            if (min.compareTo(list.get(i)) > 0){
                min = list.get(i);
            }
        }

        return min;
    }
}
