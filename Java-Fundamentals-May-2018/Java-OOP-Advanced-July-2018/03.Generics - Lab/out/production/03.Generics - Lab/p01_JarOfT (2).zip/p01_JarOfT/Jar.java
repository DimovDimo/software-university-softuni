package p01_JarOfT;

import java.util.ArrayDeque;

public class Jar<T> {

    private ArrayDeque<T> items;

    public Jar() {
        this.items = new ArrayDeque<>();
    }

    public void add(T element){
        this.items.push(element);
    }

    public T remove(){
        if (this.items.size() > 1){
            return this.items.poll();
        }

        return null;
    }
}
