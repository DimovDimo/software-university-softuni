package p02_GenericArrayCreator;

import java.util.List;

public class ArrayCreator<T> {

    @SuppressWarnings("unchecked")
    public static <T> T[] create(int length, T item){
        T[] arr = (T[]) new Object[length];
        for (int i = 0; i < length; i++) {
            arr[i] = item;
        }

        return arr;
    }

//    public static <T> T[] create(Class<T>, int length, T item){
//
//    }

}
