package p02_GenericArrayCreator;

public class Main {
}
