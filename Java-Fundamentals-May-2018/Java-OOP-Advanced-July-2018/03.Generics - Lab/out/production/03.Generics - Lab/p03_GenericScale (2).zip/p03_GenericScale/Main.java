package p03_GenericScale;

public class Main {
    public static void main(String[] args) {

    }
}
