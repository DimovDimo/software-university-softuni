package p01_JarOfT;

public class Main {
    public static void main(String[] args) {

        Jar<String> jarOfPickle = new Jar<>();

        jarOfPickle.add("add");
        jarOfPickle.add("add2");

        String pickle = jarOfPickle.remove();
    }
}
