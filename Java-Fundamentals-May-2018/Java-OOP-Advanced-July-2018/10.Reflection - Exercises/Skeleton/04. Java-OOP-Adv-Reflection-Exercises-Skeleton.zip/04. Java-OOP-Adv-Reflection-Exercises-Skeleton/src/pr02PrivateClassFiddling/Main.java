package pr02PrivateClassFiddling;

public class Main {

	public static void main(String[] args) {

	}
}
