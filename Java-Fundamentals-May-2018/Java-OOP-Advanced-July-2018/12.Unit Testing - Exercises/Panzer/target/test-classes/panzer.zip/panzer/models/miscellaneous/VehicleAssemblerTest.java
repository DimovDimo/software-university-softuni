package panzer.models.miscellaneous;

import org.junit.Before;
import org.junit.Test;

public class VehicleAssemblerTest {

    private VehicleAssembler vehicleAssembler;

    @Before
    public void setUp() throws Exception {
        this.vehicleAssembler = new VehicleAssembler();
    }

    @Test
    public void getTotalWeight() {
    }

    @Test
    public void getTotalPrice() {
    }

    @Test
    public void getTotalAttackModification() {
    }

    @Test
    public void getTotalDefenseModification() {
    }

    @Test
    public void getTotalHitPointModification() {
    }

    @Test
    public void addArsenalPart() {
    }

    @Test
    public void addShellPart() {
    }

    @Test
    public void addEndurancePart() {
    }
}