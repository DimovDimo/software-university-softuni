package net.java.main.exceptions;

public class GameException extends Exception {

    public GameException(String message) {
        super(message);
    }
}
