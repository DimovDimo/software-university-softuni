package net.java.main.commands;

public class GameOverCommand extends Command {

    @Override
    public String execute(String[] args) {
        return "Game over!";
    }
}
