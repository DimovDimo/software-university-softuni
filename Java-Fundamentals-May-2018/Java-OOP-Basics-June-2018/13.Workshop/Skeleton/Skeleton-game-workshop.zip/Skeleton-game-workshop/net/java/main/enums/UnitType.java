package net.java.main.enums;

public enum UnitType {
    MARINE;
}
