package net.java.main.io;

public class OutputWriter {

    public void writeLine(String line) {
        System.out.println(line);
    }
}
