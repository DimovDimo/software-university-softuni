package net.java.main.enums;

public enum SpellType {
    BULLET_RAIN,
    RAGE_SHOOT
}
