package net.java.main.exceptions;

public class UnitNotExistException extends UnitException {

    public UnitNotExistException(String message) {
        super(message);
    }
}
