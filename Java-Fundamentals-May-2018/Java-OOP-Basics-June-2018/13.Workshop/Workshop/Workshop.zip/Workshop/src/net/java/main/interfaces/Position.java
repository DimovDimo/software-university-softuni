package net.java.main.interfaces;

public interface Position {

    int getX();

    void setX(int x);

    int getY();

    void setY(int y);
}
