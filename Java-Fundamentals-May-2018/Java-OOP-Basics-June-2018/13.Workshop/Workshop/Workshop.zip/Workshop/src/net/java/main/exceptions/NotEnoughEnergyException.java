package net.java.main.exceptions;

public class NotEnoughEnergyException extends UnitException {

    public NotEnoughEnergyException(String message) {
        super(message);
    }
}
