package net.java.main.interfaces;

public interface Spell {

   int getDamage();

   int getEnergyCost();
}
