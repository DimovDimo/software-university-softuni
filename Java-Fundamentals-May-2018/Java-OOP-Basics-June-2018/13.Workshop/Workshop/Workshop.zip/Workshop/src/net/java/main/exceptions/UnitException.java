package net.java.main.exceptions;

public abstract class UnitException extends GameException {
    protected UnitException(String message) {
        super(message);
    }
}
