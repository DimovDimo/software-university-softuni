package net.java.main.exceptions;

public class InvalidPositionException extends UnitException {

    public InvalidPositionException(String message) {
        super(message);
    }
}
