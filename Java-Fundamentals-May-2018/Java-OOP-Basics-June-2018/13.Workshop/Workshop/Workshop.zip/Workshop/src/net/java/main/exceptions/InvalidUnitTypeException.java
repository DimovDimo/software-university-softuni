package net.java.main.exceptions;

public class InvalidUnitTypeException extends UnitException {

    public InvalidUnitTypeException(String message) {
        super(message);
    }
}
