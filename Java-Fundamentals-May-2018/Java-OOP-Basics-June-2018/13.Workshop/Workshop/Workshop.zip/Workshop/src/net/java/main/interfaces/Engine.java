package net.java.main.interfaces;

import java.io.IOException;

public interface Engine {

    void start() throws IOException;
}
