package net.java.main.interfaces;

import java.io.IOException;

public interface InputReader {

    String readLine() throws IOException;

}
