package net.java.main.exceptions;

public class UnknownCommandException extends GameException {
    public UnknownCommandException(String message) {
        super(message);
    }
}
