package p02_CarShop;

public interface Car {
    int TIRES = 4;

    String getModel();

    String getColor();

    int getHorsePower();
}
