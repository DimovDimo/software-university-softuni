package p04_SayHello;

public interface Person {
    String getName();
    String sayHello();
}
