package p05_SayHelloExtended;

public class Chinese extends BasePerson {

    public Chinese(String name) {
        super(name);
    }

    @Override
    public String sayHello() {
        System.out.println("Djydjybydjy");
        return null;
    }
}
