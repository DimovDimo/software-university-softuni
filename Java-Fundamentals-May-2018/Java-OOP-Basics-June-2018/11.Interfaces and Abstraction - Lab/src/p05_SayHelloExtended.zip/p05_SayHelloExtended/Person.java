package p05_SayHelloExtended;

public interface Person {
    String getName();
    String sayHello();
}
