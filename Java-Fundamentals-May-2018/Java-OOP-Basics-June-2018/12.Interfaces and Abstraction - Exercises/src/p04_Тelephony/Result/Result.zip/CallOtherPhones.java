

public interface CallOtherPhones {
    String Calling(String phone);
}
