

public interface BrowseInTheWorldWideWeb {
    String Browsing(String site);
}
