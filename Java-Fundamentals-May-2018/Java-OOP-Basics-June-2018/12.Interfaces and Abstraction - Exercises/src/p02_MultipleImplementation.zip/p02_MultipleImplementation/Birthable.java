package p02_MultipleImplementation;

public interface Birthable {
    String getBirthdate();
}
