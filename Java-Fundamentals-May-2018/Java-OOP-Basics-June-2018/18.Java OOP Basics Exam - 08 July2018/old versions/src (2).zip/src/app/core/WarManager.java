package app.core;

import app.contracts.Arena;
import app.contracts.ComicCharacter;
import app.contracts.Manager;
import app.contracts.SuperPower;

public class WarManager implements Manager {
    @Override
    public String checkComicCharacter(String characterName) {
        return null;
    }

    @Override
    public String addHero(ComicCharacter hero) {
        return null;
    }

    @Override
    public String addAntiHero(ComicCharacter antiHero) {
        return null;
    }

    @Override
    public String addArena(Arena arena) {
        return null;
    }

    @Override
    public String addHeroToArena(String arena, String hero) {
        return null;
    }

    @Override
    public String addAntiHeroToArena(String arena, String antiHero) {
        return null;
    }

    @Override
    public String loadSuperPowerToPool(SuperPower superPower) {
        return null;
    }

    @Override
    public String assignSuperPowerToComicCharacter(String comicCharacter, String superPower) {
        return null;
    }

    @Override
    public String usePowers(String characterName) {
        return null;
    }

    @Override
    public String startBattle(String arena) {
        return null;
    }

    @Override
    public String endWar() {
        return null;
    }
}
