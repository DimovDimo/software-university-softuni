package app.entities.ComicCharacter;

import app.contracts.ComicCharacter;
import app.contracts.SuperPower;

import java.util.ArrayList;
import java.util.Collection;

public abstract class ComicCharacterImpl implements ComicCharacter {

    private String name;
    private int energy;
    private double health;
    private double intelligence;
    private Collection<SuperPower> powers;

    public ComicCharacterImpl(String name, int energy, double health, double intelligence) {
        this.setName(name);
        this.setEnergy(energy);
        this.setHealth(health);
        this.setIntelligence(intelligence);
        this.setPowers();
    }

    private void setName(String name) {
        if (name.matches("(\\b[A-Za-z_]{2,12}\\b)") == false){
            throw new IllegalArgumentException("Comic Character name is not in the correct format!");
        }

        this.name = name;
    }

    private void setEnergy(int energy) {
        if (energy < 0 || 300 < energy){
            throw new IllegalArgumentException("Energy is not in the correct range!");
        }

        this.energy = energy;
    }

    private void setHealth(double health) {
        if (health <= 0){
            throw new IllegalArgumentException("Health should be a possitive number!");
        }

        this.health = health;
    }

    private void setIntelligence(double intelligence) {
        if (intelligence < 0 || 200 < intelligence){
            throw new IllegalArgumentException("Intelligence is not in the correct range!");
        }

        this.intelligence = intelligence;
    }

    private void setPowers() {
        this.powers = new ArrayList<>();
    }

    @Override
    public void takeDamage(double damage) {
        if (damage > 0){
            double newHealth = this.health - damage;
            this.setHealth(newHealth);
        }
    }

    @Override
    public void boostCharacter(int energy, double health, double intelligence) {
        this.setEnergy(energy);
        this.setHealth(health);
        this.setIntelligence(intelligence);
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public int getEnergy() {
        return this.energy;
    }

    @Override
    public double getHealth() {
        return this.health;
    }

    @Override
    public double getIntelligence() {
        return this.intelligence;
    }

    @Override
    public String useSuperPowers() {
        if (this.powers.isEmpty()){
            return String.format("%s has no super powers!", this.name);
        } else {
            for (SuperPower power : this.powers) {
                int newEnergy = this.energy + (int)power.getPowerPoints();
                this.setEnergy(newEnergy);

                double newHealth = this.health + (power.getPowerPoints() * 2);
                this.setHealth(newHealth);
            }

            return String.format("%s used his super powers!", this.name);
        }
    }

    @Override
    public void addSuperPower(SuperPower superPower) {
        this.powers.add(superPower);
    }

    @Override
    public String toString() {
        return null;
    }
}
