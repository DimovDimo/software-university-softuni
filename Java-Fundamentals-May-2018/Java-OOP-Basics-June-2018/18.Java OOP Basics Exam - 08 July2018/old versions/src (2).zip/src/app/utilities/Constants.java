package app.utilities;

public class Constants {
//    Input
    public final String INPUT_CHECK_CHARACTER = "CHECK_CHARACTER";
    public final String INPUT_REGISTER_HERO  = "REGISTER_HERO";
    public final String INPUT_REGISTER_ANTI_HERO = "REGISTER_ANTI_HERO";
    public final String INPUT_BUILD_ARENA = "BUILD_ARENA";
    public final String INPUT_SEND_HERO = "SEND_HERO";
    public final String INPUT_SEND_ANTI_HERO = "SEND_ANTI_HERO";
    public final String INPUT_SUPER_POWER  = "SUPER_POWER";
    public final String INPUT_ASSIGN_POWER  = "ASSIGN_POWER";
    public final String INPUT_UNLEASH = "UNLEASH";
    public final String INPUT_COMICS_WAR  = "COMICS_WAR";
    public final String INPUT_WAR_IS_OVER_TERMINATING_COMMAND  = "WAR_IS_OVER";
}
