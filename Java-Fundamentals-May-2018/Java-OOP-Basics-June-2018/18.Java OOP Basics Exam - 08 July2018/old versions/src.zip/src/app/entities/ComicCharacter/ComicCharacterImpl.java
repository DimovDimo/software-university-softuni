package app.entities.ComicCharacter;

import app.contracts.ComicCharacter;
import app.contracts.SuperPower;

import java.util.ArrayList;
import java.util.Collection;

public abstract class ComicCharacterImpl implements ComicCharacter {

    private String name;
    private int energy;
    private double health;
    private double intelligence;
    private Collection<SuperPower> powers;

    public ComicCharacterImpl(String name, int energy, double health, double intelligence) {
        this.setName(name);
        this.setEnergy(energy);
        this.setHealth(health);
        this.setIntelligence(intelligence);
        this.setPowers();
    }

    private void setName(String name) {
        if (name.matches("(\\b[A-Za-z_]{2,12}\\b)") == false){
            throw new IllegalArgumentException("Comic Character name is not in the correct format!");
        }

        this.name = name;
    }

    private void setEnergy(int energy) {
        if (energy < 0 || 300 < energy){
            throw new IllegalArgumentException("Energy is not in the correct range!");
        }

        this.energy = energy;
    }

    private void setHealth(double health) {
        if (health <= 0){
            throw new IllegalArgumentException("Health should be a possitive number!");
        }

        this.health = health;
    }

    private void setIntelligence(double intelligence) {
        if (intelligence < 0 || 200 < intelligence){
            throw new IllegalArgumentException("Intelligence is not in the correct range!");
        }

        this.intelligence = intelligence;
    }

    private void setPowers() {
        this.powers = new ArrayList<>();
    }

    @Override
    public void takeDamage(double damage) {

    }

    @Override
    public void boostCharacter(int energy, double health, double intelligence) {

    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getEnergy() {
        return 0;
    }

    @Override
    public double getHealth() {
        return 0;
    }

    @Override
    public double getIntelligence() {
        return 0;
    }

    @Override
    public String useSuperPowers() {
        return null;
    }

    @Override
    public void addSuperPower(SuperPower superPower) {

    }

    @Override
    public String toString() {
        return null;
    }
}
