package app.contracts;

public interface SuperPower {

    String getName();

	double getPowerPoints();
}
