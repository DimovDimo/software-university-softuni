package app.entities.Arena;

import app.contracts.Arena;
import app.contracts.ComicCharacter;
import app.entities.ComicCharacter.AntiHero.AntiHero;
import app.entities.ComicCharacter.Hero.Hero;

import java.util.ArrayList;
import java.util.Collection;

public class ArenaImpl implements Arena {

    private String arenaName;
    private Collection<Hero> heroes;
    private Collection<AntiHero> antiHeroes;
    private int capacity;

    public ArenaImpl(String arenaName, int capacity) {
        this.setArenaName(arenaName);
        this.setHeroes();
        this.setAntiHeroes();
        this.setCapacity(capacity);
    }

    public void setArenaName(String arenaName) {
        this.arenaName = arenaName;
    }

    public void setHeroes() {
        this.heroes = new ArrayList<>();
    }

    public void setAntiHeroes() {
        this.antiHeroes = new ArrayList<>();
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    @Override
    public String getArenaName() {
        return this.arenaName;
    }

    @Override
    public boolean isArenaFull() {
        if (this.heroes.size() + this.antiHeroes.size() >= this.capacity){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void addHero(ComicCharacter hero) {

    }

    @Override
    public void addAntiHero(ComicCharacter antiHero) {

    }

    @Override
    public boolean fightHeroes() {
        return false;
    }
}
