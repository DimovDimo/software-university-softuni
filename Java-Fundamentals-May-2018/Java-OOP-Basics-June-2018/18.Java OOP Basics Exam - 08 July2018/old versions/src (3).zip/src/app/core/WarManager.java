package app.core;

import app.contracts.Arena;
import app.contracts.ComicCharacter;
import app.contracts.Manager;
import app.contracts.SuperPower;

import java.util.HashMap;
import java.util.Map;

public class WarManager implements Manager {
    private Map<String, ComicCharacter> comicCharacters;
    private Map<String, Arena> arenes;

    public WarManager() {
        this.comicCharacters = new HashMap<>();
    }

    @Override
    public String checkComicCharacter(String characterName) {
        if (this.comicCharacters.containsKey(characterName) == false){
            return String.format("Sorry, fans! %s doesn't exist in our comics!", characterName);
        }

        if (this.comicCharacters.get(characterName).getHealth() <= 0){
            return String.format("%s has fallen in battle!", characterName);
        }

        return this.comicCharacters.get(characterName).toString();
    }

    @Override
    public String addHero(ComicCharacter hero) {
        if (this.comicCharacters.containsKey(hero.getName())){
            this.comicCharacters.get(hero.getName())
            .boostCharacter(hero.getEnergy(), hero.getHealth(), hero.getIntelligence());
            return String.format("%s evolved!", hero.getName());

        } else {
            this.comicCharacters.put(hero.getName(), hero);
            return String.format("%s is ready for battle!", hero.getName());
        }
    }

    @Override
    public String addAntiHero(ComicCharacter antiHero) {
        if (this.comicCharacters.containsKey(antiHero.getName())){
            this.comicCharacters.get(antiHero.getName())
                    .boostCharacter(antiHero.getEnergy(), antiHero.getHealth(), antiHero.getIntelligence());
            return String.format("%s is getting stronger!", antiHero.getName());

        } else {
            this.comicCharacters.put(antiHero.getName(), antiHero);
            return String.format("%s is ready for destruction!", antiHero.getName());
        }
    }

    @Override
    public String addArena(Arena arena) {
        if (this.arenes.containsKey(arena.getArenaName())){
            return "A battle is about to start there!";

        } else {
            this.arenes.put(arena.getArenaName(), arena);
            return String.format("%s is becoming a fighting ground!", arena.getArenaName());
        }
    }

    @Override
    public String addHeroToArena(String arena, String hero) {
        return null;
    }

    @Override
    public String addAntiHeroToArena(String arena, String antiHero) {
        return null;
    }

    @Override
    public String loadSuperPowerToPool(SuperPower superPower) {
        return null;
    }

    @Override
    public String assignSuperPowerToComicCharacter(String comicCharacter, String superPower) {
        return null;
    }

    @Override
    public String usePowers(String characterName) {
        return null;
    }

    @Override
    public String startBattle(String arena) {
        return null;
    }

    @Override
    public String endWar() {
        return null;
    }
}
