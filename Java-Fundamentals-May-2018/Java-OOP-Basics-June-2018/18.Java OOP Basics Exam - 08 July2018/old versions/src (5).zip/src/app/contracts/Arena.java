package app.contracts;

public interface Arena {

    String getArenaName();

	boolean isArenaFull();

	void addHero(ComicCharacter hero);

	void addAntiHero(ComicCharacter antiHero);

	boolean fightHeroes();

    boolean containsHero(ComicCharacter hero);

	boolean containsAntiHero(ComicCharacter antiHero);

	boolean containsParticipans();

	boolean startBattleIsHeroesWin();
}
