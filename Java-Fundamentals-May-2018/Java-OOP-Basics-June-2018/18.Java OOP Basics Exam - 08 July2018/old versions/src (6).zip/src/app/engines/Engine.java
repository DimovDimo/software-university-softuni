package app.engines;

import app.contracts.Manager;
import app.io.ConsoleInputReader;
import app.io.ConsoleOutputWriter;
import app.utilities.Constants;
import app.utilities.InputParser;

import java.util.List;

public class Engine {
    private ConsoleInputReader inputReader;
    private ConsoleOutputWriter outputWriter;
    private InputParser inputParser;
    private Manager manager;
    private Constants constants;

    public Engine(ConsoleInputReader inputReader, ConsoleOutputWriter outputWriter, InputParser inputParser, Manager manager) {
        this.inputReader = inputReader;
        this.outputWriter = outputWriter;
        this.inputParser = inputParser;
        this.manager = manager;
        this.constants = new Constants();
    }

    public void run(){
        String inputLine;

        while (true){
            inputLine = this.inputReader.readLine();
            List<String> commandParams = this.inputParser.parseInput(inputLine);

            this.dispachCommand(commandParams);

            if (inputLine.equals(this.constants.INPUT_WAR_IS_OVER_TERMINATING_COMMAND)){
                break;
            }
        }
    }

    private void dispachCommand(List<String> commandParams) {
        String command = commandParams.get(0);
		String result = null;
		
        switch (command){
			case "":

                break;
            case "":

                break;
            case "":

                break;
            case "":

                break;
            case "":

                break;
            case "":

                break;
            case "":

                break;
            case "":

                break;
            case "":

                break;
        }
		
        if (result != null){
            this.outputWriter.writeLine(result);
        }
    }
}
