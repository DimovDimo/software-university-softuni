package app.contracts;

public interface Rice {
}
