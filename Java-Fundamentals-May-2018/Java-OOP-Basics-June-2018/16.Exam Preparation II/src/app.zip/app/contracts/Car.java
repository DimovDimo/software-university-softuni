package app.contracts;

public interface Car {
}
