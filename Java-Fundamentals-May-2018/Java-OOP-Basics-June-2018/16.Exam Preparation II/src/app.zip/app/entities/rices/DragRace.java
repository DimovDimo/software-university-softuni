package app.entities.rices;

public class DragRace extends Race {
    public DragRace(int lenght, String route, int prizePool) {
        super(lenght, route, prizePool);
    }

}
