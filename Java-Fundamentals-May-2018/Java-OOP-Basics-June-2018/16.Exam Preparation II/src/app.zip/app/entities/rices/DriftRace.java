package app.entities.rices;

public class DriftRace {
}
