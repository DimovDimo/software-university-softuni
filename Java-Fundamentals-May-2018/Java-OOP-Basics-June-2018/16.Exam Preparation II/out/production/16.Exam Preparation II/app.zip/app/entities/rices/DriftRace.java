package app.entities.rices;

public class DriftRace extends Race {

    public DriftRace(int lenght, String route, int prizePool) {
        super(lenght, route, prizePool);
    }

}
