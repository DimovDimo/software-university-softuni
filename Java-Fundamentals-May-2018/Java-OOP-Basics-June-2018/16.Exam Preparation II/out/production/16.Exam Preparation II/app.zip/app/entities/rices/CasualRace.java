package app.entities.rices;

public class CasualRace extends Race {
    public CasualRace(int lenght, String route, int prizePool) {
        super(lenght, route, prizePool);
    }

}
