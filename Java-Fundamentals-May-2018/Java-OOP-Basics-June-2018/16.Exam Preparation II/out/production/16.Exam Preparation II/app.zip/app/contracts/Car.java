package app.contracts;

public interface Car {
    String getBrand();

    String getModel();

    void increaseHorsepower(int tuneIndex);

    void increaseSuspension(int tuneIndex);

    void tune(String element);

    int getEnginePerformance();

    int getOverallPerformance();

    int getSuspensionPerformance();

    String toString();
}
