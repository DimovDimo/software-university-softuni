package app.contracts;

public interface Race {
    int getWinnerMoney(int place);

    int getFirstPlaceMoney();

    int getSecondPlaceMoney();

    int getThirdPlaceMoney();

    void addParticipan(Car car);

    boolean hasCar(Car car);

    boolean hasParticipants();
}
