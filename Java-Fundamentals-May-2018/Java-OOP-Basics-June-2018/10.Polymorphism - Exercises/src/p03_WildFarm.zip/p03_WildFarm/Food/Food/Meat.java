package p03_WildFarm.Food.Food;

public class Meat extends Food {
    public Meat(String type, int quantity) {
        super(type, quantity);
    }
}
