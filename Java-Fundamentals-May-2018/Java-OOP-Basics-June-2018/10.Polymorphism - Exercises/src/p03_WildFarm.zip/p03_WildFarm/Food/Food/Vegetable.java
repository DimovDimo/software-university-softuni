package p03_WildFarm.Food.Food;

public class Vegetable extends Food {

    public Vegetable(String type, int quantity) {
        super(type, quantity);
    }
}
