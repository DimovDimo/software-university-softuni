package p03_WildFarm.Food.Animal;

public abstract class Felime extends Mammal {
    public Felime(String animalName, String animalType, Double animalWeight, Integer foodEaten, String livingegion) {
        super(animalName, animalType, animalWeight, foodEaten, livingegion);
    }
}
