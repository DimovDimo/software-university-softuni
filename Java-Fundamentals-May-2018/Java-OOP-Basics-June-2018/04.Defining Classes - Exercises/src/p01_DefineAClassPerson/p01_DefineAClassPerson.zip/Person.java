package p01_DefineAClassPerson;

public class Person {
    private String name;
    private int age;
}
