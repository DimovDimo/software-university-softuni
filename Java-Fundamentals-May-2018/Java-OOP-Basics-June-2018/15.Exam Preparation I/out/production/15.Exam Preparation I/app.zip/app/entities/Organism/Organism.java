package app.entities.Organism;

import app.entities.Cluster.Cluster;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

public class Organism {
    private String name;
    private Collection<Cluster> clusters;

    public Organism(String name) {
        this.name = name;
        this.clusters = new ArrayList<>();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
