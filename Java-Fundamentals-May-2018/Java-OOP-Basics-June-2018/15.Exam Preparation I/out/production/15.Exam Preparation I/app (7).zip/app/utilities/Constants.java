package app.utilities;

public class Constants {
}
