package app.core;

import app.entities.Organism.Organism;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class HealthManager {
    private Map<String, Organism> organisms;

    public HealthManager() {
        this.organisms = new HashMap<>();
    }

    public  String checkCondition(String organismName){
        Organism organism = this.organisms.get(organismName);
        return organism.toString();
    }

    public  String createOrganism(String name){
        return null;
    }

    public  String addCluster(String organismName, String id, int rows, int cols){
        return null;
    }

    public  String addCell(String organismName, String clusterId, String cellType, String cellId, int health, int positionRow, int positionCol, int additionalProperty){
        return null;
    }

    public  String activateCluster(String organismName){
        return null;
    }


}
