package app.core;

import app.entities.Cluster.Cluster;
import app.entities.Organism.Organism;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class HealthManager {
    private Map<String, Organism> organisms;

    public HealthManager() {
        this.organisms = new HashMap<>();
    }

    public  String checkCondition(String organismName){
        Organism organism = this.organisms.get(organismName);
        return organism.toString();
    }

    public  String createOrganism(String name){
        if (this.organisms.containsKey(name)){
            return String.format("Organism %s already exists", name);
        }

        Organism organism = new Organism(name);
        this.organisms.put(name, organism);
        return String.format("Created organism %s", name);
    }

    public  String addCluster(String organismName, String id, int rows, int cols){
        if (this.organisms.get(organismName).containsId(id)){
            return null;
        }

        Cluster cluster = new Cluster(id, rows, cols);
        this.organisms.get(organismName).getClusters().add(cluster);
        return String.format("Organism %s: Created cluster %s", organismName, id);
    }

    public  String addCell(String organismName, String clusterId, String cellType, String cellId, int health, int positionRow, int positionCol, int additionalProperty){
        return null;
    }

    public  String activateCluster(String organismName){
        return null;
    }


}
