package p02_MultilevelInheritance;

public class Animal {
    public void eat(){
        System.out.println("eating…");
    }
}
