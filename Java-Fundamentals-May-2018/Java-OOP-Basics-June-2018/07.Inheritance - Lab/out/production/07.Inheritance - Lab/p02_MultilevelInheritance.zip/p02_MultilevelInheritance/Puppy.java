package p02_MultilevelInheritance;

public class Puppy extends Dog {
    public void weep(){
        System.out.println("weeping…");
    }
}
