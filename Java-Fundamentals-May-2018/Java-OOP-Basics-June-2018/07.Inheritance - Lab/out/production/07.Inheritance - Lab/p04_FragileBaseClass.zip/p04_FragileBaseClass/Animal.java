package p04_FragileBaseClass;

import java.util.ArrayList;

public class Animal {
    protected ArrayList<Food> foodEaten;

    public void eatAll(Food[] foods){

    }

    public final void eat(Food food){

    }
}
