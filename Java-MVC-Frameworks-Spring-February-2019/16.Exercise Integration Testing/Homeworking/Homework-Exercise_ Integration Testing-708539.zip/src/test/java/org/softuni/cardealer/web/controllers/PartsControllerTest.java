package org.softuni.cardealer.web.controllers;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.softuni.cardealer.domain.entities.Part;
import org.softuni.cardealer.domain.entities.Supplier;
import org.softuni.cardealer.repository.PartRepository;
import org.softuni.cardealer.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
@AutoConfigureMockMvc
public class PartsControllerTest {
	private static final String NAME = "tire";
	private static final String PRICE = "100";
	private static final String SUPPLIER = "supplier";

	private static final String PRICE_PARAM = "price";
	private static final String NAME_PARAM = "name";

	private static final String ADD_PATH = "/add";
	private static final String ALL_PATH = "/all";
	private static final String PARTS_PATH = "/parts";

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private PartRepository partRepository;

	@Autowired
	private SupplierRepository supplierRepository;

	@Before
	public void setUp() {
		partRepository.deleteAll();
		supplierRepository.deleteAll();
	}

	@Test
	@WithMockUser
	public void testAddPartRedirectsToCorrectView() throws Exception {
		supplierRepository.saveAndFlush(createDefaultSupplier());

		mockMvc.perform(
				post(PARTS_PATH + ADD_PATH).param(NAME_PARAM, NAME).param(PRICE_PARAM, PRICE).param(SUPPLIER, SUPPLIER))
				.andExpect(redirectedUrl("all"));
	}

	@Test
	@WithMockUser
	public void testAddPartCorrectlySavesPart() throws Exception {
		supplierRepository.saveAndFlush(createDefaultSupplier());

		mockMvc.perform(post(PARTS_PATH + ADD_PATH).param(NAME_PARAM, NAME).param(PRICE_PARAM, PRICE).param(SUPPLIER,
				SUPPLIER));

		Part part = partRepository.findAll().get(0);
		assertThat(part.getName(), equalTo(NAME));
		assertThat(part.getPrice(), equalTo(new BigDecimal(PRICE).setScale(2, BigDecimal.ROUND_HALF_UP)));
		assertThat(part.getSupplier().getName(), equalTo(SUPPLIER));
	}

	@Test
	@WithMockUser
	public void testAllPartsReturnsCorrectView() throws Exception {
		mockMvc.perform(get(PARTS_PATH + ALL_PATH)).andExpect(view().name("all-parts"));
	}

	@Test
	@WithMockUser
	public void testAllPartsContainsCorrectAttributes() throws Exception {
		mockMvc.perform(get(PARTS_PATH + ALL_PATH)).andExpect(model().attributeExists("parts"));
	}

	@Test
	@WithMockUser
	public void testFetchPartsReturnsCorrectPart() throws UnsupportedEncodingException, Exception {
		Supplier partSupplier = createDefaultSupplier();

		Part part = new Part();
		part.setName(NAME);
		part.setPrice(new BigDecimal(PRICE));
		part.setSupplier(partSupplier);

		part = partRepository.saveAndFlush(part);

		String responseBody = mockMvc.perform(get(PARTS_PATH + "/fetch")).andExpect(status().isOk()).andReturn()
				.getResponse().getContentAsString();

		String expected = "[{\"id\":\"" + part.getId() + "\",\"name\":\"tire\",\"price\":100.00,\"supplier\":{\"id\":\""
				+ part.getSupplier().getId() + "\",\"name\":\"supplier\",\"isImporter\":true}}]";
		assertThat(responseBody, equalTo(expected));
	}

	private Supplier createDefaultSupplier() {
		Supplier supplier = new Supplier();
		supplier.setIsImporter(true);
		supplier.setName(SUPPLIER);
		return supplier;
	}

}
