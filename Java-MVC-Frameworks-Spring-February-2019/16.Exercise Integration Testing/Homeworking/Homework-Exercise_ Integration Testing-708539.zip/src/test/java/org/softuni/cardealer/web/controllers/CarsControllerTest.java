package org.softuni.cardealer.web.controllers;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.Collections;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.softuni.cardealer.domain.entities.Car;
import org.softuni.cardealer.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CarsControllerTest {
	private static final String PARTS = "parts";
	private static final String TRAVELLED_DISTANCE = "travelledDistance";
	private static final long DISTANCE = 123L;
	private static final String MAKE = "make";
	private static final String MODEL = "model";
	private static final String CAR_PATH = "/cars";

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private CarRepository carRepository;

	@Before
	public void setUp() {
		carRepository.deleteAll();
	}

	@Test
	@WithMockUser
	public void testAllCarsReturnsCorrectView() throws Exception {
		mockMvc.perform(get(CAR_PATH + "/all")).andExpect(view().name("all-cars"));
	}

	@Test
	@WithMockUser
	public void testDeleteCarRedirectToCorrectly() throws Exception {
		Car car = createDefaultCar();
		car = carRepository.saveAndFlush(car);

		mockMvc.perform(post(CAR_PATH + "/delete/" + car.getId())).andExpect(redirectedUrl("/cars/all"));
	}

	@Test(expected = Exception.class)
	@WithMockUser
	public void testDeleteCarThrowsExceptionBecauseOfInvalidCarId() throws Exception {
		mockMvc.perform(post(CAR_PATH + "/delete/" + "invalidCarId"));
	}

	@Test
	@WithMockUser
	public void testEditCarEditsExistingCar() throws Exception {
		Car car = createDefaultCar();
		car = carRepository.saveAndFlush(car);

		String newModel = "newModel";
		String newMake = "newMake";
		String newDistance = "345";

		mockMvc.perform(post(CAR_PATH + "/edit/" + car.getId()).param(MAKE, newMake).param(MODEL, newModel)
				.param(TRAVELLED_DISTANCE, newDistance).param(PARTS, "")).andExpect(redirectedUrl(CAR_PATH + "/all"));

		Car edited = carRepository.findById(car.getId()).get();
		assertThat(edited.getMake(), equalTo(newMake));
		assertThat(edited.getModel(), equalTo(newModel));
		assertThat(edited.getTravelledDistance(), equalTo(Long.valueOf(newDistance)));
	}

	@Test
	@WithMockUser
	public void testAddCarRedirectsCorrectly() throws Exception {
		mockMvc.perform(post(CAR_PATH + "/add").param(MAKE, MAKE).param(MODEL, MODEL)
				.param(TRAVELLED_DISTANCE, String.valueOf(DISTANCE)).param(PARTS, "")).andExpect(redirectedUrl("all"));
	}

	private Car createDefaultCar() {
		Car car = new Car();
		car.setMake(MAKE);
		car.setModel(MODEL);
		car.setParts(Collections.emptyList());
		car.setTravelledDistance(DISTANCE);
		return car;
	}
}
