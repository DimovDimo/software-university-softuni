package org.softuni.cardealer.web.controllers;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.softuni.cardealer.domain.entities.Customer;
import org.softuni.cardealer.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CustomersControllerTest {
	private static final String NAME_PARAM = "name";
	private static final String BIRTH_DATE_PARAM = "birthDate";
	private static final String ALL_CUSTOMERS_URI = "/customers/all";
	private static final String ADD_CUSTOMERS_URI = "/customers/add";
	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private CustomerRepository customerRepository;

	@Test
	@WithMockUser
	public void addCustomerRedirectsToCorrectView() throws Exception {
		String customerName = "bestCustomer";
		String customerBirthDate = "1111-11-11";

		mockMvc.perform(
				post(ADD_CUSTOMERS_URI).param(NAME_PARAM, customerName).param(BIRTH_DATE_PARAM, customerBirthDate))
				.andExpect(redirectedUrl("all"));
	}

	@Test
	@WithMockUser
	public void addCustomerSavesCustomerCorrectly() throws Exception {
		String customerName = "bestCustomer";
		String customerBirthDate = "1111-11-11";

		mockMvc.perform(
				post(ADD_CUSTOMERS_URI).param(NAME_PARAM, customerName).param(BIRTH_DATE_PARAM, customerBirthDate));

		Customer customer = customerRepository.findAll().get(0);
		assertThat(customerRepository.count(), equalTo(1L));
		assertThat(customer.getName(), equalTo(customerName));
		assertThat(customer.getIsYoungDriver(), equalTo(false));
		assertThat(customer.getBirthDate().toString(), equalTo(customerBirthDate));
	}

	@Test
	@WithMockUser
	public void allCustomersReturnsCorrectView() throws Exception {
		mockMvc.perform(get(ALL_CUSTOMERS_URI)).andExpect(view().name("all-customers"));
	}

	@Test
	@WithMockUser
	public void allCustomersContainsCorrectAttribute() throws Exception {
		mockMvc.perform(get(ALL_CUSTOMERS_URI)).andExpect(model().attributeExists("customers"));
	}

}
