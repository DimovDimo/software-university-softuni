package org.softuni.cardealer.web.controllers;

import static org.junit.Assert.assertEquals;
import static org.springframework.boot.jdbc.EmbeddedDatabaseConnection.H2;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.io.UnsupportedEncodingException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.softuni.cardealer.domain.entities.Supplier;
import org.softuni.cardealer.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(connection = H2)
public class SupplierControllerTest {
	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private SupplierRepository supplierRepository;

	@Before
	public void setUp() {
		supplierRepository.deleteAll();
	}

	@Test
	@WithMockUser("spring")
	public void add_SavesEntityCorrectly() throws Exception {
		mockMvc.perform(post("/suppliers/add").param("name", "softuni").param("isImporter", "off"));
		mockMvc.perform(post("/suppliers/add").param("name", "stamat").param("isImporter", "true"));

		Supplier supplier = supplierRepository.findAll().get(1);

		assertEquals(2L, supplierRepository.count());
		assertEquals("stamat", supplier.getName());
		assertEquals(true, supplier.getIsImporter());
	}

	@Test
	@WithMockUser("spring")
	public void add_RedirectCorrectly() throws Exception {
		mockMvc.perform(post("/suppliers/add").param("name", "softuni").param("isImporter", "off"))
				.andExpect(view().name("redirect:all"));
	}

	@Test
	@WithMockUser()
	public void edit_WorksCorrectly() throws Exception {
		Supplier supplier = new Supplier();
		supplier.setName("softuni");
		supplier.setIsImporter(false);

		Supplier secondSupplier = new Supplier();
		secondSupplier.setName("stamant");
		secondSupplier.setIsImporter(true);

		supplier = supplierRepository.saveAndFlush(supplier);
		secondSupplier = supplierRepository.saveAndFlush(secondSupplier);

		mockMvc.perform(
				post("/suppliers/edit/" + supplier.getId()).param("name", "SOFTUNI").param("isImporter", "true"));
		mockMvc.perform(
				post("/suppliers/edit/" + secondSupplier.getId()).param("name", "STAMAT").param("isImporter", "false"));

		Supplier firstActual = supplierRepository.findById(supplier.getId()).orElse(null);
		Supplier secondActual = supplierRepository.findById(secondSupplier.getId()).orElse(null);

		Assert.assertEquals("SOFTUNI", firstActual.getName());
		Assert.assertEquals(true, firstActual.getIsImporter());

		assertEquals("STAMAT", secondActual.getName());
		Assert.assertEquals(false, secondActual.getIsImporter());
	}

	@Test
	@WithMockUser
	public void delete_WorksCorrectly() throws Exception {
		Supplier supplier = new Supplier();
		supplier.setName("softuni");
		supplier.setIsImporter(false);

		Supplier secondSupplier = new Supplier();
		secondSupplier.setName("stamant");
		secondSupplier.setIsImporter(true);

		supplierRepository.deleteAll();
		supplier = supplierRepository.saveAndFlush(supplier);
		secondSupplier = supplierRepository.saveAndFlush(secondSupplier);

		mockMvc.perform(post("/suppliers/delete/" + supplier.getId()));

		assertEquals(1, supplierRepository.count());

		mockMvc.perform(post("/suppliers/delete/" + secondSupplier.getId()));

		assertEquals(0, supplierRepository.count());
	}

	@Test(expected = Exception.class)
	@WithMockUser
	public void delete_ThrowsExceptionWhenInvalidIdGiven() throws Exception {
		mockMvc.perform(post("/suppliers/delete/pesho"));
	}

	@Test
	public void all_WithGuestRedirectToLogin() throws Exception {
		mockMvc.perform(get("/suppliers/all")).andExpect(redirectedUrl("http://localhost/users/login"));
	}

	@Test
	@WithMockUser
	public void all_returnsCorrectView() throws Exception {
		mockMvc.perform(get("/suppliers/all")).andExpect(view().name("all-suppliers"));
	}

	@Test
	@WithMockUser
	public void all_returnsCorrectAttribute() throws Exception {
		mockMvc.perform(get("/suppliers/all")).andExpect(view().name("all-suppliers"))
				.andExpect(model().attributeExists("suppliers"));
	}

	@Test
	@WithMockUser
	public void fetch_WorksCorrectly() throws UnsupportedEncodingException, Exception {
		Supplier supplier = new Supplier();
		supplier.setName("softuni");
		supplier.setIsImporter(false);

		supplierRepository.deleteAll();
		supplier = supplierRepository.saveAndFlush(supplier);

		String responseBody = mockMvc.perform(get("/suppliers/fetch")).andExpect(status().isOk()).andReturn()
				.getResponse().getContentAsString();

		assertEquals("[{\"id\":\"" + supplier.getId() + "\",\"name\":\"softuni\",\"isImporter\":false}]", responseBody);

	}
}
