package org.softuni.cardealer.web.controllers;

import static org.junit.Assert.assertEquals;
import static org.springframework.boot.jdbc.EmbeddedDatabaseConnection.H2;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.softuni.cardealer.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(connection = H2)
public class UserControllerTest {
	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private UserRepository userRepository;

	@Before
	public void setUp() {
		userRepository.deleteAll();
	}

	@Test
	public void login_ReturnsCorrectView() throws Exception {
		mockMvc.perform(get("/users/login")).andExpect(view().name("login"));
	}

	@Test
	public void register_ReturnsCorrectView() throws Exception {
		mockMvc.perform(get("/users/register")).andExpect(view().name("register"));
	}

	@Test
	public void register_RegistersUserCorrectly() throws Exception {
		mockMvc.perform(post("/users/register").param("username", "pesho").param("password", "123")
				.param("confirmPassword", "123").param("email", "test@email.com"));

		assertEquals(1, userRepository.count());
	}

	@Test
	public void register_RegisterRedirectCorrectly() throws Exception {
		mockMvc.perform(post("/users/register").param("username", "pesho").param("password", "123")
				.param("confirmPassword", "123").param("email", "test@email.com"))
				.andExpect(view().name("redirect:login"));
	}

}
