package org.softuni.cardealer.web.controllers;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.softuni.cardealer.domain.entities.Part;
import org.softuni.cardealer.domain.entities.Supplier;
import org.softuni.cardealer.repository.PartRepository;
import org.softuni.cardealer.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
@AutoConfigureMockMvc
public class PartsControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private PartRepository partRepository;
    @Autowired
    private SupplierRepository supplierRepository;

    @Before
    public void emptyDb() {
        partRepository.deleteAll();
        supplierRepository.deleteAll();
    }

    @Test
    @WithMockUser("spring")
    public void add_RedirectsCorrectly() throws Exception {
        Supplier supplier = new Supplier();
        supplier.setIsImporter(true);
        supplier.setName("supplier");
        supplierRepository.saveAndFlush(supplier);

        mockMvc.perform(
                post("/parts/add").param("name", "name").param("price", "100").param("supplier", "supplier"))
                .andExpect(redirectedUrl("all"));
    }

    @Test
    @WithMockUser("spring")
    public void add_SavesCorrectly() throws Exception {
        Supplier supplier = new Supplier();
        supplier.setIsImporter(true);
        supplier.setName("supplier");
        supplierRepository.saveAndFlush(supplier);

        mockMvc.perform(post("/parts/add").param("name", "name").param("price", "100").param("supplier",
                "supplier"));

        Part part = partRepository.findAll().get(0);
        Assert.assertEquals(part.getName(), ("name"));
        Assert.assertEquals(part.getPrice(), new BigDecimal(100).setScale(2));
        Assert.assertEquals(part.getSupplier().getName(), "supplier");
    }

    @Test
    @WithMockUser("spring")
    public void all_ReturnsCorrectView() throws Exception {
        mockMvc.perform(get("/parts/all")).andExpect(view().name("all-parts"));
    }

    @Test
    @WithMockUser("spring")
    public void all_ContainsCorrectAttributes() throws Exception {
        mockMvc.perform(get("/parts/all")).andExpect(model().attributeExists("parts"));
    }

    @Test
    @WithMockUser("spring")
    public void fetch_ReturnsCorrectPart() throws Exception {
        Supplier supplier = new Supplier();
        supplier.setIsImporter(true);
        supplier.setName("supplier");
        supplierRepository.saveAndFlush(supplier);

        Part part = new Part();
        part.setName("name");
        part.setPrice(new BigDecimal(100));
        part.setSupplier(supplier);

        part = partRepository.saveAndFlush(part);

        String responseBody = mockMvc.perform(get("/parts/fetch")).andExpect(status().isOk()).andReturn()
                .getResponse().getContentAsString();

        String expected = "[{\"id\":\"" + part.getId() + "\",\"name\":\"name\",\"price\":100.00,\"supplier\":{\"id\":\""
                + part.getSupplier().getId() + "\",\"name\":\"supplier\",\"isImporter\":true}}]";

        Assert.assertEquals(responseBody, expected);
    }

}
