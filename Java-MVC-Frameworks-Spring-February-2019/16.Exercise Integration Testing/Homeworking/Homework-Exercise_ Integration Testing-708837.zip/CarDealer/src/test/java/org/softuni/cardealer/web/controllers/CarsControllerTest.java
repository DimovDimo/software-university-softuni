package org.softuni.cardealer.web.controllers;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.softuni.cardealer.domain.entities.Car;
import org.softuni.cardealer.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CarsControllerTest {

    @Autowired
    private MockMvc mvc;
    @Autowired
    private CarRepository carRepository;

    @Before
    public void emptyDb() {
        this.carRepository.deleteAll();
    }

    @Test
    @WithMockUser("spring")
    public void add_savesEntityCorrectly() throws Exception {
        this.mvc.perform(
                post("/cars/add")
                        .param("make", "make")
                        .param("model", "model")
                        .param("travelledDistance", String.valueOf(125L)));

        Car car = this.carRepository.findAll().get(0);
        Assert.assertEquals(1, this.carRepository.count());
        Assert.assertEquals("make", car.getMake());
        Assert.assertEquals("model", car.getModel());
        Assert.assertEquals("125", String.valueOf(car.getTravelledDistance()));
    }

    @Test
    @WithMockUser("spring")
    public void add_redirectCorrectly() throws Exception {
        this.mvc.perform(
                post("/cars/add")
                        .param("make", "make")
                        .param("model", "model")
                        .param("travelledDistance", String.valueOf(125L)))
                .andExpect(view().name("redirect:all"));
    }

    @Test
    @WithMockUser("spring")
    public void edit_EditsCorrectly() throws Exception {
        Car first = new Car();
        first.setMake("make");
        first.setModel("model");
        first.setTravelledDistance(123L);

        first = this.carRepository.saveAndFlush(first);

        this.mvc.perform(
                post("/cars/edit/" + first.getId())
                        .param("make", "make_edit")
                        .param("model", "model_edit")
                        .param("travelledDistance", String.valueOf(125L)));

        Car firstActual = this.carRepository.findById(first.getId()).get();

        Assert.assertEquals("make_edit", firstActual.getMake());
        Assert.assertEquals("model_edit", firstActual.getModel());
        Assert.assertEquals("125", String.valueOf(firstActual.getTravelledDistance()));
    }

    @Test
    @WithMockUser("spring")
    public void delete_DeletesCorrectly() throws Exception {
        Car first = new Car();
        first.setMake("make");
        first.setModel("model");
        first.setTravelledDistance(123L);

        first = this.carRepository.saveAndFlush(first);

        this.mvc.perform(
                post("/cars/delete/" + first.getId()));
        Assert.assertEquals(0, this.carRepository.count());
    }

    @Test
    public void all_withGuestRedirectToLogin() throws Exception {
        this.mvc.perform(
                get("/cars/all")
        ).andExpect(redirectedUrl("http://localhost/users/login"));
    }

    @Test
    @WithMockUser("spring")
    public void all_returnsCorrectView() throws Exception {
        this.mvc.perform(
                get("/cars/all")
        ).andExpect(view().name("all-cars"));
    }
}
