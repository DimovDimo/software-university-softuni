package org.softuni.cardealer.web.controllers;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.softuni.cardealer.domain.entities.Customer;
import org.softuni.cardealer.repository.CustomerRepository;
import org.softuni.cardealer.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CustomerControllerTest {



    @Autowired
    private MockMvc mvc;

    @Autowired
    private CustomerRepository customerRepository;


    @Before
    public void emptyDb(){
        customerRepository.deleteAll();
    }



    @Test
    @WithMockUser("spring")
    public  void add_test() throws Exception {

        this.mvc
                .perform(post("/customers/add")
                        .param("name", "Customer")
                        .param("birthDate", "2000-02-01")
                );
        Assert.assertEquals(1, customerRepository.count());
    }


    @Test
    @WithMockUser("spring")
    public void all_returns_correct_attribute() throws Exception {
        mvc.perform(get("/customers/all"))
                .andExpect(view().name("all-customers"))
                .andExpect(model().attributeExists("customers"));
    }

}
