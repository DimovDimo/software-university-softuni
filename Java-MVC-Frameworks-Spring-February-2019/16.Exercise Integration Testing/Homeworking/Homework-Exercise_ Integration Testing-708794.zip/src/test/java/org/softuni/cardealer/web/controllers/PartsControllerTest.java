package org.softuni.cardealer.web.controllers;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.softuni.cardealer.domain.entities.Part;
import org.softuni.cardealer.domain.entities.Supplier;
import org.softuni.cardealer.domain.models.binding.AddPartBindingModel;
import org.softuni.cardealer.repository.PartRepository;
import org.softuni.cardealer.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class PartsControllerTest {


    @Autowired
    private MockMvc mvc;

    @Autowired
    private SupplierRepository supplierRepository;

    @Autowired
    private PartRepository partRepository;

    private Supplier supplier;


    @Before
    public void emptyDb(){
        partRepository.deleteAll();
        supplierRepository.deleteAll();

        supplier = new Supplier();
        supplier.setIsImporter(true);
        supplier.setName("Supplier");

        supplierRepository.saveAndFlush(supplier);
    }



    @Test
    @WithMockUser("spring")
    public  void  addPart_test () throws Exception {

        this.mvc
                .perform(post("/parts/add")
                        .param("name", "Part")
                        .param("price", "10")
                        .param("supplier", "Supplier")
                );
        Assert.assertEquals(1, supplierRepository.count());
    }


    @Test
    @WithMockUser("spring")
    public  void editPart_test  () throws Exception {

        Part part = new Part();
        part.setName("PartA");
        part.setPrice(new BigDecimal(10));
        part.setSupplier(supplier);

        Part testPart = partRepository.saveAndFlush(part);


        this.mvc
                .perform(post("/parts/edit/" + testPart.getId())
                        .param("name", "Part_B")
                        .param("price", "11.00")
                        .param("supplier", "Supplier")


                );



       Part actual = partRepository.findById(testPart.getId()).orElse(null);


        Assert.assertEquals("Part_B", actual.getName());
        Assert.assertEquals(new BigDecimal("11.00"), actual.getPrice());
    }


    @Test
    @WithMockUser("spring")
    public  void delete_test  () throws Exception {

        Part part = new Part();
        part.setName("PartA");
        part.setPrice(new BigDecimal(10));
        part.setSupplier(supplier);

        Part testPart = partRepository.saveAndFlush(part);


            this.mvc
                    .perform(post("/parts/delete/" + testPart.getId())
                    );


            Assert.assertEquals(0, partRepository.count());
    }



    @Test
    @WithMockUser("spring")
    public void all_returns_correct_view() throws Exception {
        mvc.perform(get("/parts/all"))
                .andExpect(view().name("all-parts"));
    }
}
