package org.softuni.cardealer.web.controllers;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.softuni.cardealer.domain.entities.Car;
import org.softuni.cardealer.domain.entities.Part;
import org.softuni.cardealer.domain.entities.Supplier;
import org.softuni.cardealer.repository.CarRepository;
import org.softuni.cardealer.repository.PartRepository;
import org.softuni.cardealer.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CarsControllerTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private SupplierRepository supplierRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private PartRepository partRepository;


    private Supplier supplier;
    private Part part;

    @Before
    public void emptyDb(){
        carRepository.deleteAll();
        partRepository.deleteAll();
        supplierRepository.deleteAll();

        supplier = new Supplier();
        part = new Part();

        supplier.setName("Supplier");
        supplier.setIsImporter(true);
        supplier = supplierRepository.saveAndFlush(supplier);


        part.setSupplier(supplier);
        part.setName("Part");
        part.setPrice(new BigDecimal(10));
        part = partRepository.saveAndFlush(part);

    }

    @Test
    @WithMockUser("spring")
    public void add_test () throws Exception {


        this.mvc.perform(post("/cars/add")
        .param("make", "CarMake")
                .param("model", "CarModel")
                .param("travelledDistance", "1")
                .param("parts", this.part.getId())
        );

        Assert.assertEquals(1, carRepository.count());
    }

    @Test
    @WithMockUser("spring")
    public void edit_test () throws Exception {

        Car newCar = new Car();
        newCar.setMake("Make");
        newCar.setModel("Model");
        newCar.setTravelledDistance(10L);
        List<Part> carParts = new ArrayList<>();
        carParts.add(part);
        newCar.setParts(carParts);

        newCar = carRepository.saveAndFlush(newCar);

        this.mvc.perform(post("/cars/edit/" + newCar.getId())
                .param("make", "Peugeot")
                .param("model", "207")
                .param("travelledDistance", "1")
                .param("parts", this.part.getId())
        );

        Car actualCar = this.carRepository.findById(newCar.getId()).orElse(null);


        Assert.assertEquals("Peugeot", actualCar.getMake());
    }

    @Test
    @WithMockUser("spring")
    public  void delete_test() throws Exception {
        Car newCar = new Car();
        newCar.setMake("Make");
        newCar.setModel("Model");
        newCar.setTravelledDistance(10L);
        List<Part> carParts = new ArrayList<>();
        carParts.add(part);
        newCar.setParts(carParts);

        newCar = carRepository.saveAndFlush(newCar);

        this.mvc.perform(post("/cars/delete/" + newCar.getId()));

        Assert.assertEquals(0L, this.carRepository.count());
    }

    @Test
    public void all_withredirectURL () throws Exception {
        mvc
                .perform(get ("/cars/all"))
                .andExpect(redirectedUrl("http://localhost/users/login"));
    }

    @Test
    @WithMockUser("spring")
    public void all_returns_correct_view() throws Exception {
        mvc.perform(get("/cars/all"))
                .andExpect(view().name("all-cars"));
    }

    @Test
    @WithMockUser("spring")
    public void all_returns_correct_attribute() throws Exception {
        mvc.perform(get("/cars/all"))
                .andExpect(view().name("all-cars"))
                .andExpect(model().attributeExists("cars"));
    }





}
