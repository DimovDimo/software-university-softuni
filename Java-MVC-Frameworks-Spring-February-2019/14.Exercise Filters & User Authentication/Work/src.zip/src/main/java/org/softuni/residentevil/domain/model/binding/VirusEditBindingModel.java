package org.softuni.residentevil.domain.model.binding;

public class VirusEditBindingModel extends VirusBindingModel {
    private String id;

    public VirusEditBindingModel() {
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }
}

