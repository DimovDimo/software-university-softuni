package org.softuni.residentevil.web.controllers;

import org.modelmapper.ModelMapper;
import org.softuni.residentevil.domain.models.view.CapitalListViewModel;
import org.softuni.residentevil.service.CapitalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/capitals")
public class CapitalController extends BaseController {


    private final CapitalService capitalService;
    private final ModelMapper modelMapper;

    @Autowired
    public CapitalController(CapitalService capitalService, ModelMapper modelMapper) {
        this.capitalService = capitalService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/delete/{id}")
    public ModelAndView delete(ModelAndView modelAndView, @PathVariable String id) {
        this.capitalService.deleteCapital(id);
        return super.redirect("/capitals/show");
    }

    @GetMapping(path = "/fetch", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public @ResponseBody
    List<CapitalListViewModel> getAllCapitals() {
        return this.capitalService.findAllCapitals()
                .stream()
                .map(c -> this.modelMapper.map(c, CapitalListViewModel.class))
                .collect(Collectors.toList());
    }
}
