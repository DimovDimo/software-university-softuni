package residentevil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResidentevilApplication {

    public static void main(String[] args) {
        SpringApplication.run(ResidentevilApplication.class, args);
    }

}
