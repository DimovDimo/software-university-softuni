package residentevil.domain.entities;

public enum Creator {
    Corp, corp;
}
