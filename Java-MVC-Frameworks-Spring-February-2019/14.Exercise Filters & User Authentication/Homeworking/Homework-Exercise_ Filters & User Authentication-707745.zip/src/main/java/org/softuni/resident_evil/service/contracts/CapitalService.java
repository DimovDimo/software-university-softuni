package org.softuni.resident_evil.service.contracts;

import org.softuni.resident_evil.domain.models.service.CapitalServiceModel;

import java.util.List;

public interface CapitalService {
    List<CapitalServiceModel> findAllCapitals();

    List<CapitalServiceModel> findAllCapitalsSortedByName();

    CapitalServiceModel findCapitalById(String id);
}
