package org.softuni.resident_evil.config;

import org.modelmapper.ModelMapper;
import org.softuni.resident_evil.util.ValidationUtilImpl;
import org.softuni.resident_evil.util.contracts.JsonParser;
import org.softuni.resident_evil.util.JsonParserImpl;
import org.softuni.resident_evil.util.contracts.ValidationUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
public class ApplicationBeanConfiguration {

    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    @Bean
    public ValidationUtils validationUtils() {
        return new ValidationUtilImpl();
    }

    @Bean
    public JsonParser jsonParser() {
        return new JsonParserImpl();
    }

    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
