package org.softuni.resident_evil.constants;

public final class VirusValidationMessages {
    public static final String INVALID_NAME_MESSAGE = "Invalid name!";
    public static final String INVALID_DESCRIPTION_MESSAGE = "Invalid description!";
    public static final String INVALID_SIDE_EFFECTS_MESSAGE = "Invalid side effects!";
    public static final String INVALID_CREATOR_MESSAGE = "Invalid creator!";
    public static final String INVALID_MUTATION_MESSAGE = "Invalid mutation!";
    public static final String INVALID_TURNOVER_MESSAGE = "Invalid turnover rate!";
    public static final String INVALID_HOURS_UNTIL_TURN_MESSAGE = "Invalid hours until turn!";
    public static final String INVALID_MAGNITUDE_MESSAGE = "Invalid magnitude!";
    public static final String INVALID_CAPITALS_MESSAGE = "No capitals were selected!";
    public static final String INVALID_RELEASE_DATE_MESSAGE = "Invalid release date!";


    private VirusValidationMessages() { }
}