package org.softuni.resident_evil.service.contracts;

import org.softuni.resident_evil.domain.models.service.UserServiceModel;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface UserService extends UserDetailsService {
    boolean registerUser(UserServiceModel userServiceModel);

    List<UserServiceModel> findAll();
}
