package org.softuni.resident_evil.service.contracts;

import org.softuni.resident_evil.domain.models.service.VirusServiceModel;

import java.util.List;

public interface VirusService {
    VirusServiceModel addVirus(VirusServiceModel virusServiceModel);

    List<VirusServiceModel> findAllViruses();

    VirusServiceModel findById(String id);

    boolean deleteById(String id);

    VirusServiceModel updateVirus(VirusServiceModel virusServiceModel);
}
