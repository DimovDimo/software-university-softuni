package org.softuni.resident_evil.util.contracts;

public interface ValidationUtils {
    <E>  boolean isValid(E object);

    <E> String getErrors(E object);
}
