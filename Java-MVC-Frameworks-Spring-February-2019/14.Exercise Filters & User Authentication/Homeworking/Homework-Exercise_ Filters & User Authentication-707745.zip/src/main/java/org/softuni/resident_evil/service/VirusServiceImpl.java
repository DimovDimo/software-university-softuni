package org.softuni.resident_evil.service;

import org.modelmapper.ModelMapper;
import org.softuni.resident_evil.domain.entites.Capital;
import org.softuni.resident_evil.domain.entites.Virus;
import org.softuni.resident_evil.domain.models.service.VirusServiceModel;
import org.softuni.resident_evil.repository.CapitalRepository;
import org.softuni.resident_evil.repository.VirusRepository;
import org.softuni.resident_evil.service.contracts.VirusService;
import org.softuni.resident_evil.util.contracts.ValidationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class VirusServiceImpl implements VirusService {
    private final VirusRepository virusRepository;
    private final CapitalRepository capitalRepository;
    private final ModelMapper mapper;
    private final ValidationUtils validationUtils;

    @Autowired
    public VirusServiceImpl(VirusRepository virusRepository, CapitalRepository capitalRepository, ModelMapper mapper, ValidationUtils validationUtils) {
        this.virusRepository = virusRepository;
        this.capitalRepository = capitalRepository;
        this.mapper = mapper;
        this.validationUtils = validationUtils;
    }

    @Override
    public VirusServiceModel addVirus(VirusServiceModel virusServiceModel) {
        if(!this.validationUtils.isValid(virusServiceModel)) {
            throw new IllegalArgumentException(this.validationUtils.getErrors(virusServiceModel));
        }

        List<Capital> capitals = virusServiceModel.getCapitals()
                .stream()
                .filter(x -> x.getId() != null)
                .map(c -> this.capitalRepository.findById(c.getId()).orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        Virus virusToSave = this.mapper.map(virusServiceModel, Virus.class);
        virusToSave.setCapitals(capitals);

        Virus virus = this.virusRepository.saveAndFlush(virusToSave);

        if(virus == null) {
            throw new IllegalArgumentException("Something went wrong");
        }


        return this.mapper.map(virus, VirusServiceModel.class);
    }

    @Override
    public List<VirusServiceModel> findAllViruses() {
        return this.virusRepository.findAll()
                .stream()
                .map(v -> this.mapper.map(v, VirusServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public VirusServiceModel findById(String id) {
        Virus virus = this.virusRepository.findById(id).orElse(null);

        if(virus == null) {
            return null;
        }

        return this.mapper.map(virus, VirusServiceModel.class);
    }

    @Override
    @Transactional
    public boolean deleteById(String id) {
        Virus virus = this.virusRepository.findById(id).orElse(null);
        if(virus == null) {
            return false;
        }

        virus.getCapitals()
                .forEach(capital -> {
                    capital.getViruses().removeIf(v -> v.getId().equals(virus.getId()));
                    this.capitalRepository.saveAndFlush(capital);
                });

        this.virusRepository.deleteById(id);

        return true;
    }

    @Override
    @Transactional
    public VirusServiceModel updateVirus(VirusServiceModel virusServiceModel) {
        Virus virus = this.virusRepository.findById(virusServiceModel.getId()).orElse(null);
        if(virus == null) {
            throw new IllegalArgumentException();
        }

        virusServiceModel.setReleasedOn(virus.getReleasedOn());

        if(!this.validationUtils.isValid(virusServiceModel)) {
            throw new IllegalArgumentException(this.validationUtils.getErrors(virusServiceModel));
        }

        List<Capital> capitals = virusServiceModel.getCapitals()
                .stream()
                .filter(x -> x.getId() != null)
                .map(x -> this.capitalRepository.findById(x.getId()).orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        virus.setName(virusServiceModel.getName());
        virus.setDescription(virusServiceModel.getDescription());
        virus.setSideEffects(virusServiceModel.getSideEffects());
        virus.setCreator(virusServiceModel.getCreator());
        virus.setCurable(virusServiceModel.isCurable());
        virus.setDeadly(virusServiceModel.isDeadly());
        virus.setMutation(virusServiceModel.getMutation());
        virus.setTurnoverRate(virusServiceModel.getTurnoverRate());
        virus.setHoursUntilTurn(virusServiceModel.getHoursUntilTurn());
        virus.setMagnitude(virusServiceModel.getMagnitude());

        virus.getCapitals()
                .forEach(capital -> {
                    capital.getViruses().removeIf(v -> v.getId().equals(virus.getId()));
                    this.capitalRepository.saveAndFlush(capital);
                });

        virus.setCapitals(capitals);

        return this.mapper.map(this.virusRepository.saveAndFlush(virus), VirusServiceModel.class);
    }
}
