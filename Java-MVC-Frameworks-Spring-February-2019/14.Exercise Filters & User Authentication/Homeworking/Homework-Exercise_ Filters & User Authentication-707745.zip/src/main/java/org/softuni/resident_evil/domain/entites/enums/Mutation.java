package org.softuni.resident_evil.domain.entites.enums;

public enum Mutation {
    ZOMBIE, T_078_TYRANT, GIANT_SPIDER
}
