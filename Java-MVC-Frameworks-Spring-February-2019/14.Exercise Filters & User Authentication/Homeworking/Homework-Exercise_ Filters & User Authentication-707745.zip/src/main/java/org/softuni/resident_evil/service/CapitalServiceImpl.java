package org.softuni.resident_evil.service;

import org.modelmapper.ModelMapper;
import org.softuni.resident_evil.domain.entites.Capital;
import org.softuni.resident_evil.domain.models.service.CapitalServiceModel;
import org.softuni.resident_evil.repository.CapitalRepository;
import org.softuni.resident_evil.service.contracts.CapitalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CapitalServiceImpl implements CapitalService {
    private final CapitalRepository capitalRepository;
    private final ModelMapper mapper;

    @Autowired
    public CapitalServiceImpl(CapitalRepository capitalRepository, ModelMapper mapper) {
        this.capitalRepository = capitalRepository;
        this.mapper = mapper;
    }

    @Override
    public List<CapitalServiceModel> findAllCapitals() {
        return this.capitalRepository.findAll()
                .stream()
                .map(x -> this.mapper.map(x, CapitalServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<CapitalServiceModel> findAllCapitalsSortedByName() {
        return this.capitalRepository.findAllByOrderByNameAsc()
                .stream()
                .map(x -> this.mapper.map(x, CapitalServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public CapitalServiceModel findCapitalById(String id) {
        Capital capital = this.capitalRepository.findById(id).orElse(null);

        if(capital == null) {
            return null;
        }

        return this.mapper.map(capital, CapitalServiceModel.class);
    }
}
