package org.softuni.resident_evil.domain.entites.enums;

public enum  VirusCreator {
    Corp, corp
}
