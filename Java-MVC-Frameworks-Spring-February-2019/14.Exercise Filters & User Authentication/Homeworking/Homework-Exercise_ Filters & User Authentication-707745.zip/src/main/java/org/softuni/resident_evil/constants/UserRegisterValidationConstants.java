package org.softuni.resident_evil.constants;

public final class UserRegisterValidationConstants {
    public static final String DEFAULT_VALIDATION_MESSAGE = "%s cannot be empty!";

    private UserRegisterValidationConstants() { }
}
