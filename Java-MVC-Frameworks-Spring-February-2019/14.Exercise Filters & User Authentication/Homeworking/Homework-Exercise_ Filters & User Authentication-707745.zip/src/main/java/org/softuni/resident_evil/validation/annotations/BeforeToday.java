package org.softuni.resident_evil.validation.annotations;

import org.softuni.resident_evil.constants.VirusValidationMessages;
import org.softuni.resident_evil.validation.validators.BeforeTodayValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Constraint(validatedBy = BeforeTodayValidator.class)
public @interface BeforeToday {

    String message() default VirusValidationMessages.INVALID_RELEASE_DATE_MESSAGE;

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
