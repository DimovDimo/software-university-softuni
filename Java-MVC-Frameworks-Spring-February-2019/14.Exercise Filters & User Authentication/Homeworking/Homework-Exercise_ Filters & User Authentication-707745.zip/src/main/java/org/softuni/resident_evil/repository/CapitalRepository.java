package org.softuni.resident_evil.repository;

import org.softuni.resident_evil.domain.entites.Capital;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CapitalRepository extends JpaRepository<Capital, String> {
    List<Capital> findAllByOrderByNameAsc();
}
