package org.softuni.resident_evil.web;

import org.modelmapper.ModelMapper;
import org.softuni.resident_evil.domain.models.view.CapitalAllViewModel;
import org.softuni.resident_evil.service.contracts.CapitalService;
import org.softuni.resident_evil.util.contracts.JsonParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController()
public class CapitalsRestController {
    private final CapitalService capitalService;
    private final JsonParser jsonParser;
    private final ModelMapper mapper;

    @Autowired
    public CapitalsRestController(CapitalService capitalService, JsonParser jsonParser, ModelMapper mapper) {
        this.capitalService = capitalService;
        this.jsonParser = jsonParser;
        this.mapper = mapper;
    }

    @GetMapping("/api/capitals/all")
    public String getAllCapitals() {
        List<CapitalAllViewModel> capitals = this.capitalService
                .findAllCapitals()
                .stream()
                .map(capital -> this.mapper.map(capital, CapitalAllViewModel.class))
                .collect(Collectors.toList());

        return this.jsonParser.toJson(capitals);
    }
}
