package org.softuni.resident_evil.web.controllers;

import org.modelmapper.ModelMapper;
import org.softuni.resident_evil.domain.models.view.VirusAllViewModel;
import org.softuni.resident_evil.service.contracts.VirusService;
import org.softuni.resident_evil.util.contracts.JsonParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
public class VirusesRestController {
    private final VirusService virusService;
    private final ModelMapper mapper;
    private final JsonParser jsonParser;

    @Autowired
    public VirusesRestController(VirusService virusService, ModelMapper mapper, JsonParser jsonParser) {
        this.virusService = virusService;
        this.mapper = mapper;
        this.jsonParser = jsonParser;
    }

    @GetMapping("/api/viruses/all")
    public String getAllViruses() {
        List<VirusAllViewModel> viruses =
                this.virusService.findAllViruses()
                .stream()
                .map(virus -> this.mapper.map(virus, VirusAllViewModel.class))
                .collect(Collectors.toList());

        return this.jsonParser.toJson(viruses);
    }
}
