package org.softuni.resident_evil.repository;

import org.softuni.resident_evil.domain.entites.Virus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VirusRepository extends JpaRepository<Virus, String> {
}