package org.softuni.resident_evil.web.controllers;

import org.softuni.resident_evil.web.controllers.base.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AuthorizationController extends BaseController {
    @GetMapping("/unauthorized")
    public ModelAndView unauthorized() {
        return super.view("unauthorized");
    }
}
