package org.softuni.resident_evil.domain.models.view;

import org.softuni.resident_evil.domain.entites.Role;

import java.util.Set;

public class UserListViewModel {
    private String id;
    private String username;
    private String email;
    private Set<Role> authorities;
    private boolean admin;
    private boolean moderator;
    private boolean user;

    public UserListViewModel() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Set<Role> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(Set<Role> authorities) {
        this.authorities = authorities;
    }

    public boolean isAdmin() {
        return this.authorities.stream().anyMatch(r -> r.getAuthority().equals("ROLE_ADMIN"));
    }

    public boolean isModerator() {
        return this.authorities.stream().anyMatch(r -> r.getAuthority().equals("ROLE_MODERATOR"));
    }

    public boolean isUser() {
        return this.authorities.stream().anyMatch(r -> r.getAuthority().equals("ROLE_USER"));
    }
}
