package org.softuni.resident_evil.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.softuni.resident_evil.util.contracts.JsonParser;

import java.time.LocalDate;


public class JsonParserImpl implements JsonParser {
    private Gson gson;

    public JsonParserImpl() {
        this.gson = new GsonBuilder()
                .excludeFieldsWithoutExposeAnnotation()
                .registerTypeAdapter(LocalDate.class, new LocalDateAdapter())
                .create();
    }

    @Override
    public <E> String toJson(E object) {
        return this.gson.toJson(object);
    }
}