package org.softuni.resident_evil.domain.models.service;

import org.softuni.resident_evil.constants.VirusValidationMessages;
import org.softuni.resident_evil.domain.entites.enums.Magnitude;
import org.softuni.resident_evil.domain.entites.enums.Mutation;
import org.softuni.resident_evil.domain.entites.enums.VirusCreator;
import org.softuni.resident_evil.validation.annotations.BeforeToday;

import javax.validation.constraints.*;
import java.time.LocalDate;
import java.util.List;

public class VirusServiceModel {
    private String id;
    private String name;
    private String description;
    private String sideEffects;
    private VirusCreator creator;
    private boolean isDeadly;
    private boolean isCurable;
    private Mutation mutation;
    private int turnoverRate;
    private int hoursUntilTurn;
    private Magnitude magnitude;
    private LocalDate releasedOn;
    private List<CapitalServiceModel> capitals;

    public VirusServiceModel() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @NotNull
    @Size(min = 3, max = 10, message = VirusValidationMessages.INVALID_NAME_MESSAGE)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotNull
    @Size(min = 5, max = 100, message = VirusValidationMessages.INVALID_DESCRIPTION_MESSAGE)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @NotNull
    @Size(max = 50, message = VirusValidationMessages.INVALID_SIDE_EFFECTS_MESSAGE)
    public String getSideEffects() {
        return sideEffects;
    }

    public void setSideEffects(String sideEffects) {
        this.sideEffects = sideEffects;
    }

    @NotNull(message = VirusValidationMessages.INVALID_CREATOR_MESSAGE)
    public VirusCreator getCreator() {
        return creator;
    }

    public void setCreator(VirusCreator creator) {
        this.creator = creator;
    }

    public boolean isDeadly() {
        return isDeadly;
    }

    public void setDeadly(boolean deadly) {
        isDeadly = deadly;
    }

    public boolean isCurable() {
        return isCurable;
    }

    public void setCurable(boolean curable) {
        isCurable = curable;
    }

    @NotNull(message = VirusValidationMessages.INVALID_MUTATION_MESSAGE)
    public Mutation getMutation() {
        return mutation;
    }

    public void setMutation(Mutation mutation) {
        this.mutation = mutation;
    }

    @Min(value = 0, message = VirusValidationMessages.INVALID_TURNOVER_MESSAGE)
    @Max(value = 50, message = VirusValidationMessages.INVALID_TURNOVER_MESSAGE)
    public int getTurnoverRate() {
        return turnoverRate;
    }

    public void setTurnoverRate(int turnoverRate) {
        this.turnoverRate = turnoverRate;
    }

    @Min(value = 1, message = VirusValidationMessages.INVALID_HOURS_UNTIL_TURN_MESSAGE)
    @Max(value = 12, message = VirusValidationMessages.INVALID_HOURS_UNTIL_TURN_MESSAGE)
    public int getHoursUntilTurn() {
        return hoursUntilTurn;
    }

    public void setHoursUntilTurn(int hoursUntilTurn) {
        this.hoursUntilTurn = hoursUntilTurn;
    }

    @NotNull(message = VirusValidationMessages.INVALID_MAGNITUDE_MESSAGE)
    public Magnitude getMagnitude() {
        return magnitude;
    }

    public void setMagnitude(Magnitude magnitude) {
        this.magnitude = magnitude;
    }

    @BeforeToday
    public LocalDate getReleasedOn() {
        return releasedOn;
    }

    public void setReleasedOn(LocalDate releasedOn) {
        this.releasedOn = releasedOn;
    }

    @NotEmpty(message = VirusValidationMessages.INVALID_CAPITALS_MESSAGE)
    public List<CapitalServiceModel> getCapitals() {
        return capitals;
    }

    public void setCapitals(List<CapitalServiceModel> capitals) {
        this.capitals = capitals;
    }
}
