package org.softuni.resident_evil.web.controllers;

import org.modelmapper.ModelMapper;
import org.softuni.resident_evil.domain.models.binding.UserRegisterBindingModel;
import org.softuni.resident_evil.domain.models.service.UserServiceModel;
import org.softuni.resident_evil.domain.models.view.UserListViewModel;
import org.softuni.resident_evil.service.contracts.UserService;
import org.softuni.resident_evil.web.controllers.base.BaseController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class UserController extends BaseController {
    private final UserService userService;
    private final ModelMapper mapper;

    @Autowired
    public UserController(UserService userService, ModelMapper mapper) {
        this.userService = userService;
        this.mapper = mapper;
    }


    @GetMapping("/register")
    @PreAuthorize("isAnonymous()")
    public ModelAndView register(@ModelAttribute(name = "bindingModel")UserRegisterBindingModel userRegisterBindingModel) {
        return super.view("register");
    }

    @PostMapping("/register")
    public ModelAndView registerConfirm(ModelAndView modelAndView, @Valid @ModelAttribute(name = "bindingModel")UserRegisterBindingModel userRegisterBindingModel, BindingResult bindingResult) {
        if(bindingResult.hasErrors()) {
            modelAndView.addObject("bindingModel", userRegisterBindingModel);
            return super.view("register", modelAndView);
        }

        boolean isRegistered = this.userService.registerUser(this.mapper.map(userRegisterBindingModel, UserServiceModel.class));

        if(!userRegisterBindingModel.getPassword().equals(userRegisterBindingModel.getConfirmPassword())) {
            throw new IllegalArgumentException("Both passwords should match");
        }

        if(!isRegistered) {
            throw new IllegalArgumentException("Something went wrong!");
        }

        return super.redirect("/login");
    }

    @GetMapping("/login")
    @PreAuthorize("isAnonymous()")
    public ModelAndView login() {
        return super.view("login");
    }

    @GetMapping("/users")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ModelAndView users(ModelAndView modelAndView) {
        List<UserListViewModel> users = this.userService.findAll()
                .stream()
                .map(u -> this.mapper.map(u, UserListViewModel.class))
                .collect(Collectors.toList());

        modelAndView.addObject("users", users);
        

        return super.view("users", modelAndView);
    }
}
