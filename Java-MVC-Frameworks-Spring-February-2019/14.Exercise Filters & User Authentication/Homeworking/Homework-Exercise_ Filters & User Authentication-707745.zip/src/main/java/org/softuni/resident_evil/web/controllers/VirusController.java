package org.softuni.resident_evil.web.controllers;

import org.modelmapper.ModelMapper;
import org.softuni.resident_evil.domain.models.binding.VirusAddBindingModel;
import org.softuni.resident_evil.domain.models.binding.VirusEditBindingModel;
import org.softuni.resident_evil.domain.models.service.CapitalServiceModel;
import org.softuni.resident_evil.domain.models.service.VirusServiceModel;
import org.softuni.resident_evil.domain.models.view.CapitalSelectViewModel;
import org.softuni.resident_evil.domain.models.view.VirusDeleteViewModel;
import org.softuni.resident_evil.service.contracts.CapitalService;
import org.softuni.resident_evil.service.contracts.VirusService;
import org.softuni.resident_evil.web.controllers.base.BaseController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/viruses")
public class VirusController extends BaseController {
    private final VirusService virusService;
    private final CapitalService capitalService;
    private final ModelMapper mapper;

    @Autowired
    public VirusController(VirusService virusService, CapitalService capitalService, ModelMapper mapper) {
        this.virusService = virusService;
        this.capitalService = capitalService;
        this.mapper = mapper;
    }

    @GetMapping("")
    public ModelAndView all() {
        return super.view("all-viruses");
    }

    @GetMapping("/add")
    public ModelAndView add(ModelAndView modelAndView, @ModelAttribute(name = "bindingModel") VirusAddBindingModel bindingModel) {
        this.setAddFormAttributes(modelAndView, bindingModel);
        return super.view("add-virus", modelAndView);
    }

    @PostMapping("/add")
    public ModelAndView addConfirm(@Valid @ModelAttribute(name = "bindingModel") VirusAddBindingModel bindingModel, BindingResult bindingResult, ModelAndView modelAndView) {
        if(bindingResult.hasErrors()) {
            this.setAddFormAttributes(modelAndView, bindingModel);
            return super.view("add-virus", modelAndView);
        }

        try {
            VirusServiceModel virusServiceModel = this.mapper.map(bindingModel, VirusServiceModel.class);
            bindingModel.getCapitals()
                    .forEach(capitalId -> {
                        CapitalServiceModel capital = this.capitalService.findCapitalById(capitalId);
                        if(capital != null) {
                            virusServiceModel.getCapitals().add(this.mapper.map(capital, CapitalServiceModel.class));
                        }
                    });

            VirusServiceModel savedVirus = this.virusService.addVirus(virusServiceModel);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return super.redirect("/");
    }

    @GetMapping("/delete")
    public ModelAndView deleteVirus(@RequestParam(name = "id") String id, ModelAndView modelAndView) {
        VirusServiceModel virusFromDb = this.virusService.findById(id);

        if(virusFromDb == null) {
            return super.redirect("/");
        }

        VirusDeleteViewModel virusDeleteViewModel = this.mapper.map(virusFromDb, VirusDeleteViewModel.class);
        virusDeleteViewModel.setCapitals(virusFromDb.getCapitals().stream().map(CapitalServiceModel::getName).collect(Collectors.toList()));
        modelAndView.addObject("bindingModel", virusDeleteViewModel);

        return super.view("delete-virus", modelAndView);
    }

    @PostMapping("/delete")
    public ModelAndView deleteVirusConfirm(@RequestParam(name = "id") String id) {
        this.virusService.deleteById(id);
        return super.redirect("/");
    }


    @GetMapping("/edit")
    public ModelAndView editVirus(@RequestParam(name = "id") String id, ModelAndView modelAndView, @ModelAttribute(name = "bindingModel") VirusEditBindingModel bindingModel) {
        VirusServiceModel virusFromDb = this.virusService.findById(id);

        if(virusFromDb == null) {
            return super.redirect("/");
        }

        bindingModel = this.mapper.map(virusFromDb, VirusEditBindingModel.class);
        bindingModel.setCapitals(virusFromDb.getCapitals().stream().map(CapitalServiceModel::getId).collect(Collectors.toList()));

        modelAndView.addObject("bindingModel", bindingModel);
        modelAndView.addObject("capitals", this.getCapitalsForFormDisplay());

        return super.view("edit-virus", modelAndView);
    }

    @PostMapping("/edit")
    public ModelAndView editVirusConfirm(@RequestParam(name = "id") String id, ModelAndView modelAndView, @Valid @ModelAttribute(name = "bindingModel") VirusEditBindingModel bindingModel, BindingResult bindingResult) {
        if(bindingResult.hasErrors()) {
            modelAndView.addObject("bindingModel", bindingModel);
            modelAndView.addObject("capitals", this.getCapitalsForFormDisplay());
            return super.view("edit-virus", modelAndView);
        }

        VirusServiceModel virusServiceModel = this.mapper.map(bindingModel, VirusServiceModel.class);
        bindingModel.getCapitals()
                .forEach(capitalId -> {
                    CapitalServiceModel capital = this.capitalService.findCapitalById(capitalId);
                    if(capital.getId() != null) {
                        virusServiceModel.getCapitals().add(this.mapper.map(capital, CapitalServiceModel.class));
                    }
                });
        this.virusService.updateVirus(virusServiceModel);

        return super.redirect("/");
    }

//    @InitBinder
//    public void initBinder(WebDataBinder binder) {
//        binder.registerCustomEditor(LocalDate.class, new PropertyEditorSupport() {
//            @Override
//            public void setAsText(String text) throws IllegalArgumentException{
//                setValue(LocalDate.parse(text, DateTimeFormatter.ofPattern("yyyy-MM-dd")));
//            }
//
//            @Override
//            public String getAsText() throws IllegalArgumentException {
//                return DateTimeFormatter.ofPattern("yyyy-MM-dd").format((LocalDate) getValue());
//            }
//        });
//    }

    private void setAddFormAttributes(ModelAndView modelAndView, VirusAddBindingModel bindingModel) {
        modelAndView.addObject("bindingModel", bindingModel);

//        Mutation[] mutations = Mutation.values();
//        modelAndView.addObject("mutations", mutations);
//
//        Magnitude[] magnitudes = Magnitude.values();
//        modelAndView.addObject("magnitudes", magnitudes);

        List<CapitalSelectViewModel> capitals = this.getCapitalsForFormDisplay();
        modelAndView.addObject("capitals", capitals);
    }

    private List<CapitalSelectViewModel> getCapitalsForFormDisplay() {
        return this.capitalService.findAllCapitalsSortedByName()
                .stream()
                .map(x -> this.mapper.map(x, CapitalSelectViewModel.class))
                .collect(Collectors.toList());
    }
}
