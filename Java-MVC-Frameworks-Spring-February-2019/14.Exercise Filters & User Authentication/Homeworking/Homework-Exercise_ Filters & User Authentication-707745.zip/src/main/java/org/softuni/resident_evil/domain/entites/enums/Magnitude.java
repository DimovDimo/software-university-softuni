package org.softuni.resident_evil.domain.entites.enums;

public enum Magnitude {
    Low, High, Medium
}
