package org.softuni.resident_evil.util.contracts;

public interface JsonParser {
    <E> String toJson(E object);
}