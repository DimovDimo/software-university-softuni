const domUtil = (function () {
    const createElement = elementType => $(elementType);

    const appendElement = (element, parent) => element.appendTo(parent);

    const selectElementFromDom = selector => $(selector);

    const addEventListener = (element, eventType, func) => element.on(eventType, func);

    const append = (element, elementsToAppend) => element.append(elementsToAppend);

    const setText = (element, text) => element.text(text);

    const removeElementFromDom = element => element.remove();

    const uncheck = radioButton => radioButton.prop('checked', false);

    const setAttribute = (element, attrName, attrValue) => element.attr(attrName, attrValue);

    const setValue = (element, value) => element.val(value);

    return {
        createElement,
        appendElement,
        selectElementFromDom,
        addEventListener,
        append,
        setText,
        removeElementFromDom,
        uncheck,
        setAttribute,
        setValue
    }
})();