$(() => {
    const url = window.location.href;
    const form = domUtil.selectElementFromDom('form');
    const submitBtn = domUtil.selectElementFromDom('#submitBtn');
    const submitBtnValue = getSubmitBtnValue(url);
    const releaseDateContainer = domUtil.createElement('');
    const capitalsContainer = domUtil.selectElementFromDom('#capitalsContainer');

    domUtil.setAttribute(form,'action', url);
    domUtil.setValue(submitBtn, submitBtnValue);

    if(url.includes('delete')) {
        console.log(capitalsContainer.html());
        disableInputs();
        domUtil.setAttribute(submitBtn, 'disabled', false);
    }
});

const getSubmitBtnValue = (url) => {
  if(url.includes('delete')) {
      return 'Delete Virus';
  } else if(url.includes('edit')) {
      return 'Edit Virus'
  } else {
      return 'Spread virus';
  }
};

const disableInputs = () => {
    const inputs = domUtil.selectElementFromDom('input, textarea, select');
    domUtil.setAttribute(inputs, 'disabled', true);
};