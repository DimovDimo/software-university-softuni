const capitalService = (function () {
    const getAllCapitals = () => http.doGet('/api/capitals/all');

    return {
        getAllCapitals
    }
})();