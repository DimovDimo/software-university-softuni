const virusService = (function () {
    const getAllViruses = () => http.doGet('/api/viruses/all');

    return {
        getAllViruses
    }
})();