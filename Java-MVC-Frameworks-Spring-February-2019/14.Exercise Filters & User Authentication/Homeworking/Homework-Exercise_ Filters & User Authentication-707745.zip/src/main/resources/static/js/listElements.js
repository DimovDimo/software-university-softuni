const mainContainer = domUtil.selectElementFromDom('.container');
const heading = domUtil.selectElementFromDom('#choiceHeading');
const headingToBeRemovedAfterSelection = domUtil.selectElementFromDom('#nonSelectedItemHeading');
const capitalRadioButton = domUtil.selectElementFromDom('#capitalRadioButton');
const virusesRadioButton = domUtil.selectElementFromDom('#virusRadioButton');

$(() => {
    domUtil.addEventListener(capitalRadioButton, 'change', renderCapitals);
    domUtil.addEventListener(virusesRadioButton, 'change', renderViruses);
});

const renderCapitals = async () => {
    clearTable();
    domUtil.uncheck(virusesRadioButton);
    const capitals = await capitalService.getAllCapitals();
    const capitalsTable = domUtil.createElement('<table class="table">');

    renderTable('<thead><tr><th>#</th><th>Name</th><th>Latitude</th><th>Longitude</th></tr></thead>',
        capitals.map((capital, index) => `<tr><th>${index + 1}</th><th>${capital.name}</th><th>${capital.latitude}</th><th>${capital.longitude}</th></tr>`),
        'Capitals');
};

const renderTable = (thead, rows, headingText) => {
    const table = domUtil.createElement('<table class="table">');
    domUtil.append(table, thead);
    domUtil.append(table, rows);
    domUtil.appendElement(table, mainContainer);
    domUtil.setText(heading, headingText);
    domUtil.removeElementFromDom(headingToBeRemovedAfterSelection);
};

const renderViruses = async () => {
    clearTable();
    domUtil.uncheck(capitalRadioButton);
    const viruses = await virusService.getAllViruses();
    const thead = '<thead>' +
            '<th scope="col">#</th>' +
            '<th scope="col">Name</th>' +
            '<th scope="col">Magnitude</th>' +
            '<th scope="col">Released on</th>' +
            '<th scope="col">Actions</th>' +
        '</thead>';

    const rows = viruses.map((virus, index) => `<tr><td>${index + 1}</td><td>${virus.name}</td><td>${virus.magnitude}</td><td>${virus.releasedOn}</td><td><a class="btn btn-light mr-2" href="/viruses/edit?id=${virus.id}">Edit</a><a class="btn btn-light" href="/viruses/delete?id=${virus.id}">Delete</a></td></tr>`);
    renderTable(thead, rows, 'Viruses');
};

const clearTable = () => {
    const table = domUtil.selectElementFromDom('table');

    if(table.length > 0) {
        domUtil.removeElementFromDom(table);
    }
};