package residentevil.domain.enums;

public enum Magnitude {
    Low,
    Medium,
    High
}
