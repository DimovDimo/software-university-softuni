package residentevil.domain.enums;

public enum Creator {
    Corp,
    corp
}
