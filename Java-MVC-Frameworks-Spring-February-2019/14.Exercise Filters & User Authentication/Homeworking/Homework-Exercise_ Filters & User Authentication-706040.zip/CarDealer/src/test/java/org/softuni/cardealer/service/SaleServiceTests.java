package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.models.service.*;
import org.softuni.cardealer.repository.CarSaleRepository;
import org.softuni.cardealer.repository.PartSaleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.ArrayList;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class SaleServiceTests {

    @Autowired
    private CarSaleRepository carSaleRepository;
    @Autowired
    private PartSaleRepository partSaleRepository;

    private ModelMapper modelMapper;

    @Before
    public void init() {
        this.modelMapper = new ModelMapper();
    }

    @Test
    public void saleService_saleCarWithCorrectValues_returnsCorrect() {
        SaleService saleService
                = new SaleServiceImpl(this.carSaleRepository, this.partSaleRepository, this.modelMapper);

        CarServiceModel carServiceModel = new CarServiceModel();
        carServiceModel.setMake("Make");
        carServiceModel.setModel("Model");
        carServiceModel.setTravelledDistance(100L);
        carServiceModel.setParts(new ArrayList<>());

        CarSaleServiceModel toBeSold = new CarSaleServiceModel();
        toBeSold.setCar(carServiceModel);
        toBeSold.setDiscount(0D);

        CarSaleServiceModel actual = saleService.saleCar(toBeSold);
        CarSaleServiceModel expected = this.modelMapper
                .map(this.carSaleRepository.findAll().get(0), CarSaleServiceModel.class);

        Assert.assertEquals(expected.getCar().getMake(), actual.getCar().getMake());
        Assert.assertEquals(expected.getCar().getModel(), actual.getCar().getModel());
        Assert.assertEquals(expected.getCar().getTravelledDistance(), actual.getCar().getTravelledDistance());
    }

    @Test(expected = Exception.class)
    public void saleService_saleCarWithNullMakeValue_throwsException() {
        SaleService saleService
                = new SaleServiceImpl(this.carSaleRepository, this.partSaleRepository, this.modelMapper);

        CarServiceModel carServiceModel = new CarServiceModel();
        carServiceModel.setMake(null);
        carServiceModel.setModel("Model");
        carServiceModel.setTravelledDistance(100L);
        carServiceModel.setParts(new ArrayList<>());

        CarSaleServiceModel toBeSold = new CarSaleServiceModel();
        toBeSold.setCar(carServiceModel);
        toBeSold.setDiscount(0D);

        CarSaleServiceModel actual = saleService.saleCar(toBeSold);
    }

    @Test(expected = Exception.class)
    public void saleService_saleCarWithNullDiscountValue_throwsException() {
        SaleService saleService
                = new SaleServiceImpl(this.carSaleRepository, this.partSaleRepository, this.modelMapper);

        CarSaleServiceModel toBeSold = new CarSaleServiceModel();
        toBeSold.setCar(null);

        CarSaleServiceModel actual = saleService.saleCar(toBeSold);
    }

    @Test
    public void saleService_salePartWithCorrectValues_returnsCorrect() {
        SaleService saleService
                = new SaleServiceImpl(this.carSaleRepository, this.partSaleRepository, this.modelMapper);

        PartServiceModel partServiceModel = new PartServiceModel();
        partServiceModel.setName("Part");
        partServiceModel.setPrice(BigDecimal.ONE);

        PartSaleServiceModel toBeSold = new PartSaleServiceModel();
        toBeSold.setPart(partServiceModel);
        toBeSold.setQuantity(10);
        toBeSold.setDiscount(0D);

        PartSaleServiceModel actual = saleService.salePart(toBeSold);
        PartSaleServiceModel expected = this.modelMapper
                .map(this.partSaleRepository.findAll().get(0), PartSaleServiceModel.class);

        Assert.assertEquals(expected.getDiscount(), actual.getDiscount());
        Assert.assertEquals(expected.getPart().getName(), actual.getPart().getName());
        Assert.assertEquals(expected.getQuantity(), actual.getQuantity());
    }

    @Test(expected = Exception.class)
    public void saleService_salePartWithNullPartValue_throwsException() {
        SaleService saleService
                = new SaleServiceImpl(this.carSaleRepository, this.partSaleRepository, this.modelMapper);

        PartServiceModel partServiceModel = new PartServiceModel();
        partServiceModel.setName(null);
        partServiceModel.setPrice(BigDecimal.ONE);

        PartSaleServiceModel toBeSold = new PartSaleServiceModel();
        toBeSold.setPart(partServiceModel);
        toBeSold.setQuantity(10);
        toBeSold.setDiscount(0D);

        saleService.salePart(toBeSold);
    }

    @Test(expected = Exception.class)
    public void saleService_salePartWithNullDiscountValue_throwsException() {
        SaleService saleService
                = new SaleServiceImpl(this.carSaleRepository, this.partSaleRepository, this.modelMapper);

        PartServiceModel partServiceModel = new PartServiceModel();
        partServiceModel.setName("Part");
        partServiceModel.setPrice(BigDecimal.ONE);

        PartSaleServiceModel toBeSold = new PartSaleServiceModel();
        toBeSold.setPart(partServiceModel);
        toBeSold.setQuantity(10);
        toBeSold.setDiscount(null);

        saleService.salePart(toBeSold);
    }

    @Test(expected = Exception.class)
    public void saleService_salePartWithNullPartServiceModelValue_throwsException() {
        SaleService saleService
                = new SaleServiceImpl(this.carSaleRepository, this.partSaleRepository, this.modelMapper);

        PartSaleServiceModel toBeSold = new PartSaleServiceModel();
        toBeSold.setPart(null);

        saleService.salePart(toBeSold);
    }
}
