package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.entities.Customer;
import org.softuni.cardealer.domain.models.service.CustomerServiceModel;
import org.softuni.cardealer.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CustomerServiceTests {

    private CustomerService customerService;

    @Autowired
    private CustomerRepository customerRepository;
    private ModelMapper modelMapper;

    @Before
    public void init() {
        this.modelMapper = new ModelMapper();
        this.customerService
                = new CustomerServiceImpl(this.customerRepository, this.modelMapper);
    }

    private Customer initCustomer() {
        Customer customer = new Customer();
        customer.setName("Pesho");
        customer.setBirthDate(LocalDate.now());
        customer.setYoungDriver(true);
        return customer;
    }

    private CustomerServiceModel initCustomerServiceModel(String id, String name, boolean isYougDriver) {
        CustomerServiceModel customer = new CustomerServiceModel();
        customer.setId(id);
        customer.setName(name);
        customer.setBirthDate(LocalDate.now());
        customer.setYoungDriver(isYougDriver);
        return customer;
    }

    private void propertiesAssert(CustomerServiceModel expected, CustomerServiceModel actual) {
        Assert.assertEquals(expected.getName(), actual.getName());
        Assert.assertEquals(expected.getBirthDate(), actual.getBirthDate());
        Assert.assertEquals(expected.isYoungDriver(), actual.isYoungDriver());
    }

    @Test
    public void customerService_saveCustomerWithCorrectValues_returnsCorrect() {
        CustomerServiceModel toBeAdded = initCustomerServiceModel(null, "Pesho", true);

        CustomerServiceModel actual = customerService.saveCustomer(toBeAdded);
        CustomerServiceModel expected = this.modelMapper
                .map(this.customerRepository.findAll().get(0), CustomerServiceModel.class);

        propertiesAssert(expected, actual);
    }

    @Test(expected = Exception.class)
    public void customerService_saveCustomerWithNullValues_throwsException() {
        CustomerServiceModel toBeAdded = initCustomerServiceModel(null, null, true);

        customerService.saveCustomer(toBeAdded);
    }

    @Test
    public void customerService_editCustomerWithCorrectValues_returnsCorrect() {
        Customer customer = initCustomer();

        customer = this.customerRepository.saveAndFlush(customer);

        CustomerServiceModel toBeAdded
                = initCustomerServiceModel(customer.getId(), "Gosho", false);

        CustomerServiceModel actual = customerService.editCustomer(toBeAdded);
        CustomerServiceModel expected = this.modelMapper
                .map(this.customerRepository.findAll().get(0), CustomerServiceModel.class);

        propertiesAssert(expected, actual);
    }

    @Test(expected = Exception.class)
    public void customerService_editCustomerWithNullValues_throwsException() {
        Customer customer = initCustomer();

        customer = this.customerRepository.saveAndFlush(customer);

        CustomerServiceModel toBeAdded = new CustomerServiceModel();
        toBeAdded.setId(customer.getId());
        toBeAdded.setName(null);

        customerService.editCustomer(toBeAdded);
    }

    @Test
    public void customerService_deleteCustomerWithCorrectId_returnsCorrect() {
        Customer customer = initCustomer();

        customer = this.customerRepository.saveAndFlush(customer);

        customerService.deleteCustomer(customer.getId());

        long expected = 0;
        long actual = this.customerRepository.count();

        Assert.assertEquals(expected, actual);
    }

    @Test(expected = Exception.class)
    public void customerService_deleteCustomerWithIncorrectId_throwsException() {
        Customer customer = initCustomer();

        this.customerRepository.saveAndFlush(customer);

        customerService.deleteCustomer("MockedId");
    }

    @Test
    public void customerService_findCustomerByCorrectId_returnsCorrect() {
        Customer customer = initCustomer();

        customer = this.customerRepository.saveAndFlush(customer);

        CustomerServiceModel actual = customerService.findCustomerById(customer.getId());
        CustomerServiceModel expected = this.modelMapper.map(customer, CustomerServiceModel.class);

        propertiesAssert(expected, actual);
    }

    @Test(expected = Exception.class)
    public void customerService_findCustomerByIncorrectId_throwsException() {
        Customer customer = initCustomer();

        this.customerRepository.saveAndFlush(customer);

        customerService.findCustomerById("MockedId");
    }
}
