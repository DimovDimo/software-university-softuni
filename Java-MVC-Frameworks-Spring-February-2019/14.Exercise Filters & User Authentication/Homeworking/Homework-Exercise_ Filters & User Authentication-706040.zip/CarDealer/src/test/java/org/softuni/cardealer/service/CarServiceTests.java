package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.entities.Car;
import org.softuni.cardealer.domain.models.service.CarServiceModel;
import org.softuni.cardealer.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CarServiceTests {

    private CarService carService;

    @Autowired
    private CarRepository carRepository;

    private ModelMapper modelMapper;

    @Before
    public void init() {
        this.modelMapper = new ModelMapper();
        this.carService = new CarServiceImpl(this.carRepository, this.modelMapper);
    }

    private CarServiceModel initCarServiceModel(String id, String model, long travelledDistance) {
        CarServiceModel car = new CarServiceModel();
        car.setId(id);
        car.setMake("Make");
        car.setModel(model);
        car.setTravelledDistance(travelledDistance);
        car.setParts(new ArrayList<>());
        return car;
    }

    private Car initCar() {
        Car car = new Car();
        car.setMake("Make");
        car.setModel("Model");
        car.setTravelledDistance(100L);
        car.setParts(new ArrayList<>());
        return car;
    }

    private void propertiesAssert(CarServiceModel expected, CarServiceModel actual) {
        Assert.assertEquals(expected.getId(), actual.getId());
        Assert.assertEquals(expected.getMake(), actual.getMake());
        Assert.assertEquals(expected.getModel(), actual.getModel());
        Assert.assertEquals(expected.getTravelledDistance(), actual.getTravelledDistance());
    }

    @Test
    public void carService_saveCarWithCorrectValues_returnsCorrect() {
        CarServiceModel toBeAdded = initCarServiceModel(null,"Model", 100L);

        CarServiceModel actual = carService.saveCar(toBeAdded);
        CarServiceModel expected = this.modelMapper
                .map(this.carRepository.findAll().get(0), CarServiceModel.class);

        propertiesAssert(expected, actual);
    }

    @Test(expected = Exception.class)
    public void carService_saveCarWithNullValues_throwsException() {
        CarServiceModel toBeAdded = initCarServiceModel(null, null, 100L);

        carService.saveCar(toBeAdded);
    }

    @Test
    public void carService_editCarWithCorrectValues_returnsCorrect() {
        Car car = initCar();

        car = this.carRepository.saveAndFlush(car);

        CarServiceModel toBeEdited
                = initCarServiceModel(car.getId(), "Model_new", 101L);

        CarServiceModel actual = carService.editCar(toBeEdited);
        CarServiceModel expected = this.modelMapper
                .map(this.carRepository.findAll().get(0), CarServiceModel.class);

        propertiesAssert(expected, actual);
    }

    @Test(expected = Exception.class)
    public void carService_editCarWithNullValues_throwsException() {
        Car car = initCar();

        car = this.carRepository.saveAndFlush(car);

        CarServiceModel toBeEdited
                = initCarServiceModel(car.getId(), null, 100L);

        carService.editCar(toBeEdited);
    }

    @Test
    public void carService_deleteCarWithCorrectValues_returnsCorrect() {
        Car car = initCar();

        car = this.carRepository.saveAndFlush(car);

        carService.deleteCar(car.getId());

        long expected = 0;
        long actual = this.carRepository.count();

        Assert.assertEquals(expected, actual);
    }

    @Test(expected = Exception.class)
    public void carService_deleteCarWithNullValues_throwsException() {
        Car car = initCar();

        this.carRepository.saveAndFlush(car);

        carService.deleteCar("MockedId");
    }

    @Test
    public void carService_findByIdCarWithValidId_returnsCorrect() {
        Car car = initCar();

        car = this.carRepository.saveAndFlush(car);

        CarServiceModel actual = carService.findCarById(car.getId());
        CarServiceModel expected = this.modelMapper.map(car, CarServiceModel.class);

        propertiesAssert(expected, actual);
    }

    @Test(expected = Exception.class)
    public void carService_findByIdCarWithInvalidId_throwsException() {
        Car car = initCar();

        this.carRepository.saveAndFlush(car);

        carService.findCarById("Mocked");
    }
}
