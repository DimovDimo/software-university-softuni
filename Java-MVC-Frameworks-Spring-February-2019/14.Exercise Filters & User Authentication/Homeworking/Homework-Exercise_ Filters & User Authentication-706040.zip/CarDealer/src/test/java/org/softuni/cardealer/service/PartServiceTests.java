package org.softuni.cardealer.service;

import org.h2.jdbc.JdbcSQLIntegrityConstraintViolationException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.entities.Part;
import org.softuni.cardealer.domain.entities.Supplier;
import org.softuni.cardealer.domain.models.service.PartServiceModel;
import org.softuni.cardealer.domain.models.service.SupplierServiceModel;
import org.softuni.cardealer.repository.PartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.validation.ConstraintViolationException;
import java.math.BigDecimal;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class PartServiceTests {

    @Autowired
    private PartRepository partRepository;

    private ModelMapper modelMapper;

    @Before
    public void init() {
        this.modelMapper = new ModelMapper();
    }

    @Test
    public void partService_savePartWithCorrectValues_returnsCorrect() {
        PartService partService
                = new PartServiceImpl(this.partRepository, this.modelMapper);

        SupplierServiceModel supplier = new SupplierServiceModel();
        supplier.setName("Supplier");
        supplier.setImporter(true);

        PartServiceModel toBeAdded = new PartServiceModel();
        toBeAdded.setName("Part");
        toBeAdded.setPrice(BigDecimal.ONE);
        toBeAdded.setSupplier(supplier);

        PartServiceModel actual = partService.savePart(toBeAdded);
        PartServiceModel expected =
                this.modelMapper.map(this.partRepository.findAll().get(0), PartServiceModel.class);

        Assert.assertEquals(expected.getId(), actual.getId());
        Assert.assertEquals(expected.getName(), actual.getName());
        Assert.assertEquals(expected.getPrice(), actual.getPrice());
    }

    @Test(expected = Exception.class)
    public void partService_savePartWithNullValues_throwsException() {
        PartService partService
                = new PartServiceImpl(this.partRepository, this.modelMapper);

        SupplierServiceModel supplier = new SupplierServiceModel();
        supplier.setName("Supplier");
        supplier.setImporter(true);

        PartServiceModel toBeAdded = new PartServiceModel();
        toBeAdded.setName(null);
        toBeAdded.setPrice(BigDecimal.ONE);
        toBeAdded.setSupplier(supplier);

        partService.savePart(toBeAdded);
    }

    @Test
    public void partService_editPartWithCorrectValues_returnsCorrect() {
        PartService partService
                = new PartServiceImpl(this.partRepository, this.modelMapper);

        Supplier supplier = new Supplier();
        supplier.setName("Supplier");
        supplier.setImporter(true);

        Part part = new Part();
        part.setName("Part");
        part.setPrice(BigDecimal.ONE);
        part.setSupplier(supplier);

        part = this.partRepository.saveAndFlush(part);

        PartServiceModel toBeEdited = new PartServiceModel();
        toBeEdited.setId(part.getId());
        toBeEdited.setName("Part_new");
        toBeEdited.setPrice(BigDecimal.TEN);
        toBeEdited.setSupplier(this.modelMapper.map(supplier, SupplierServiceModel.class));

        PartServiceModel actual = partService.editPart(toBeEdited);
        PartServiceModel expected = this.modelMapper
                .map(this.partRepository.findAll().get(0), PartServiceModel.class);

        Assert.assertEquals(expected.getId(), actual.getId());
        Assert.assertEquals(expected.getName(), actual.getName());
        Assert.assertEquals(expected.getPrice(), actual.getPrice());
    }

    @Test(expected = Exception.class)
    public void partService_editPartWithNullValues_throwsException() {
        PartService partService
                = new PartServiceImpl(this.partRepository, this.modelMapper);

        Supplier supplier = new Supplier();
        supplier.setName("Supplier");
        supplier.setImporter(true);

        Part part = new Part();
        part.setName("Part");
        part.setPrice(BigDecimal.ONE);
        part.setSupplier(supplier);

        part = this.partRepository.saveAndFlush(part);

        PartServiceModel toBeEdited = new PartServiceModel();
        toBeEdited.setId(part.getId());
        toBeEdited.setName("Part_new");
        toBeEdited.setPrice(null);
        toBeEdited.setSupplier(this.modelMapper.map(supplier, SupplierServiceModel.class));

        partService.editPart(toBeEdited);
    }

    @Test
    public void partService_deletePartWithValidId_returnsCorrect() {
        PartService partService
                = new PartServiceImpl(this.partRepository, this.modelMapper);

        Supplier supplier = new Supplier();
        supplier.setName("Supplier");
        supplier.setImporter(true);

        Part part = new Part();
        part.setName("Part");
        part.setPrice(BigDecimal.ONE);
        part.setSupplier(supplier);

        part = this.partRepository.saveAndFlush(part);

        partService.deletePart(part.getId());

        long expected = 0;
        long actual = this.partRepository.count();

        Assert.assertEquals(expected, actual);
    }

    @Test(expected = Exception.class)
    public void partService_deletePartWithInvalidId_throwsException() {
        PartService partService
                = new PartServiceImpl(this.partRepository, this.modelMapper);

        Supplier supplier = new Supplier();
        supplier.setName("Supplier");
        supplier.setImporter(true);

        Part part = new Part();
        part.setName("Part");
        part.setPrice(BigDecimal.ONE);
        part.setSupplier(supplier);

        part = this.partRepository.saveAndFlush(part);

        partService.deletePart("MockedId");
    }

    @Test
    public void partService_findByIdPartWithValidId_returnsCorrect() {
        PartService partService
                = new PartServiceImpl(this.partRepository, this.modelMapper);

        Supplier supplier = new Supplier();
        supplier.setName("Supplier");
        supplier.setImporter(true);

        Part part = new Part();
        part.setName("Part");
        part.setPrice(BigDecimal.ONE);
        part.setSupplier(supplier);

        part = this.partRepository.saveAndFlush(part);

        PartServiceModel actual = partService.findPartById(part.getId());
        PartServiceModel expected = this.modelMapper.map(part, PartServiceModel.class);

        Assert.assertEquals(expected.getId(), actual.getId());
        Assert.assertEquals(expected.getName(), actual.getName());
        Assert.assertEquals(expected.getPrice(), actual.getPrice());
    }

    @Test(expected = Exception.class)
    public void partService_findByIdPartWithInvalidId_returnsCorrect() {
        PartService partService
                = new PartServiceImpl(this.partRepository, this.modelMapper);

        Supplier supplier = new Supplier();
        supplier.setName("Supplier");
        supplier.setImporter(true);

        Part part = new Part();
        part.setName("Part");
        part.setPrice(BigDecimal.ONE);
        part.setSupplier(supplier);

        part = this.partRepository.saveAndFlush(part);

        partService.findPartById("MockedId");
    }

}
