package com.softuni.residentevil.domain.entities;

public enum  Mutation {

    ZOMBIE, T_78_TYRANT, GIANT_SPIDER;
}
