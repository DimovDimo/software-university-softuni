package com.softuni.residentevil.service;

import com.softuni.residentevil.domain.models.service.CapitalServiceModel;

import java.util.List;

public interface CapitalService {
    List<CapitalServiceModel> findAllCapitals();
}
