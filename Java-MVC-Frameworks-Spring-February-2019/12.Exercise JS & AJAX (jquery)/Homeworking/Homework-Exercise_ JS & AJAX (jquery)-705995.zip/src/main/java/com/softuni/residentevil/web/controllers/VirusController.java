package com.softuni.residentevil.web.controllers;

import com.softuni.residentevil.domain.models.binding.VirusAddBindingModel;
import com.softuni.residentevil.domain.models.binding.VirusEditBindingModel;
import com.softuni.residentevil.domain.models.service.VirusServiceModel;
import com.softuni.residentevil.domain.view.CapitalListViewModel;
import com.softuni.residentevil.domain.view.VirusViewModel;
import com.softuni.residentevil.service.CapitalService;
import com.softuni.residentevil.service.VirusService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/viruses")
public class VirusController extends BaseController {
    @Autowired
    private CapitalService capitalService;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private VirusService virusService;

    @GetMapping("/add")
    public ModelAndView add(ModelAndView modelAndView,
                            @ModelAttribute(name = "bindingModel") VirusAddBindingModel bindingModel) {
        modelAndView.addObject("bindingModel", bindingModel);
        modelAndView.addObject("capitals", this.capitalService
                .findAllCapitals()
                .stream()
                .map(c -> this.modelMapper.map(c, CapitalListViewModel.class))
                .collect(Collectors.toList()));

        return super.view("add-virus", modelAndView);
    }

    @PostMapping("/add")
    public ModelAndView addConfirm(@Valid @ModelAttribute(name = "bindingModel") VirusAddBindingModel bindingModel,
                                   BindingResult bindingResult,
                                   ModelAndView modelAndView) {
        if (bindingResult.hasErrors()) {
            modelAndView.addObject("bindingModel", bindingModel);
            return super.view("add-virus", modelAndView);
        }
        VirusServiceModel virus = this.virusService.save(
                this.modelMapper.map(bindingModel, VirusServiceModel.class));

        if (virus == null) {
            return super.redirect("/error");
        }
        return super.redirect("/");
    }

    @GetMapping("/show")
    public ModelAndView show(ModelAndView modelAndView) {

        List<VirusViewModel> viruses = this.virusService.findAllViruses()
                .stream()
                .map(v -> this.modelMapper.map(v, VirusViewModel.class))
                .collect(Collectors.toList());
        modelAndView.addObject("viruses", viruses);

        return super.view("show-all", modelAndView);
    }

    @GetMapping("/edit/{id}")
    public ModelAndView edit(@PathVariable(name = "id") Integer id,
                             ModelAndView modelAndView) {
        VirusEditBindingModel bindingModel = this.modelMapper.map(
                this.virusService.findById(id), VirusEditBindingModel.class);

        modelAndView.addObject("bindingModel", bindingModel);
        modelAndView.addObject("capitals", this.capitalService
                .findAllCapitals()
                .stream()
                .map(c -> this.modelMapper.map(c, CapitalListViewModel.class))
                .collect(Collectors.toList()));

        return super.view("edit-virus", modelAndView);
    }

    @PostMapping("/edit/{id}")
    public ModelAndView editConfirm(@PathVariable(name = "id") Integer id,
                                    @Valid @ModelAttribute(name = "bindingModel") VirusEditBindingModel bindingModel,
                                    BindingResult bindingResult,
                                    ModelAndView modelAndView) {
        if (bindingResult.hasErrors()) {
            modelAndView.addObject("bindingModel", bindingModel);
            return super.view("edit-virus", modelAndView);
        }
        bindingModel.setId(id);
        VirusServiceModel virus = this.virusService.edit(
                this.modelMapper.map(bindingModel, VirusServiceModel.class));

        if (virus == null) {
            return super.redirect("/error");
        }
        return super.redirect("/");
    }

    @GetMapping("/delete/{id}")
    public ModelAndView delete(@PathVariable(name = "id") Integer id) {
        System.out.println("hi");
        if (!this.virusService.delete(id)) {
            throw new IllegalArgumentException("Could not delete virus");
        }
        return super.redirect("/");
    }
}