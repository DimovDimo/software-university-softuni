package com.softuni.residentevil.domain.entities;

public enum Creator {
    Corp,corp;
}
