package com.softuni.residentevil.repository;

import com.softuni.residentevil.domain.entities.Virus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VirusRepository extends JpaRepository<Virus,Integer> {

    Optional<Virus> findById(Integer id);
}
