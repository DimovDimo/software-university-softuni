package com.softuni.residentevil.domain.view;

import com.softuni.residentevil.domain.entities.Magnitude;

import java.time.LocalDate;

public class VirusViewModel {

    private Integer id;
    private String name;
    private Magnitude magnitude;
    private LocalDate releasedOn;

    public VirusViewModel() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Magnitude getMagnitude() {
        return magnitude;
    }

    public void setMagnitude(Magnitude magnitude) {
        this.magnitude = magnitude;
    }

    public LocalDate getReleasedOn() {
        return releasedOn;
    }

    public void setReleasedOn(LocalDate releasedOn) {
        this.releasedOn = releasedOn;
    }
}
