package com.softuni.residentevil.service;

import com.softuni.residentevil.domain.models.service.VirusServiceModel;

import java.util.List;

public interface VirusService {

    VirusServiceModel save(VirusServiceModel virusServiceModel);

    VirusServiceModel edit(VirusServiceModel virusServiceModel);

    VirusServiceModel findById(Integer id);

    List<VirusServiceModel> findAllViruses();

    boolean delete(Integer id);
}
