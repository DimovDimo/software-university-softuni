package com.softuni.residentevil.service;

import com.softuni.residentevil.domain.entities.Virus;
import com.softuni.residentevil.domain.models.service.VirusServiceModel;
import com.softuni.residentevil.repository.VirusRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class VirusServiceImpl implements VirusService {

    @Autowired
    private VirusRepository virusRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public VirusServiceModel save(VirusServiceModel virusServiceModel) {
        try {
            Virus virus = this.modelMapper.map(virusServiceModel, Virus.class);
            virus = this.virusRepository.saveAndFlush(virus);
            return this.modelMapper.map(virus, VirusServiceModel.class);
        } catch (Exception e) {
            throw new IllegalArgumentException("Virus was not saved, try again!");
        }
    }

    @Override
    public VirusServiceModel edit(VirusServiceModel virusServiceModel) {
        try {
            Virus virus = this.modelMapper.map(virusServiceModel, Virus.class);
            virus = this.virusRepository.saveAndFlush(virus);
            return this.modelMapper.map(virus, VirusServiceModel.class);
        } catch (Exception e) {
            throw new IllegalArgumentException("Virus was not edited, try again!");
        }
    }

    @Override
    public VirusServiceModel findById(Integer id) {
        Virus virus = this.virusRepository.findById(id).orElse(null);
        if (virus == null) {
            throw new IllegalArgumentException("Virus does not exists");
        }
        return this.modelMapper.map(virus, VirusServiceModel.class);
    }

    @Override
    public List<VirusServiceModel> findAllViruses() {
        return this.virusRepository.findAll()
                .stream()
                .map(v -> this.modelMapper.map(v, VirusServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public boolean delete(Integer id) {
        Virus virus = this.virusRepository.findById(id).orElse(null);
        if (virus == null) {
            throw new IllegalArgumentException("Virus does not exists");
        }
        try {
            this.virusRepository.delete(virus);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
