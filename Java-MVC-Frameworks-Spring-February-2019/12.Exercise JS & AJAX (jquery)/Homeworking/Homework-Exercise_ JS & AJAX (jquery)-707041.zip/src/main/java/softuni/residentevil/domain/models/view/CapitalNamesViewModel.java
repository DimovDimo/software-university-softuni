package softuni.residentevil.domain.models.view;

public class CapitalNamesViewModel extends BaseViewModel {
	private String name;

	public CapitalNamesViewModel() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}