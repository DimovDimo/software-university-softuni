package com.example.residentevil.domain.entities.enumerations;

public enum Mutation {

    ZOMBIE, T_078_TYRANT, GIANT_SPIDER
}
