package com.example.residentevil.domain.entities.enumerations;

public enum Magnitude {

    Low, Medium, High
}
