package org.softuni.residentevil.domain.models.binding;

import org.hibernate.validator.constraints.Range;
import org.softuni.residentevil.domain.entities.Capital;
import org.softuni.residentevil.domain.entities.Creator;
import org.softuni.residentevil.domain.entities.Magnitude;
import org.softuni.residentevil.domain.entities.Mutation;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDate;
import java.util.List;

public class VirusAddBindingModel extends VirusBindingModel{

    public VirusAddBindingModel() {
    }


    //
//    private String name;
//    private String description;
//    private String sideEffects;
//    private Creator creator;
//    private boolean isDeadly;
//    private boolean isCurable;
//    private Mutation mutation;
//    private Integer turnoverRate;
//    private Integer hoursUntilTurn;
//    private Magnitude magnitude;
//    private LocalDate releasedOn;
//    private List<Capital> capitals;
//
//
//    public VirusAddBindingModel() {
//
//    }
//
//    @NotNull
//    @Size(min = 3, max = 10, message = "Name should be between 3 and 10 symbols!")
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    @NotNull
//    @Size(min = 5, max=100, message = "Description should be between 5 and 100 symbols.")
//    public String getDescription() {
//        return description;
//    }
//
//    public void setDescription(String description) {
//        this.description = description;
//    }
//
//    @Size(max=50, message = "Side Effects should have a maximum of 50 symbols")
//    public String getSideEffects() {
//        return sideEffects;
//    }
//
//    public void setSideEffects(String sideEffects) {
//        this.sideEffects = sideEffects;
//    }
//
//    public Creator getCreator() {
//        return creator;
//    }
//
//    public void setCreator(Creator creator) {
//        this.creator = creator;
//    }
//
//    public boolean isDeadly() {
//        return isDeadly;
//    }
//
//    public void setDeadly(boolean deadly) {
//        isDeadly = deadly;
//    }
//
//    public boolean isCurable() {
//        return isCurable;
//    }
//
//    public void setCurable(boolean curable) {
//        isCurable = curable;
//    }
//
//    @NotNull(message = "You should choose one option.")
//    public Mutation getMutation() {
//        return mutation;
//    }
//
//    public void setMutation(Mutation mutation) {
//        this.mutation = mutation;
//    }
//
//    @NotNull(message = "Turnover Rate should be between 0 and 100.")
//    @Range(min=0, max=100, message = "Turnover Rate should be between 0 and 100")
//    public Integer getTurnoverRate() {
//        return turnoverRate;
//    }
//
//    public void setTurnoverRate(Integer turnoverRate) {
//        this.turnoverRate = turnoverRate;
//    }
//
//    @NotNull(message = "Hours Until Turn (to a mutation) should be between 1 and 12")
//    @Range(min=1, max=12, message = "Hours Until Turn (to a mutation) should be between 1 and 12")
//    public Integer getHoursUntilTurn() {
//        return hoursUntilTurn;
//    }
//
//    public void setHoursUntilTurn(Integer hoursUntilTurn) {
//        this.hoursUntilTurn = hoursUntilTurn;
//    }
//
//    public Magnitude getMagnitude() {
//        return magnitude;
//    }
//
//    public void setMagnitude(Magnitude magnitude) {
//        this.magnitude = magnitude;
//    }
//
//    @DateTimeFormat(pattern = "yyyy-MM-dd")
//    public LocalDate getReleasedOn() {
//        return releasedOn;
//    }
//
//    public void setReleasedOn(LocalDate releasedOn) {
//        this.releasedOn = releasedOn;
//    }
//
//    public List<Capital> getCapitals() {
//        return capitals;
//    }
//
//    public void setCapitals(List<Capital> capitals) {
//        this.capitals = capitals;
//    }
}
