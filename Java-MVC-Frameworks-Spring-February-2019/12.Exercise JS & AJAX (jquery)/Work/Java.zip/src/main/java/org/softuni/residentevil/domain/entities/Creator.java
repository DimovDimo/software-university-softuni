package org.softuni.residentevil.domain.entities;

public enum Creator {
    Corp, corp
}
