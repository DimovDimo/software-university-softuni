package org.softuni.demo.domain.entities;

public class Log {

}
