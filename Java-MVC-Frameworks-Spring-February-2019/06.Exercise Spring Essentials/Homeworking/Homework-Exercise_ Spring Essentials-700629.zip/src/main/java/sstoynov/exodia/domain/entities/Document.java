package sstoynov.exodia.domain.entities;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity(name = "documents")
public class Document extends BaseEntity{
    private String title;
    private String content;

    public Document() {
    }

    @Column(name = "title", nullable = false)
    public String getTitle() {
        return this.title;
    }

    @Column(name = "content", columnDefinition = "TEXT", nullable = false)
    public String getContent() {
        return this.content;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
