package com.softuni.exodiaspring.web.controllers.base;

import com.softuni.exodiaspring.service.contracts.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

@Controller
public abstract class BaseController {
    protected boolean isLoggedIn(HttpSession session) {
        String id = (String) session.getAttribute("userId");
        String username = (String) session.getAttribute("username");

        if(id == null || username == null) {
            return false;
        }

        return true;
    }

    protected ModelAndView redirectUnAuthorizedUser(ModelAndView modelAndView) {
        modelAndView.setViewName("redirect:/login");
        return modelAndView;
    }
}
