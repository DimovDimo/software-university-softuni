package com.softuni.exodiaspring.service;

import com.softuni.exodiaspring.domain.entites.User;
import com.softuni.exodiaspring.domain.models.service.UserServiceModel;
import com.softuni.exodiaspring.repository.UserRepository;
import com.softuni.exodiaspring.service.contracts.UserService;
import org.apache.commons.codec.digest.DigestUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public UserServiceModel register(UserServiceModel userServiceModel) {
        try {
            User user = this.modelMapper.map(userServiceModel, User.class);
            user.setPassword(DigestUtils.sha256Hex(user.getPassword()));
            User savedUser = this.userRepository.saveAndFlush(user);

            return this.modelMapper.map(savedUser, UserServiceModel.class);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public UserServiceModel login(UserServiceModel userServiceModel) {
        userServiceModel.setPassword(DigestUtils.sha256Hex(userServiceModel.getPassword()));
        User user = this.userRepository.
                findByUsernameAndPassword(userServiceModel.getUsername(), userServiceModel.getPassword())
                .orElse(null);

        if(user == null) {
            return null;
        }

        return this.modelMapper.map(user, UserServiceModel.class);
    }

    @Override
    public UserServiceModel findById(String id) {
        return this.userRepository.findById(id).map(x -> this.modelMapper.map(x, UserServiceModel.class)).orElse(null);
    }
}