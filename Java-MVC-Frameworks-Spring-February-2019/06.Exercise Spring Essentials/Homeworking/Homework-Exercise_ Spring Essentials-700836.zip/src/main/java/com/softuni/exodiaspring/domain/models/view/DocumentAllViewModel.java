package com.softuni.exodiaspring.domain.models.view;

public class DocumentAllViewModel {
    private String id;
    private String title;

    public DocumentAllViewModel() {
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        int requiredLength = 12;
        return this.title.substring(0, Math.min(requiredLength, this.title.length())) + "...";
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
