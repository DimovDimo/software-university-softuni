package com.softuni.exodiaspring.service;

import com.softuni.exodiaspring.domain.entites.Document;
import com.softuni.exodiaspring.domain.models.service.DocumentServiceModel;
import com.softuni.exodiaspring.repository.DocumentRepository;
import com.softuni.exodiaspring.service.contracts.DocumentService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DocumentServiceImpl implements DocumentService {
    private final DocumentRepository documentRepository;
    private final ModelMapper mapper;

    @Autowired
    public DocumentServiceImpl(DocumentRepository documentRepository, ModelMapper mapper) {
        this.documentRepository = documentRepository;
        this.mapper = mapper;
    }

    @Override
    public DocumentServiceModel save(DocumentServiceModel documentServiceModel) {
        try {
            Document savedDocument = this.documentRepository.saveAndFlush(this.mapper.map(documentServiceModel, Document.class));
            return this.mapper.map(savedDocument, DocumentServiceModel.class);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public DocumentServiceModel findById(String id) {
        Document document = this.documentRepository.findById(id).orElse(null);

        if(document != null) {
            return this.mapper.map(document, DocumentServiceModel.class);
        }

        return null;
    }

    @Override
    public List<DocumentServiceModel> findAll() {
        return this.documentRepository.findAll()
                .stream()
                .map(x -> this.mapper.map(x, DocumentServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public boolean print(String id) {
        try {
            this.documentRepository.deleteById(id);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
