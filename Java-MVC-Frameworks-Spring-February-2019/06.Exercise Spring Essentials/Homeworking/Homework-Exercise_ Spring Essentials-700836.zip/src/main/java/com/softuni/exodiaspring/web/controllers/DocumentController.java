package com.softuni.exodiaspring.web.controllers;

import com.softuni.exodiaspring.domain.models.binding.DocumentCreateBindingModel;
import com.softuni.exodiaspring.domain.models.service.DocumentServiceModel;
import com.softuni.exodiaspring.domain.models.view.DocumentDetailsViewModel;
import com.softuni.exodiaspring.domain.models.view.DocumentPrintViewModel;
import com.softuni.exodiaspring.service.contracts.DocumentService;
import com.softuni.exodiaspring.web.controllers.base.BaseController;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

@Controller
public class DocumentController extends BaseController {
    private final DocumentService documentService;
    private final ModelMapper mapper;

    @Autowired
    public DocumentController(DocumentService documentService, ModelMapper mapper) {
        this.documentService = documentService;
        this.mapper = mapper;
    }

    @GetMapping("/schedule")
    public ModelAndView schedule(ModelAndView modelAndView, HttpSession session) {
        if(!super.isLoggedIn(session)) {
            return super.redirectUnAuthorizedUser(modelAndView);
        }

        modelAndView.setViewName("schedule");

        return modelAndView;
    }

    @PostMapping("/schedule")
    public ModelAndView scheduleConfirm(@ModelAttribute DocumentCreateBindingModel documentCreateBindingModel, ModelAndView modelAndView, HttpSession session) {
        if(!super.isLoggedIn(session)) {
            return super.redirectUnAuthorizedUser(modelAndView);
        }

        DocumentServiceModel savedDocument = this.documentService.save(
                this.mapper.map(documentCreateBindingModel, DocumentServiceModel.class)
        );

        if(savedDocument == null) {
            throw new IllegalArgumentException("Something went wrong!");
        }

        modelAndView.setViewName("redirect:/details/" + savedDocument.getId());

        return modelAndView;
    }

    @GetMapping("/details/{id}")
    public ModelAndView documentDetails(@PathVariable(name = "id") String id, ModelAndView modelAndView, HttpSession session) {
        if(!super.isLoggedIn(session)) {
            return super.redirectUnAuthorizedUser(modelAndView);
        }

        DocumentServiceModel documentFromDb = this.documentService.findById(id);

        if(documentFromDb == null) {
            throw new IllegalArgumentException("Something went wrong");
        }

        modelAndView.addObject("document", this.mapper.map(documentFromDb, DocumentDetailsViewModel.class));
        modelAndView.setViewName("details");

        return modelAndView;
    }

    @GetMapping("/print/{id}")
    public ModelAndView printDocument(@PathVariable(name = "id") String id, ModelAndView modelAndView, HttpSession session) {
        if(!super.isLoggedIn(session)) {
            return super.redirectUnAuthorizedUser(modelAndView);
        }
        DocumentServiceModel document = this.documentService.findById(id);

        if(document == null) {
            throw new IllegalArgumentException("Something went wrong!");
        }

        modelAndView.addObject("document", this.mapper.map(document, DocumentPrintViewModel.class));
        modelAndView.setViewName("print");

        return modelAndView;
    }

    @PostMapping("/print/{id}")
    public ModelAndView printConfirm(@PathVariable(name = "id") String id, ModelAndView modelAndView, HttpSession session) {
        if(!super.isLoggedIn(session)) {
            return super.redirectUnAuthorizedUser(modelAndView);
        }

        boolean isPrintSuccessful = this.documentService.print(id);

        if(!isPrintSuccessful) {
            throw new IllegalArgumentException("Something went wrong!");
        }

        modelAndView.setViewName("redirect:/home");

        return modelAndView;
    }
}
