package com.softuni.exodiaspring.service.contracts;

import com.softuni.exodiaspring.domain.models.service.DocumentServiceModel;

import java.util.List;

public interface DocumentService {
    DocumentServiceModel save(DocumentServiceModel documentServiceModel);

    DocumentServiceModel findById(String id);

    List<DocumentServiceModel> findAll();

    boolean print(String id);
}
