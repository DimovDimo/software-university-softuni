package com.softuni.exodiaspring.web.controllers;

import com.softuni.exodiaspring.domain.models.binding.UserLoginBindingModel;
import com.softuni.exodiaspring.domain.models.binding.UserRegisterBindingModel;
import com.softuni.exodiaspring.domain.models.service.UserServiceModel;
import com.softuni.exodiaspring.service.contracts.UserService;
import com.softuni.exodiaspring.web.controllers.base.BaseController;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

@Controller
public class UserController extends BaseController {
    private final UserService userService;
    private final ModelMapper mapper;

    @Autowired
    public UserController(UserService userService, ModelMapper mapper) {
        this.userService = userService;
        this.mapper = mapper;
    }


    @GetMapping("/register")
    public ModelAndView register(ModelAndView modelAndView, HttpSession session) {
        if(!super.isLoggedIn(session)) {
            modelAndView.setViewName("register");
        } else {
            modelAndView.setViewName("redirect:/home");
        }
        return modelAndView;
    }

    @PostMapping("/register")
    public ModelAndView registerConfirm(@ModelAttribute UserRegisterBindingModel userRegisterBindingModel, ModelAndView modelAndView, HttpSession session) {
        if(super.isLoggedIn(session)) {
            modelAndView.setViewName("redirect:/home");
            return modelAndView;
        }


        if(!userRegisterBindingModel.getPassword().equals(userRegisterBindingModel.getConfirmPassword())) {
            throw new IllegalArgumentException("Passwords do not match");
        }

        if(this.userService.register(this.mapper.map(userRegisterBindingModel, UserServiceModel.class)) == null) {
            throw new IllegalArgumentException("Something went wrong!");
        }

        modelAndView.setViewName("redirect:/login");

        return modelAndView;
    }

    @GetMapping("/login")
    public ModelAndView login(ModelAndView modelAndView, HttpSession session) {
        if(!super.isLoggedIn(session)) {
            modelAndView.setViewName("login");
        } else {
            modelAndView.setViewName("redirect:/home");
        }
        return modelAndView;
    }

    @PostMapping("/login")
    public ModelAndView loginConfirm(ModelAndView modelAndView, @ModelAttribute UserLoginBindingModel userLoginBindingModel, HttpSession session) {
        if(super.isLoggedIn(session)) {
            modelAndView.setViewName("redirect:/home");
            return modelAndView;
        }

        UserServiceModel loggedInUser = this.userService.login(
                this.mapper.map(userLoginBindingModel, UserServiceModel.class)
        );

        if(loggedInUser == null) {
            throw new IllegalArgumentException("Something went wrong!");
        }

        session.setAttribute("userId", loggedInUser.getId());
        session.setAttribute("username", loggedInUser.getUsername());

        modelAndView.setViewName("redirect:/home");

        return modelAndView;
    }

    @GetMapping("/logout")
    public ModelAndView logout(HttpSession session, ModelAndView modelAndView) {
        session.invalidate();

        modelAndView.setViewName("redirect:/");
        return modelAndView;
    }
}
