package com.softuni.exodiaspring.web.controllers;

import com.softuni.exodiaspring.domain.models.view.DocumentAllViewModel;
import com.softuni.exodiaspring.service.contracts.DocumentService;
import com.softuni.exodiaspring.web.controllers.base.BaseController;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class HomeController extends BaseController {
    private final DocumentService documentService;
    private final ModelMapper mapper;

    @Autowired
    public HomeController(DocumentService documentService, ModelMapper mapper) {
        this.documentService = documentService;
        this.mapper = mapper;
    }

    @GetMapping("/")
    public ModelAndView index(ModelAndView modelAndView, HttpSession session) {
        if(super.isLoggedIn(session)) {
           modelAndView.setViewName("redirect:/home");
        } else {
            modelAndView.setViewName("index");
        }
        return modelAndView;
    }

    @GetMapping("/home")
    public ModelAndView home(ModelAndView modelAndView, HttpSession session) {
        if(super.isLoggedIn(session)) {
            modelAndView.setViewName("home");
        } else {
            return super.redirectUnAuthorizedUser(modelAndView);
        }

        List<DocumentAllViewModel> documents = this.documentService.findAll()
                .stream()
                .map(x -> this.mapper.map(x, DocumentAllViewModel.class))
                .collect(Collectors.toList());

        modelAndView.addObject("documents", documents);

        return modelAndView;
    }
}
