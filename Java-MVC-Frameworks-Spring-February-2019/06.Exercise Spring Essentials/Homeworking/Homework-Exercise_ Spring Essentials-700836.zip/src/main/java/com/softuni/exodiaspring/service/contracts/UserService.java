package com.softuni.exodiaspring.service.contracts;

import com.softuni.exodiaspring.domain.models.service.UserServiceModel;

public interface UserService {
    UserServiceModel register(UserServiceModel userServiceModel);

    UserServiceModel login(UserServiceModel userServiceModel);

    UserServiceModel findById(String id);
}
