package com.softuni.exodiaspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExodiaSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExodiaSpringApplication.class, args);
    }

}
