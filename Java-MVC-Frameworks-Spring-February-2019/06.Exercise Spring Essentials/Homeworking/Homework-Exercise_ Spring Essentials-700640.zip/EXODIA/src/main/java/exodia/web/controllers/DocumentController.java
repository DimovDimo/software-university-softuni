package exodia.web.controllers;

import exodia.domain.models.binding.DocumentScheduleBindingModel;
import exodia.domain.models.service.DocumentServiceModel;
import exodia.domain.models.view.DocumentDetailsViewModel;
import exodia.service.DocumentService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

@Controller
public class DocumentController extends BaseController {
    private final DocumentService documentService;
    private final ModelMapper modelMapper;

    @Autowired
    public DocumentController(DocumentService documentService, ModelMapper modelMapper) {
        this.documentService = documentService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/schedule")
    public ModelAndView schedule(ModelAndView modelAndView, HttpSession session) {
        if (session.getAttribute("username") == null) {
            return this.redirect("login", modelAndView);
        }

        return this.view("schedule");
    }

    @PostMapping("/schedule")
    public ModelAndView scheduleConfirm(@ModelAttribute DocumentScheduleBindingModel model, ModelAndView modelAndView, HttpSession session) {
        if (session.getAttribute("username") == null){
            return this.redirect("login", modelAndView);
        }

        DocumentServiceModel document = this.documentService.scheduleDocument(this.modelMapper.map(model, DocumentServiceModel.class));

        if (document == null){
            throw  new IllegalArgumentException("Document save failed!");
        }

        return this.redirect("details/" + document.getId(), modelAndView);
    }

    @GetMapping("/details/{id}")
    public ModelAndView details(@PathVariable(name = "id") String id, ModelAndView modelAndView, HttpSession session){
        if (session.getAttribute("username") == null){
            return this.redirect("/login", modelAndView);
        }

        modelAndView = this.prepareDetailview(modelAndView, id);

        return this.view("details", modelAndView);
    }

    @GetMapping("/print/{id}")
    public ModelAndView print(@PathVariable(name = "id") String id, ModelAndView modelAndView, HttpSession session) {
        if (session.getAttribute("username") == null) {
            return this.redirect("/login", modelAndView);
        }

        modelAndView = this.prepareDetailview(modelAndView, id);

        return this.view("print", modelAndView);
    }

    @PostMapping("/print/{id}")
    public ModelAndView printConfirm(@PathVariable(name = "id") String id, ModelAndView modelAndView, HttpSession session) {
        if (session.getAttribute("username") == null) {
            return this.redirect("/login", modelAndView);
        }

        if (!this.documentService.printDocumentById(id)){
            throw new IllegalArgumentException("Something went wrong!");
        }

        return this.redirect("/home", modelAndView);
    }

    private ModelAndView prepareDetailview(ModelAndView modelAndView, String id){
        DocumentServiceModel serviceModel = this.documentService.findDocumentById(id);
        if (serviceModel == null) {
            throw new IllegalArgumentException("Document not found!");
        }

        DocumentDetailsViewModel view = this.modelMapper.map(serviceModel, DocumentDetailsViewModel.class);

        modelAndView.addObject("model", this.modelMapper.map(serviceModel, DocumentDetailsViewModel.class));

        return modelAndView;
    }
}


