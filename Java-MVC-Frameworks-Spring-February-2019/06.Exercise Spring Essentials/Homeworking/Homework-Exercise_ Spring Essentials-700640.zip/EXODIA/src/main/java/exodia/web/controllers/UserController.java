package exodia.web.controllers;

import exodia.domain.models.binding.UserLoginBinding;
import exodia.domain.models.binding.UserRegisterBindingModel;
import exodia.domain.models.service.UserServiceModel;
import exodia.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

@Controller
public class UserController extends BaseController {
    private final UserService userService;
    private final ModelMapper modelMapper;

    @Autowired
    public UserController(UserService userService, ModelMapper modelMapper) {
        this.userService = userService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/register")
    public ModelAndView register(ModelAndView modelAndView, HttpSession session){
        if (session.getAttribute("username") != null){
            return this.redirect("home", modelAndView);
        }
        return this.view("register", modelAndView);
    }

    @PostMapping("/register")
    public ModelAndView registerConfirm(@ModelAttribute UserRegisterBindingModel model,
                                        ModelAndView modelAndView){
        if (!model.getPassword().equals(model.getConfirmPassword())){
            throw new IllegalArgumentException("Password doesn't match!");
        }

        if (!this.userService.registerUser(this.modelMapper.map(model, UserServiceModel.class))){
            throw  new IllegalArgumentException("User registration failed!");
        }

        return this.redirect("/login", modelAndView);
    }

    @GetMapping("/login")
    public ModelAndView login(ModelAndView modelAndView, HttpSession session){
        if (session.getAttribute("username") != null){
            return this.redirect("home", modelAndView);
        }
        return this.view("login", modelAndView);
    }

    @PostMapping("/login")
    public ModelAndView loginConfirm(@ModelAttribute UserLoginBinding userLoginBinding, ModelAndView modelAndView,
                                     HttpSession session){
        UserServiceModel user = this.userService.loginUser(this.modelMapper.map(userLoginBinding, UserServiceModel.class));

        if (user == null){
            throw  new IllegalArgumentException("User login failed!");
        }

        session.setAttribute("userId", user.getId());
        session.setAttribute("username", user.getUsername());

        return this.redirect("home", modelAndView);
    }

    @GetMapping("/logout")
    public ModelAndView logOut(ModelAndView modelAndView, HttpSession session){
        if (session.getAttribute("username") == null){
            return this.redirect("", modelAndView);
        }

        session.invalidate();
        return this.redirect("", modelAndView);
    }
}
