package exodia.service;

import exodia.domain.models.service.UserServiceModel;
import org.springframework.stereotype.Service;

public interface UserService {
    boolean registerUser(UserServiceModel userServiceModel);
    UserServiceModel loginUser(UserServiceModel userServiceModel);
}
