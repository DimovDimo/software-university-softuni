package softuni.exodia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExodiaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExodiaApplication.class, args);
    }

}
