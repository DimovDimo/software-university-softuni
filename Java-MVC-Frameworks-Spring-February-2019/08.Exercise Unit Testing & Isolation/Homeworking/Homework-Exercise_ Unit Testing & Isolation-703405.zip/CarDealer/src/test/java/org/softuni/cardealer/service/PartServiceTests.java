package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.entities.Part;
import org.softuni.cardealer.domain.entities.Supplier;
import org.softuni.cardealer.domain.models.service.PartServiceModel;
import org.softuni.cardealer.repository.PartRepository;
import org.softuni.cardealer.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class PartServiceTests {

    @Autowired
    private PartRepository partRepository;
    @Autowired
    private SupplierRepository supplierRepository;
    private ModelMapper modelMapper;
    private PartService  partService;


    @Before
    public void init() {
        this.modelMapper = new ModelMapper();
        this.partService = new PartServiceImpl(this.partRepository, this.modelMapper);

    }

    private Part createPart() {
        Part part = new Part();
        part.setName("part1");
        part.setPrice(BigDecimal.valueOf(20L));
        Supplier supplier = new Supplier();
        supplier.setName("Pesh");
        supplier.setImporter(true);
        this.supplierRepository.saveAndFlush(supplier);
        part.setSupplier(supplier);
        return part;
    }

    private void compareParts(PartServiceModel actual, PartServiceModel expected) {
        Assert.assertEquals(expected.getId(),actual.getId());
        Assert.assertEquals(expected.getName(),actual.getName());
        Assert.assertEquals(expected.getPrice(),actual.getPrice());
        Assert.assertEquals(expected.getSupplier().getId(),actual.getSupplier().getId());
        Assert.assertEquals(expected.getSupplier().getName(),actual.getSupplier().getName());
        Assert.assertEquals(expected.getSupplier().isImporter(),actual.getSupplier().isImporter());

    }
    @Test
    public void partService_savePartWithCorrectValues_Returns_Correct() {

        PartServiceModel toBeSaved = this.modelMapper.map(createPart(),PartServiceModel.class);

        PartServiceModel actual = this.partService.savePart(toBeSaved);
        PartServiceModel expected = this.modelMapper.map(
                this.partRepository.findAll().get(0), PartServiceModel.class);

        compareParts(actual, expected);
    }

    @Test(expected = Exception.class)
    public void partService_savePartWithNullValues_ThrowsException() {

        PartServiceModel toBeSaved = this.modelMapper.map(createPart(),PartServiceModel.class);

        toBeSaved.setName(null);
        toBeSaved.setPrice(null);

        this.partService.savePart(toBeSaved);
    }

    @Test
    public void  partService_editPartWithCorrectValues_ReturnsCorrect(){
        Part part = createPart();
        part = this.partRepository.saveAndFlush(part);

        PartServiceModel toBeEdited = new PartServiceModel();
        toBeEdited.setId(part.getId());
        toBeEdited.setName("part1Edited");
        toBeEdited.setPrice(BigDecimal.valueOf(199L));

        PartServiceModel actual = this.partService.editPart(toBeEdited);
        PartServiceModel expected = this.modelMapper.map(
                this.partRepository.findAll().get(0), PartServiceModel.class
        );

        compareParts(actual, expected);
    }

    @Test(expected = Exception.class)
    public void  partService_editPartWithNullValues_ThrowsException() {
        Part part = createPart();
        part = this.partRepository.saveAndFlush(part);

        PartServiceModel toBeEdited = new PartServiceModel();
        toBeEdited.setId(part.getId());

        PartServiceModel actual = this.partService.editPart(toBeEdited);
    }

    @Test
    public void partService_DeletePartWithValidId_ReturnCorrect(){

        Part part = createPart();
        part = this.partRepository.saveAndFlush(part);

        this.partService.deletePart(part.getId());
        long expectedCount=0L;
        long actualCount = this.partRepository.count();

        Assert.assertEquals(expectedCount,actualCount);
    }

    @Test(expected=Exception.class)
    public void partService_DeletePartWithInvalidId_ThrowsException() {

        Part part = createPart();
        part = this.partRepository.saveAndFlush(part);

        this.partService.deletePart("invalid");

    }

    @Test
    public void  partService_FindPartWithValidId_ReturnsCorrect(){

        Part part = createPart();
        part = this.partRepository.saveAndFlush(part);

        PartServiceModel actual = this.partService.findPartById(part.getId());
        PartServiceModel expected = this.modelMapper.map(part,PartServiceModel.class);

        compareParts(actual, expected);
    }

    @Test(expected = Exception.class)
    public void  partService_FindPartWithInvalidId_ThrowsException() {

        Part part = createPart();
        part = this.partRepository.saveAndFlush(part);

        this.partService.findPartById("invalid");
    }


}
