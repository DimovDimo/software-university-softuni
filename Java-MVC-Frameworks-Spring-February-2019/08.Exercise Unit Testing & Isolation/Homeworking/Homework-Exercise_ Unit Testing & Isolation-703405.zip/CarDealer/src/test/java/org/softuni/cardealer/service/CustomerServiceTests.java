package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.entities.Customer;
import org.softuni.cardealer.domain.models.service.CustomerServiceModel;
import org.softuni.cardealer.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CustomerServiceTests {
    @Autowired
    private CustomerRepository customerRepository;
    private ModelMapper modelMapper;
    private CustomerService  customerService;

    @Before
    public void init() {
        this.modelMapper = new ModelMapper();
        this.customerService = new CustomerServiceImpl(this.customerRepository, this.modelMapper);

    }

    private void compareCustomers(CustomerServiceModel actual, CustomerServiceModel expected) {
        Assert.assertEquals(expected.getId(),actual.getId());
        Assert.assertEquals(expected.getName(),actual.getName());
        Assert.assertEquals(expected.getBirthDate(),actual.getBirthDate());
    }

    private Customer createCustomer() {
        Customer customer = new Customer();
        customer.setName("Ivan");
        DateTimeFormatter germanFormatter = DateTimeFormatter.ofLocalizedDate(
                FormatStyle.MEDIUM).withLocale(Locale.GERMAN);

        LocalDate birthdate = LocalDate.parse("15.05.1999", germanFormatter);
        customer.setBirthDate(birthdate);
        customer.setYoungDriver(false);
        return customer;
    }

    @Test
    public void customerService_saveCustomerWithCorrectValues_Returns_Correct() {

        CustomerServiceModel toBeSaved = this.modelMapper.map(createCustomer(),CustomerServiceModel.class);

        CustomerServiceModel actual = this.customerService.saveCustomer(toBeSaved);
        CustomerServiceModel expected = this.modelMapper.map(
                this.customerRepository.findAll().get(0), CustomerServiceModel.class);

        compareCustomers(actual, expected);

    }

    @Test(expected = Exception.class)
    public void customerService_saveCustomerWithNullValues_ThrowsException() {

        CustomerServiceModel toBeSaved = this.modelMapper.map(createCustomer(),CustomerServiceModel.class);

        toBeSaved.setName(null);
        toBeSaved.setBirthDate(null);

        this.customerService.saveCustomer(toBeSaved);
    }

    @Test
    public void  customerService_editCustomerWithCorrectValues_ReturnsCorrect(){
        Customer customer = createCustomer();
        customer = this.customerRepository.saveAndFlush(customer);

        CustomerServiceModel toBeEdited = new CustomerServiceModel();
        toBeEdited.setId(customer.getId());
        toBeEdited.setName("Dido");
        toBeEdited.setYoungDriver(true);
        DateTimeFormatter germanFormatter = DateTimeFormatter.ofLocalizedDate(
                FormatStyle.MEDIUM).withLocale(Locale.GERMAN);

        LocalDate birthdate = LocalDate.parse("15.12.1999", germanFormatter);
        toBeEdited.setBirthDate(birthdate);

        CustomerServiceModel actual = this.customerService.editCustomer(toBeEdited);
        CustomerServiceModel expected = this.modelMapper.map(
                this.customerRepository.findAll().get(0), CustomerServiceModel.class
        );

        compareCustomers(actual, expected);
    }

    @Test(expected = Exception.class)
    public void  customerService_editCustomerWithNullValues_ThrowsException() {
        Customer customer = createCustomer();
        customer = this.customerRepository.saveAndFlush(customer);

        CustomerServiceModel toBeEdited = new CustomerServiceModel();
        toBeEdited.setId(customer.getId());

        CustomerServiceModel actual = this.customerService.editCustomer(toBeEdited);
    }

    @Test
    public void  customerService_DeleteCustomerWithValidId_ReturnCorrect(){

        Customer customer = createCustomer();
        customer = this.customerRepository.saveAndFlush(customer);

        this.customerService.deleteCustomer(customer.getId());
        long expectedCount=0L;
        long actualCount = this.customerRepository.count();

        Assert.assertEquals(expectedCount,actualCount);
    }

    @Test(expected=Exception.class)
    public void customerService_DeleteCustomerWithInalidId_ThrowsException() {

        Customer customer = createCustomer();
        customer = this.customerRepository.saveAndFlush(customer);

        this.customerService.deleteCustomer("invalid");

    }

    @Test
    public void  customerService_FindCustomerWithValidId_ReturnsCorrect(){

        Customer customer = createCustomer();
        customer = this.customerRepository.saveAndFlush(customer);

        CustomerServiceModel actual = this.customerService.findCustomerById(customer.getId());
        CustomerServiceModel expected = this.modelMapper.map(customer,CustomerServiceModel.class);

        compareCustomers(actual, expected);
    }

    @Test(expected = Exception.class)
    public void  customerService_FindCustomerWithInvalidId_ThrowsException() {

        Customer customer = createCustomer();
        customer = this.customerRepository.saveAndFlush(customer);

        this.customerService.findCustomerById("invalid");
    }

}
