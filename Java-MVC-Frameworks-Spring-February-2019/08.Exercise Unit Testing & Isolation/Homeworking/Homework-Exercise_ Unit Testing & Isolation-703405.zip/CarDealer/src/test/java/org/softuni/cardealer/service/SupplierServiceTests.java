package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.entities.Supplier;
import org.softuni.cardealer.domain.models.service.SupplierServiceModel;
import org.softuni.cardealer.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class SupplierServiceTests {

    @Autowired
    private SupplierRepository supplierRepository;
    private ModelMapper modelMapper;
    private SupplierService  supplierService;

    @Before
    public void init() {
        this.modelMapper = new ModelMapper();
        this.supplierService = new SupplierServiceImpl(this.supplierRepository, this.modelMapper);

    }

    private void compareSuppliers(SupplierServiceModel actual, SupplierServiceModel expected) {
        Assert.assertEquals(expected.getId(), actual.getId());
        Assert.assertEquals(expected.getName(), actual.getName());
        Assert.assertEquals(expected.isImporter(), actual.isImporter());
    }
    @Test
    public void supplierService_saveSupplierWithCorrectValues_Returns_Correct() {

        SupplierServiceModel toBeSaved = new SupplierServiceModel();
        toBeSaved.setName("Pesho");
        toBeSaved.setImporter(true);

        SupplierServiceModel actual = this.supplierService.saveSupplier(toBeSaved);
        SupplierServiceModel expected = this.modelMapper.map(
                this.supplierRepository.findAll().get(0), SupplierServiceModel.class);

        compareSuppliers(actual, expected);

    }

    @Test(expected = Exception.class)
    public void supplierService_SaveSupplierWithNullValues_ThrowsException() {

        SupplierServiceModel toBeSaved = new SupplierServiceModel();

        toBeSaved.setName(null);
        toBeSaved.setImporter(true);

        this.supplierService.saveSupplier(toBeSaved);
    }

    @Test
    public void supplierService_EditSupplierWithCorrectValues_ReturnsCorrect() {

        Supplier supplier = new Supplier();
        supplier.setName("Pesho");
        supplier.setImporter(true);

        supplier = this.supplierRepository.saveAndFlush(supplier);

        SupplierServiceModel toBeEdited = new SupplierServiceModel();
        toBeEdited.setId(supplier.getId());
        toBeEdited.setName("Gosho");
        toBeEdited.setImporter(false);

        SupplierServiceModel actual = this.supplierService.editSupplier(toBeEdited);
        SupplierServiceModel expected = this.modelMapper.map(
                this.supplierRepository.findAll().get(0), SupplierServiceModel.class
        );

        compareSuppliers(actual, expected);

    }

    @Test(expected = Exception.class)
    public void supplierService_EditSupplierWithNullValues_ThrowsException() {

        Supplier supplier = new Supplier();
        supplier.setName("Pesho");
        supplier.setImporter(true);

        supplier = this.supplierRepository.saveAndFlush(supplier);

        SupplierServiceModel toBeEdited = new SupplierServiceModel();
        toBeEdited.setId(supplier.getId());
        toBeEdited.setName(null);
        toBeEdited.setImporter(false);

        this.supplierService.editSupplier(toBeEdited);
    }

    @Test
    public void supplierService_DeleteSupplierWithValidId_ReturnCorrect(){

        Supplier supplier = new Supplier();
        supplier.setName("Pesho");
        supplier.setImporter(true);

        supplier = this.supplierRepository.saveAndFlush(supplier);

        this.supplierService.deleteSupplier(supplier.getId());
        long expectedCount=0L;
        long actualCount = this.supplierRepository.count();

        Assert.assertEquals(expectedCount,actualCount);
    }

    @Test(expected=Exception.class)
    public void supplierService_DeleteSupplierWithInalidId_ThrowsException() {

        Supplier supplier = new Supplier();
        supplier.setName("Pesho");
        supplier.setImporter(true);

        supplier = this.supplierRepository.saveAndFlush(supplier);

        this.supplierService.deleteSupplier("invalid");

    }

    @Test
    public void supplierService_FindSupplierWithValidId_ReturnsCorrect(){

        Supplier supplier = new Supplier();
        supplier.setName("Pesho");
        supplier.setImporter(true);

        supplier = this.supplierRepository.saveAndFlush(supplier);

        SupplierServiceModel actual = this.supplierService.findSupplierById(supplier.getId());
        SupplierServiceModel expected = this.modelMapper.map(supplier,SupplierServiceModel.class);

       //Assert.assertEquals(expected,actual);
        compareSuppliers(actual, expected);
    }

    @Test(expected = Exception.class)
    public void supplierService_FindSupplierWithInvalidId_ThrowsException() {
        Supplier supplier = new Supplier();
        supplier.setName("Pesho");
        supplier.setImporter(true);

        supplier = this.supplierRepository.saveAndFlush(supplier);

        this.supplierService.findSupplierById("invalid");
    }
}
