package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.entities.Car;
import org.softuni.cardealer.domain.entities.Part;
import org.softuni.cardealer.domain.models.service.CarServiceModel;
import org.softuni.cardealer.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CarServiceTests {
    @Autowired
    private CarRepository carRepository;
    private ModelMapper modelMapper;
    private CarService  carService;

    @Before
    public void init() {
        this.modelMapper = new ModelMapper();
        this.carService = new CarServiceImpl(this.carRepository, this.modelMapper);

    }

    private void compareCars(CarServiceModel actual, CarServiceModel expected) {
        Assert.assertEquals(expected.getId(),actual.getId());
        Assert.assertEquals(expected.getModel(),actual.getModel());
        Assert.assertEquals(expected.getMake(),actual.getMake());
        Assert.assertEquals(expected.getTravelledDistance(),actual.getTravelledDistance());
        Assert.assertEquals(expected.getParts(),actual.getParts());
    }

    private Car createCar() {
        Car car = new Car();
        car.setModel("Audi");
        car.setMake("Germany");
        car.setTravelledDistance(1000L);
        car.setParts(new ArrayList<>());

        return car;
    }
    @Test
    public void carService_saveCarWithCorrectValues_Returns_Correct() {

        CarServiceModel toBeSaved = this.modelMapper.map(createCar(),CarServiceModel.class);

        CarServiceModel actual = this.carService.saveCar(toBeSaved);
        CarServiceModel expected = this.modelMapper.map(
                this.carRepository.findAll().get(0), CarServiceModel.class);

        compareCars(actual, expected);

    }

    @Test(expected = Exception.class)
    public void carService_saveCarWithNullValues_ThrowsException() {

        CarServiceModel toBeSaved = this.modelMapper.map(createCar(),CarServiceModel.class);

        toBeSaved.setModel(null);

        this.carService.saveCar(toBeSaved);
    }

    @Test
    public void  carService_editCarWithCorrectValues_ReturnsCorrect(){
         Car car = createCar();
        car = this.carRepository.saveAndFlush(car);

        CarServiceModel toBeEdited = new CarServiceModel();
        toBeEdited.setId(car.getId());
        toBeEdited.setModel("Mercedes");
        toBeEdited.setMake("BG");
        toBeEdited.setTravelledDistance(1001L);

        CarServiceModel actual = this.carService.editCar(toBeEdited);
        CarServiceModel expected = this.modelMapper.map(
                this.carRepository.findAll().get(0), CarServiceModel.class
        );

        compareCars(actual, expected);
    }

    @Test(expected = Exception.class)
    public void  carService_editCarWithNullValues_ThrowsException() {
        Car car = createCar();
        car = this.carRepository.saveAndFlush(car);

        CarServiceModel toBeEdited = new CarServiceModel();
        toBeEdited.setId(car.getId());

        CarServiceModel actual = this.carService.editCar(toBeEdited);
    }

    @Test
    public void  carService_DeleteCarWithValidId_ReturnCorrect(){

        Car car = createCar();
        car = this.carRepository.saveAndFlush(car);

        this.carService.deleteCar(car.getId());
        long expectedCount=0L;
        long actualCount = this.carRepository.count();

        Assert.assertEquals(expectedCount,actualCount);
    }

    @Test(expected=Exception.class)
    public void carService_DeleteCarWithInalidId_ThrowsException() {

        Car car = createCar();
        car = this.carRepository.saveAndFlush(car);

        this.carService.deleteCar("invalid");

    }

    @Test
    public void  carService_FindCarWithValidId_ReturnsCorrect(){

        Car car = createCar();
        car = this.carRepository.saveAndFlush(car);

        CarServiceModel actual = this.carService.findCarById(car.getId());
        CarServiceModel expected = this.modelMapper.map(car,CarServiceModel.class);

        compareCars(actual, expected);
    }

    @Test(expected = Exception.class)
    public void  carService_FindCarWithInvalidId_ThrowsException() {

        Car car = createCar();
        car = this.carRepository.saveAndFlush(car);

        this.carService.findCarById("invalid");
    }

}
