package org.softuni.cardealer;

public class asd {
}
