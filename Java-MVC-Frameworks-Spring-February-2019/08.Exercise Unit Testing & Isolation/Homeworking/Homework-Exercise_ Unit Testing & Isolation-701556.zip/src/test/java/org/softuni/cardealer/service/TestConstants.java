package org.softuni.cardealer.service;

public class TestConstants {
    public static final String INVALID_ID="invalid_id";
}
