package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.entities.*;
import org.softuni.cardealer.domain.models.service.CarSaleServiceModel;
import org.softuni.cardealer.domain.models.service.PartSaleServiceModel;
import org.softuni.cardealer.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.time.LocalDate;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class SaleServiceTests {

    @Autowired
    private CarSaleRepository carSaleRepository;
    @Autowired
    private PartSaleRepository partSaleRepository;
    private ModelMapper modelMapper;
    private SaleService saleService;

    private CarSaleServiceModel carSaleServiceModel;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private CarRepository carRepository;

    @Autowired
    private PartRepository partRepository;

    @Before
    public void init(){
        this.modelMapper=new ModelMapper();
        this.saleService=new SaleServiceImpl(this.carSaleRepository,this.partSaleRepository,this.modelMapper);
    }

    @Test
    public void saleService_saveCarSale_WithCorrectValues(){
        CarSale carSale=new CarSale();
        carSale.setDiscount(20.50);
        carSale.setCar(this.initCar());
        carSale.setCustomer(this.initCustomer());

        CarSaleServiceModel carSaleToSave = this.modelMapper.map(carSale, CarSaleServiceModel.class);

        CarSaleServiceModel actual = this.saleService.saleCar(carSaleToSave);
        CarSaleServiceModel expected = this.modelMapper
                .map(this.carSaleRepository.findAll().get(0), CarSaleServiceModel.class);

        Assert.assertEquals(expected.getId(),actual.getId());
        Assert.assertEquals(expected.getDiscount(),actual.getDiscount());

        Assert.assertEquals(expected.getCar().getId(),actual.getCar().getId());
        Assert.assertEquals(expected.getCar().getTravelledDistance(),actual.getCar().getTravelledDistance());
        Assert.assertEquals(expected.getCar().getModel(),actual.getCar().getModel());
        Assert.assertEquals(expected.getCar().getMake(),actual.getCar().getMake());

        Assert.assertEquals(expected.getCustomer().getId(),actual.getCustomer().getId());
        Assert.assertEquals(expected.getCustomer().getBirthDate(),actual.getCustomer().getBirthDate());
        Assert.assertEquals(expected.getCustomer().getName(),actual.getCustomer().getName());
        Assert.assertEquals(expected.getCustomer().isYoungDriver(),actual.getCustomer().isYoungDriver());
    }

    @Test(expected = Exception.class)
    public void saleService_saveCarSale_WithNullValues(){
        this.saleService.saleCar(new CarSaleServiceModel());
    }

    @Test
    public void saleService_savePartSale_WithCorrectValues(){
        PartSale partSale=new PartSale();
        partSale.setDiscount(30.4);
        partSale.setQuantity(5);
        partSale.setCustomer(this.initCustomer());
        partSale.setPart(this.initPart());

        PartSaleServiceModel partToSave = this.modelMapper.map(partSale, PartSaleServiceModel.class);
        PartSaleServiceModel actual = this.saleService.salePart(partToSave);
        PartSaleServiceModel expected = this.modelMapper
                .map(this.partSaleRepository.findAll().get(0), PartSaleServiceModel.class);

        Assert.assertEquals(expected.getId(),actual.getId());
        Assert.assertEquals(expected.getDiscount(),actual.getDiscount());

        Assert.assertEquals(expected.getCustomer().getId(),actual.getCustomer().getId());
        Assert.assertEquals(expected.getCustomer().getBirthDate(),actual.getCustomer().getBirthDate());
        Assert.assertEquals(expected.getCustomer().getName(),actual.getCustomer().getName());
        Assert.assertEquals(expected.getCustomer().isYoungDriver(),actual.getCustomer().isYoungDriver());

        Assert.assertEquals(expected.getPart().getId(),actual.getPart().getId());
        Assert.assertEquals(expected.getPart().getPrice(),actual.getPart().getPrice());
        Assert.assertEquals(expected.getPart().getName(),actual.getPart().getName());
    }
    @Test(expected = Exception.class)
    public void saleService_savePartSale_WithNullValues(){
        this.saleService.salePart(new PartSaleServiceModel());
    }

    private Customer  initCustomer() {
        Customer customer=new Customer();
        customer.setName("Vancho");
        customer.setBirthDate(LocalDate.now());
        customer.setYoungDriver(true);
        return this.customerRepository.saveAndFlush(customer);
    }

    private Car initCar() {
        Car car=new Car();
        car.setMake("VW");
        car.setModel("Golf Vier");
        car.setTravelledDistance(100L);
        return this.carRepository.saveAndFlush(car);
    }
    private Part initPart() {
        Part part=new Part();
        part.setName("Wasserpumpe");
        part.setPrice(new BigDecimal("50.5"));
        return this.partRepository.saveAndFlush(part);
    }
}
