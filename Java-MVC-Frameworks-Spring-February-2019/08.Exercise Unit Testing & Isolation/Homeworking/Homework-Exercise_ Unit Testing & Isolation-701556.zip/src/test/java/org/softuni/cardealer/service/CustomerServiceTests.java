package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.entities.Customer;
import org.softuni.cardealer.domain.models.service.CustomerServiceModel;
import org.softuni.cardealer.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CustomerServiceTests {
    private final String SAMPLE_NAME="Go6ko";
    private final LocalDate SAMPLE_BIRTHDAY=LocalDate.now();

    @Autowired
    private CustomerRepository customerRepository;
    private ModelMapper modelMapper;

    private CustomerService customerService;
    private Customer customer;

    @Before
    public void init(){
        this.modelMapper=new ModelMapper();
        this.customerService=new CustomerServiceImpl(this.customerRepository,this.modelMapper);
        this.initCustomer();
    }

    private void initCustomer() {
        Customer customer=new Customer();
        customer.setName(SAMPLE_NAME);
        customer.setBirthDate(SAMPLE_BIRTHDAY);
        customer.setYoungDriver(true);
        this.customer=customer;
    }

    @Test
    public void customerService_saveCustomerWithCorrectData(){
        Customer customerToSave=this.customer;

        CustomerServiceModel actual = this.customerService.
                saveCustomer(this.modelMapper.map(customerToSave, CustomerServiceModel.class));

        CustomerServiceModel expected = this.modelMapper
                .map(this.customerRepository.findAll().get(0), CustomerServiceModel.class);

        Assert.assertEquals(expected.getId(),actual.getId());
        Assert.assertEquals(expected.getBirthDate(),actual.getBirthDate());
        Assert.assertEquals(expected.isYoungDriver(),actual.isYoungDriver());
    }

    @Test(expected = Exception.class)
    public void customerService_saveCustomerWithNullName(){
        Customer customerToSave=this.customer;
        customerToSave.setName(null);

        this.customerService.
                saveCustomer(this.modelMapper.map(customerToSave, CustomerServiceModel.class));
    }
    @Test(expected = Exception.class)
    public void customerService_saveCustomerWithNullBirthday(){
        Customer customerToSave=this.customer;
        customerToSave.setBirthDate(null);

        this.customerService.
                saveCustomer(this.modelMapper.map(customerToSave, CustomerServiceModel.class));
    }

    @Test
    public void customerService_editCustomerWithCorrectData(){
        Customer customerToSave=this.customer;

        customerToSave=this.customerRepository.save(customerToSave);

        CustomerServiceModel toEdit = this.modelMapper.map(customerToSave, CustomerServiceModel.class);
        LocalDate birthdayPlusOneDay = SAMPLE_BIRTHDAY.plusDays(1);

        toEdit.setName("Stoqn");
        toEdit.setBirthDate(birthdayPlusOneDay);
        toEdit.setYoungDriver(false);

        CustomerServiceModel actual = this.customerService.editCustomer(toEdit);

        CustomerServiceModel expected = this.modelMapper
                .map(this.customerRepository.findAll().get(0), CustomerServiceModel.class);

        Assert.assertEquals(expected.getId(),toEdit.getId());
        Assert.assertEquals(expected.getBirthDate(),toEdit.getBirthDate());
        Assert.assertEquals(expected.isYoungDriver(),toEdit.isYoungDriver());
    }

    @Test(expected = Exception.class)
    public void customerService_editCustomerWithNullData(){
        Customer customerToSave=this.customer;

        customerToSave=this.customerRepository.save(customerToSave);

        CustomerServiceModel toEdit = this.modelMapper.map(customerToSave, CustomerServiceModel.class);
        LocalDate birthdayPlusOneDay = SAMPLE_BIRTHDAY.plusDays(1);

        toEdit.setName(null);
        toEdit.setBirthDate(null);

        this.customerService.editCustomer(toEdit);
    }

    @Test
    public void customerService_deleteCustomerWithCorrectId(){
        Customer customerToSave=this.customerRepository.save(this.customer);

        CustomerServiceModel toDelete = this.modelMapper.map(customerToSave, CustomerServiceModel.class);
        CustomerServiceModel actual = this.customerService.deleteCustomer(toDelete.getId());

        Assert.assertEquals(customerToSave.getId(),actual.getId());
        Assert.assertEquals(customerToSave.getName(),actual.getName());
        Assert.assertEquals(customerToSave.isYoungDriver(),actual.isYoungDriver());

        Assert.assertEquals(this.customerRepository.count(),0L);
    }

    @Test(expected = Exception.class)
    public void customerService_deleteCustomerWithIncorrectId(){
       this.customerService.deleteCustomer(TestConstants.INVALID_ID);
    }

    @Test
    public void customerService_findCustomerWithCorrectId(){
        Customer customerToSave=this.customerRepository.save(this.customer);

        CustomerServiceModel actual = this.customerService.findCustomerById(customerToSave.getId());
        CustomerServiceModel expected = this.modelMapper.map(this.customerRepository.findAll().get(0), CustomerServiceModel.class);

        Assert.assertEquals(customerToSave.getId(),actual.getId());
        Assert.assertEquals(customerToSave.getName(),actual.getName());
        Assert.assertEquals(customerToSave.isYoungDriver(),actual.isYoungDriver());
    }

    @Test(expected = Exception.class)
    public void customerService_findCustomerWithIncorrectId(){
        this.customerService.findCustomerById(TestConstants.INVALID_ID);
    }

}
