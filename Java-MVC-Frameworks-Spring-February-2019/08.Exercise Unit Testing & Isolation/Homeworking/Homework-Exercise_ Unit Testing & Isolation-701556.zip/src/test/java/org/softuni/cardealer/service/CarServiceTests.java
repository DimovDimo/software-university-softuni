package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.entities.Car;
import org.softuni.cardealer.domain.models.service.CarServiceModel;
import org.softuni.cardealer.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CarServiceTests {
    @Autowired
    private CarRepository carRepository;
    private ModelMapper modelMapper;

    private CarService carService;
    private CarServiceModel car;

    @Before
    public void init(){
        this.modelMapper=new ModelMapper();
        this.carService=new CarServiceImpl(this.carRepository,this.modelMapper);
        this.initCar();
    }

    private void initCar() {
        CarServiceModel car=new CarServiceModel();
        car.setMake("VW");
        car.setModel("Golf Vier");
        car.setTravelledDistance(100L);
        this.car=car;
    }

    @Test
    public void carService_saveCarWithCorrectData(){
        CarServiceModel carToSave = this.car;
        CarServiceModel actual = this.carService.saveCar(carToSave);

        CarServiceModel expected = this.modelMapper.map(this.carRepository.findAll().get(0), CarServiceModel.class);

        Assert.assertEquals(expected.getId(),actual.getId());
        Assert.assertEquals(expected.getMake(),actual.getMake());
        Assert.assertEquals(expected.getModel(),actual.getModel());
        Assert.assertEquals(expected.getTravelledDistance(),actual.getTravelledDistance());
    }

    @Test(expected = Exception.class)
    public void carService_saveCarWithNullMake(){
        CarServiceModel carToSave = this.car;
        carToSave.setMake(null);
        this.carService.saveCar(carToSave);
    }
    @Test(expected = Exception.class)
    public void carService_saveCarWithNullModel(){
        CarServiceModel carToSave = this.car;
        carToSave.setModel(null);
        this.carService.saveCar(carToSave);
    }
    @Test(expected = Exception.class)
    public void carService_saveCarWithNullDistance(){
        CarServiceModel carToSave = this.car;
        carToSave.setTravelledDistance(null);
        this.carService.saveCar(carToSave);
    }

    @Test
    public void carService_editCarWithCorrectData(){
        Car savedCar = this.carRepository.saveAndFlush(this.modelMapper.map(this.car, Car.class));
        CarServiceModel carToEdit = this.modelMapper.map(savedCar, CarServiceModel.class);

        carToEdit.setMake("Audi");
        carToEdit.setModel("A3");
        carToEdit.setTravelledDistance(200L);

        CarServiceModel actual = this.carService.editCar(carToEdit);

        CarServiceModel expected = this.modelMapper.map(this.carRepository.findAll().get(0), CarServiceModel.class);

        Assert.assertEquals(expected.getId(),actual.getId());
        Assert.assertEquals(expected.getMake(),actual.getMake());
        Assert.assertEquals(expected.getModel(),actual.getModel());
        Assert.assertEquals(expected.getTravelledDistance(),actual.getTravelledDistance());
    }

    @Test(expected = Exception.class)
    public void carService_editCarWithNullData(){
        CarServiceModel carToEdit = this.modelMapper.map(new Car(), CarServiceModel.class);
        this.carService.editCar(carToEdit);
    }

    @Test
    public void carService_deleteCarWithCorrectId(){
        Car savedCar = this.carRepository.saveAndFlush(this.modelMapper.map(this.car, Car.class));
        CarServiceModel carToDel = this.modelMapper.map(savedCar, CarServiceModel.class);

        CarServiceModel actual = this.carService.deleteCar(carToDel.getId());

        Assert.assertEquals(carToDel.getId(),actual.getId());
        Assert.assertEquals(carToDel.getMake(),actual.getMake());
        Assert.assertEquals(carToDel.getModel(),actual.getModel());
        Assert.assertEquals(carToDel.getTravelledDistance(),actual.getTravelledDistance());

        Assert.assertEquals(this.carRepository.count(),0);
    }

    @Test(expected = Exception.class)
    public void carService_deleteCarWithIncorrectId(){
        this.carService.deleteCar(TestConstants.INVALID_ID);
    }

    @Test
    public void carService_findCarWithCorrectId(){
        Car savedCar = this.carRepository.saveAndFlush(this.modelMapper.map(this.car, Car.class));

        CarServiceModel actual = this.carService.findCarById(savedCar.getId());
        CarServiceModel expected = this.modelMapper.map(this.carRepository.findAll().get(0), CarServiceModel.class);

        Assert.assertEquals(expected.getId(),actual.getId());
        Assert.assertEquals(expected.getMake(),actual.getMake());
        Assert.assertEquals(expected.getModel(),actual.getModel());
        Assert.assertEquals(expected.getTravelledDistance(),actual.getTravelledDistance());
    }

    @Test(expected = Exception.class)
    public void carService_findCarWithIncorrectId(){
        this.carService.findCarById(TestConstants.INVALID_ID);
    }


}
