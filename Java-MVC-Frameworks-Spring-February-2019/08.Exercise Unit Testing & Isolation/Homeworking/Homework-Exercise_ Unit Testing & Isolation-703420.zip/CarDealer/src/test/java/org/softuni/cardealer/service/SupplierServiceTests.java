package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.models.service.SupplierServiceModel;
import org.softuni.cardealer.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;


import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class SupplierServiceTests {

    @Autowired
    private SupplierRepository supplierRepository;

    private ModelMapper modelMapper;

    private SupplierService supplierService;

    @Before
    public void init(){
        this.modelMapper=new ModelMapper();
        this.supplierService = new SupplierServiceImpl(this.supplierRepository, this.modelMapper);
    }

    @Test
    public void supplierService_saveSupplierWithCorrectValues_ReturnsCorrect(){

        SupplierServiceModel toBeSaved = new SupplierServiceModel();
        toBeSaved.setName("Vlado");
        toBeSaved.setImporter(true);

        SupplierServiceModel actual = supplierService.saveSupplier(toBeSaved);
        SupplierServiceModel expected =
                this.modelMapper.map(this.supplierRepository.findAll().get(0),SupplierServiceModel.class);

        Assert.assertEquals(expected.getId(), actual.getId());
        Assert.assertEquals(expected.getName(), actual.getName());
        Assert.assertEquals(expected.isImporter(), actual.isImporter());
    }

    @Test(expected = Exception.class)
    public void supplierService_saveSupplierWithNullValues_ThrowsException(){

        SupplierServiceModel toBeSaved = new SupplierServiceModel();
        toBeSaved.setName(null);
        toBeSaved.setImporter(true);
        this.supplierService.saveSupplier(toBeSaved);
    }

    @Test
    public void supplierService_findSupplierById_withCorrectValues_returnsCorrect(){
        SupplierServiceModel toBeSaved1 = new SupplierServiceModel();
        toBeSaved1.setName("Vlado");
        toBeSaved1.setImporter(true);
        SupplierServiceModel expected = supplierService.saveSupplier(toBeSaved1);


        SupplierServiceModel actual = this.supplierService.findSupplierById(expected.getId());

        Assert.assertEquals(expected.getId(), actual.getId());
        Assert.assertEquals(expected.getName(), actual.getName());
        Assert.assertEquals(expected.isImporter(), actual.isImporter());
    }

    @Test(expected = Exception.class)
    public void supplierService_findSupplierById_withNonExistingValues_throwsException(){
        SupplierServiceModel toBeSaved = new SupplierServiceModel();
        toBeSaved.setName("Vlado");
        toBeSaved.setImporter(true);

        SupplierServiceModel test = supplierService.saveSupplier(toBeSaved);

        SupplierServiceModel expected = this.supplierService.findSupplierById("NoSuchId");
    }

    @Test
    public void supplierService_editSupplier_withCorrectValues_returnsCorrect(){
        SupplierServiceModel toBeSaved = new SupplierServiceModel();
        toBeSaved.setName("Vlado");
        toBeSaved.setImporter(true);

        SupplierServiceModel expected = supplierService.saveSupplier(toBeSaved);

        expected.setName("Pesho");
        expected.setImporter(false);

        supplierService.editSupplier(expected);

        SupplierServiceModel actual = this.supplierService.findSupplierById(expected.getId());

        Assert.assertEquals(expected.getId(), actual.getId());
        Assert.assertEquals(expected.getName(), actual.getName());
        Assert.assertEquals(expected.isImporter(), actual.isImporter());
    }

    @Test(expected = Exception.class)
    public void supplierService_editSupplier_withInvalidValues_throwsException(){
        SupplierServiceModel toBeSaved = new SupplierServiceModel();
        toBeSaved.setName("Vlado");
        toBeSaved.setImporter(true);

        SupplierServiceModel expected = supplierService.saveSupplier(toBeSaved);

        expected.setName(null);
        expected.setImporter(false);

        supplierService.editSupplier(expected);
    }

    @Test(expected = Exception.class)
    public void supplierService_deleteSupplierById_withCorrectValues_returnsCorrect(){
        SupplierServiceModel toBeSaved = new SupplierServiceModel();
        toBeSaved.setName("Vlado");
        toBeSaved.setImporter(true);
        SupplierServiceModel expected = supplierService.saveSupplier(toBeSaved);
        this.supplierService.deleteSupplier(expected.getId());

        SupplierServiceModel actual = this.supplierService.findSupplierById(expected.getId());
    }
}
