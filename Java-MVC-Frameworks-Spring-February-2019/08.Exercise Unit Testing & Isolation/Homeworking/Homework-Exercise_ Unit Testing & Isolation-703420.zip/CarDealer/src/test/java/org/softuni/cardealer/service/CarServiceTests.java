package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.models.service.CarServiceModel;
import org.softuni.cardealer.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CarServiceTests {

    @Autowired
    private CarRepository carRepository;

    private ModelMapper modelMapper;

    private CarService carService;

    @Before
    public void init(){
        this.modelMapper=new ModelMapper();
        this.carService = new CarServiceImpl(this.carRepository, this.modelMapper);
    }

    @Test
    public void carService_saveCarWithCorrectValues_ReturnsCorrect(){
        CarServiceModel actual = new CarServiceModel();
        actual.setMake("Opel");
        actual.setModel("Astra");
        actual.setTravelledDistance(200L);

        CarServiceModel expected = this.carService.saveCar(actual);

        Assert.assertEquals(expected.getMake(), actual.getMake());
        Assert.assertEquals(expected.getModel(), actual.getModel());
        Assert.assertEquals(expected.getTravelledDistance(), actual.getTravelledDistance());
    }

    @Test(expected = Exception.class)
    public void carService_saveCarWithInvalidValues_TrowsException(){
        CarServiceModel actual = new CarServiceModel();
        actual.setMake("Opel");
        actual.setModel("Astra");
        actual.setTravelledDistance(200L);

        CarServiceModel invalidCar = this.carService.saveCar(actual);

        invalidCar.setMake(null);

        this.carService.saveCar(invalidCar);
    }

    @Test
    public void carService_findByIdWithCorrectValues_ReturnsCorrect(){
        CarServiceModel toBeSaved = new CarServiceModel();
        toBeSaved.setMake("Opel");
        toBeSaved.setModel("Astra");
        toBeSaved.setTravelledDistance(200L);

        CarServiceModel expected = this.carService.saveCar(toBeSaved);

        CarServiceModel actual = this.carService.findCarById(expected.getId());

        Assert.assertEquals(expected.getMake(), actual.getMake());
        Assert.assertEquals(expected.getModel(), actual.getModel());
        Assert.assertEquals(expected.getTravelledDistance(), actual.getTravelledDistance());
    }

    @Test(expected = Exception.class)
    public void carService_findByIdWithNonExistingValues_throwsException(){
        CarServiceModel toBeSaved = new CarServiceModel();
        toBeSaved.setMake("Opel");
        toBeSaved.setModel("Astra");
        toBeSaved.setTravelledDistance(200L);

        CarServiceModel expected = this.carService.saveCar(toBeSaved);

        CarServiceModel actual = this.carService.findCarById("NoSuchId");
    }

    @Test
    public void carService_editCarWithCorrectValues_ReturnsCorrect(){
        CarServiceModel toBeSaved = new CarServiceModel();
        toBeSaved.setMake("Opel");
        toBeSaved.setModel("Astra");
        toBeSaved.setTravelledDistance(200L);

        CarServiceModel expected = this.carService.saveCar(toBeSaved);

        expected.setMake("BMV");
        expected.setModel("X5");
        expected.setTravelledDistance(1000L);

        this.carService.editCar(expected);

        CarServiceModel actual = this.carService.findCarById(expected.getId());

        Assert.assertEquals(expected.getMake(), actual.getMake());
        Assert.assertEquals(expected.getModel(), actual.getModel());
        Assert.assertEquals(expected.getTravelledDistance(), actual.getTravelledDistance());
    }

    @Test(expected = Exception.class)
    public void carService_editWithInvalidValues_TrowsException(){
        CarServiceModel actual = new CarServiceModel();
        actual.setMake("Opel");
        actual.setModel("Astra");
        actual.setTravelledDistance(200L);

        CarServiceModel invalidCar = this.carService.saveCar(actual);

        invalidCar.setMake(null);

        this.carService.editCar(invalidCar);
    }

    @Test(expected = Exception.class)
    public void carService_deleteCarInvalidValues_TrowsException(){
        CarServiceModel actual = new CarServiceModel();
        actual.setMake("Opel");
        actual.setModel("Astra");
        actual.setTravelledDistance(200L);

        CarServiceModel invalidCar = this.carService.saveCar(actual);


        this.carService.deleteCar("No such id");
    }

    @Test
    public void carService_deleteCarWithCorrectValues_returnsCorrect(){
        CarServiceModel actual = new CarServiceModel();
        actual.setMake("Opel");
        actual.setModel("Astra");
        actual.setTravelledDistance(200L);

        CarServiceModel invalidCar = this.carService.saveCar(actual);

        Assert.assertEquals(this.carRepository.findAll().size(),1);

        this.carService.deleteCar(invalidCar.getId());

        Assert.assertEquals(this.carRepository.findAll().size(),0);
    }
}
