package org.softuni.cardealer.service;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.entities.Supplier;
import org.softuni.cardealer.domain.models.service.PartServiceModel;
import org.softuni.cardealer.domain.models.service.SupplierServiceModel;
import org.softuni.cardealer.repository.PartRepository;
import org.softuni.cardealer.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class PartServiceTests {

    private ModelMapper modelMapper;

    @Autowired
    private PartRepository partRepository;

    @Autowired
    private SupplierRepository supplierRepository;

    private PartService partService;

    @Before
    public void init(){
        this.modelMapper=new ModelMapper();
        this.partService = new PartServiceImpl(this.partRepository, this.modelMapper);
    }

    @Test
    public void partService_savePartWithCorrectValues_returnsCorrect(){
        Supplier supplier = new Supplier();
        supplier.setImporter(true);
        supplier.setName("Vlado");
        supplier = this.supplierRepository.save(supplier);

        PartServiceModel part = new PartServiceModel();
        part.setName("Engine");
        part.setPrice(BigDecimal.TEN);
        part.setSupplier(this.modelMapper.map(supplier, SupplierServiceModel.class));

        PartServiceModel actual = this.partService.savePart(part);

        Assert.assertEquals(part.getName(),actual.getName());
        Assert.assertEquals(part.getPrice(),actual.getPrice());
    }

    @Test(expected = Exception.class)
    public void partService_savePartWithInvalidValues_throwsException(){
        PartServiceModel part = new PartServiceModel();
        part.setPrice(BigDecimal.TEN);

        PartServiceModel actual = this.partService.savePart(part);
    }

    @Test
    public void partService_editWithCorrectValues_returnsCorrect(){
        Supplier supplier = new Supplier();
        supplier.setImporter(true);
        supplier.setName("Vlado");
        supplier = this.supplierRepository.save(supplier);

        PartServiceModel part = new PartServiceModel();
        part.setName("Engine");
        part.setPrice(BigDecimal.TEN);
        part.setSupplier(this.modelMapper.map(supplier, SupplierServiceModel.class));

        PartServiceModel actual = this.partService.savePart(part);

        actual.setName("Tyre");

        PartServiceModel expected = this.partService.editPart(actual);

        Assert.assertEquals(actual.getName(),expected.getName());
    }

    @Test(expected = Exception.class)
    public void partService_editWithInvalidValues_throwsException(){
        Supplier supplier = new Supplier();
        supplier.setImporter(true);
        supplier.setName("Vlado");
        supplier = this.supplierRepository.save(supplier);

        PartServiceModel part = new PartServiceModel();
        part.setName("Engine");
        part.setPrice(BigDecimal.TEN);
        part.setSupplier(this.modelMapper.map(supplier, SupplierServiceModel.class));

        PartServiceModel actual = this.partService.savePart(part);

        actual.setName(null);

        PartServiceModel expected = this.partService.savePart(actual);
    }

    @Test
    public void partService_deletePartWithCorrectValues_returnsCorrect(){
        Supplier supplier = new Supplier();
        supplier.setImporter(true);
        supplier.setName("Vlado");
        supplier = this.supplierRepository.save(supplier);

        PartServiceModel part = new PartServiceModel();
        part.setName("Engine");
        part.setPrice(BigDecimal.TEN);
        part.setSupplier(this.modelMapper.map(supplier, SupplierServiceModel.class));

        PartServiceModel actual = this.partService.savePart(part);

        Assert.assertEquals(this.partRepository.findAll().size(),1);

        this.partService.deletePart(actual.getId());

        Assert.assertEquals(this.partRepository.findAll().size(),0);
    }

    @Test
    public void partService_findByIdWithCorrectValues_returnsCorrect(){
        Supplier supplier = new Supplier();
        supplier.setImporter(true);
        supplier.setName("Vlado");
        supplier = this.supplierRepository.save(supplier);

        PartServiceModel part = new PartServiceModel();
        part.setName("Engine");
        part.setPrice(BigDecimal.TEN);
        part.setSupplier(this.modelMapper.map(supplier, SupplierServiceModel.class));

        PartServiceModel expected = this.partService.savePart(part);

        PartServiceModel actual = this.partService.findPartById(expected.getId());



        Assert.assertEquals(expected.getName(),actual.getName());
        Assert.assertEquals(expected.getPrice(),actual.getPrice());
    }


}
