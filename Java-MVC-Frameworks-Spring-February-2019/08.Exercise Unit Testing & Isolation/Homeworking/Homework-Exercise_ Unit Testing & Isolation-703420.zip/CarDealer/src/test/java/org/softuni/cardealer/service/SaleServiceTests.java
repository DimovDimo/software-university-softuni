package org.softuni.cardealer.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.softuni.cardealer.domain.entities.Car;
import org.softuni.cardealer.domain.entities.Customer;
import org.softuni.cardealer.domain.entities.Part;
import org.softuni.cardealer.domain.entities.Supplier;
import org.softuni.cardealer.domain.models.service.*;
import org.softuni.cardealer.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.time.LocalDate;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class SaleServiceTests {

    private ModelMapper modelMapper;

    @Autowired
    private CarSaleRepository carSaleRepository;

    @Autowired
    private PartSaleRepository partSaleRepository;
    @Autowired
    private CarRepository carRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private SupplierRepository supplierRepository;

    @Autowired
    private PartRepository partRepository;

    private SaleService saleService;

    @Before
    public void init(){
        this.modelMapper=new ModelMapper();
        this.saleService = new SaleServiceImpl(this.carSaleRepository, this.partSaleRepository,this.modelMapper);
    }

    @Test
    public void saleService_saleCarCorrectValues_ReturnsCorrect(){

        CarSaleServiceModel toBeSaved = new CarSaleServiceModel();

        CarServiceModel car = new CarServiceModel();
        car.setModel("Astra");
        car.setMake("Opel");
        car.setTravelledDistance(100L);

        car = this.modelMapper.map(this.carRepository.save(
                this.modelMapper.map(car, Car.class)),
                CarServiceModel.class);

        toBeSaved.setDiscount(0.2);
        toBeSaved.setCar(car);

        Customer customer = new Customer();

        customer.setName("Vlado");
        customer.setYoungDriver(false);
        customer.setBirthDate(LocalDate.now());

        customer = this.customerRepository.save(customer);

        toBeSaved.setCustomer(this.modelMapper.map(customer, CustomerServiceModel.class));

        CarSaleServiceModel actual = this.saleService.saleCar(toBeSaved);

        Assert.assertEquals(toBeSaved.getCar().getModel(), actual.getCar().getModel());
        Assert.assertEquals(toBeSaved.getCar().getMake(), actual.getCar().getMake());
        Assert.assertEquals(toBeSaved.getCar().getTravelledDistance(), actual.getCar().getTravelledDistance());
    }

    @Test(expected = Exception.class)
    public void saleService_saleCarWithInvalidValues_throwsException(){
        CarSaleServiceModel toBeSaved = new CarSaleServiceModel();


        CarSaleServiceModel actual = this.saleService.saleCar(toBeSaved);
    }

    @Test
    public void saleService_salePartWithCorrectValues_ReturnsCorrect(){
        Supplier supplier = new Supplier();
        supplier.setName("Vlado");
        supplier.setImporter(true);
        supplier = this.supplierRepository.save(supplier);

        Part part = new Part();
        part.setPrice(BigDecimal.TEN);
        part.setSupplier(supplier);
        part.setName("Engine");
        part = this.partRepository.save(part);

        PartSaleServiceModel partSaleServiceModel = new PartSaleServiceModel();

        partSaleServiceModel.setPart(this.modelMapper.map(part, PartServiceModel.class));
        partSaleServiceModel.setQuantity(20);
        partSaleServiceModel.setDiscount(0.2);

        Customer customer = new Customer();

        customer.setName("Vlado");
        customer.setYoungDriver(false);
        customer.setBirthDate(LocalDate.now());

        customer = this.customerRepository.save(customer);

        partSaleServiceModel.setCustomer(this.modelMapper.map(customer,CustomerServiceModel.class));


        partSaleServiceModel=this.saleService.salePart(partSaleServiceModel);

        Assert.assertEquals(partSaleServiceModel.getQuantity(),Integer.valueOf(20));
    }

    @Test(expected = Exception.class)
    public void saleService_salePartWithInvalidValues_throwsException(){

        PartSaleServiceModel partSaleServiceModel = new PartSaleServiceModel();
        partSaleServiceModel.setQuantity(20);

        partSaleServiceModel=this.saleService.salePart(partSaleServiceModel);
    }

}
