package resident_evil.app.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;
import resident_evil.app.service.VirusService;

@Controller
public class MapController {

    @Autowired
    private VirusService virusService;

    @GetMapping("/map")
    public ModelAndView map(ModelAndView modelAndView) {
        String geoJson = this.virusService.getGeoData();

        modelAndView.addObject("geoJson", geoJson);

        modelAndView.setViewName("map");
        return modelAndView;
    }
}
