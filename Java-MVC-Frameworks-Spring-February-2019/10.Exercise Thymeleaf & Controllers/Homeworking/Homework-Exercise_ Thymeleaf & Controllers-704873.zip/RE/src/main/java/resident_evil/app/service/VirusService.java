package resident_evil.app.service;

import resident_evil.app.domain.model.service.VirusServiceModel;

import java.util.List;

public interface VirusService {

    VirusServiceModel saveVirus(VirusServiceModel virusServiceModel);

    List<VirusServiceModel> getAllViruses();

    VirusServiceModel getVirusById(int id);

    VirusServiceModel editVirusById(VirusServiceModel virusServiceModel);

    void removeVirusById(int id);

    String getGeoData();
}
