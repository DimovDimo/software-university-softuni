package resident_evil.app.web.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import resident_evil.app.domain.model.binding.VirusAddBindingModel;
import resident_evil.app.domain.model.binding.VirusEditBindingModel;
import resident_evil.app.domain.model.service.VirusServiceModel;
import resident_evil.app.domain.model.view.AllVirusesViewModel;
import resident_evil.app.domain.model.view.CapitalListViewModel;
import resident_evil.app.domain.model.view.EditVirusViewModel;
import resident_evil.app.service.CapitalService;
import resident_evil.app.service.VirusService;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/viruses")
public class VirusController extends BaseController {

    private final CapitalService capitalService;
    private final VirusService virusService;
    private final ModelMapper modelMapper;

    @Autowired
    public VirusController(CapitalService capitalService, VirusService virusService, ModelMapper modelMapper) {
        this.capitalService = capitalService;
        this.virusService = virusService;
        this.modelMapper = modelMapper;
    }
    //TODO going through base controller might cause thymeleaf to struggle finding the binding model

    private ModelAndView addCapitalList(ModelAndView modelAndView) {
        List<CapitalListViewModel> capitals = this.capitalService.findAllCapitals()
                .stream()
                .map(csm -> this.modelMapper.map(csm, CapitalListViewModel.class))
                .collect(Collectors.toList());
        modelAndView.addObject("capitals", capitals);
        return modelAndView;
    }

    @GetMapping("/add")
    public ModelAndView add(@ModelAttribute VirusAddBindingModel bindingModel, ModelAndView modelAndView) {
        modelAndView.addObject("bindingModel", bindingModel);

        modelAndView = addCapitalList(modelAndView);

        return super.view("add-virus", modelAndView);
    }

    @PostMapping("/add")
    public ModelAndView addConfirm(@Valid @ModelAttribute(name = "bindingModel") VirusAddBindingModel bindingModel,
                                   BindingResult bindingResult, ModelAndView modelAndView) {

        if (bindingResult.hasErrors()) {
            modelAndView.addObject("bindingModel", bindingModel);
            modelAndView = addCapitalList(modelAndView);

            return super.view("add-virus", modelAndView);
        }

        VirusServiceModel virusServiceModel = this.modelMapper
                .map(bindingModel, VirusServiceModel.class);
        this.virusService.saveVirus(virusServiceModel);

        return super.redirect("/");
    }

    @GetMapping("/show")
    public ModelAndView show(ModelAndView modelAndView) {
        List<AllVirusesViewModel> viruses
                = this.virusService.getAllViruses()
                .stream()
                .map(virusServiceModel -> this.modelMapper.map(virusServiceModel, AllVirusesViewModel.class))
                .collect(Collectors.toList());

        modelAndView.addObject("viruses", viruses);

        return super.view("show-virus", modelAndView);
    }

    @GetMapping("/edit/{id}")
    public ModelAndView edit(ModelAndView modelAndView, @PathVariable("id") int id) {
        EditVirusViewModel editVirusViewModel = this.modelMapper
                .map(this.virusService.getVirusById(id), EditVirusViewModel.class);

        if (editVirusViewModel == null) {
            return super.redirect("/");
        }

        modelAndView.addObject("virusEdit", editVirusViewModel);
        modelAndView = addCapitalList(modelAndView);

        return super.view("edit-virus", modelAndView);
    }

    @PostMapping("/edit/{id}")
    public ModelAndView editConfirm(
            @Valid @ModelAttribute(name = "editBindingModel") VirusEditBindingModel bindingModel,
            BindingResult bindingResult, ModelAndView modelAndView, @PathVariable("id") int id) {

        if (bindingResult.hasErrors()) {
            modelAndView.addObject("editBindingModel", bindingModel);
            modelAndView = addCapitalList(modelAndView);

            return super.view("edit-virus", modelAndView);
        }

        VirusServiceModel virusServiceModel = this.modelMapper
                .map(bindingModel, VirusServiceModel.class);
        virusServiceModel.setId(id);
        this.virusService.editVirusById(virusServiceModel);

        return super.redirect("/viruses/show");
    }

    @GetMapping("/delete/{id}")
    public ModelAndView delete(ModelAndView modelAndView, @PathVariable("id") int id) {
        VirusServiceModel virusServiceModel = this.virusService.getVirusById(id);
        if (virusServiceModel == null) {
            return super.view("/", modelAndView);
        }

        this.virusService.removeVirusById(id);

        return super.redirect("/viruses/show");
    }
}
