package resident_evil.app.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import resident_evil.app.domain.entity.Capital;
import resident_evil.app.domain.entity.Virus;
import resident_evil.app.domain.model.service.VirusServiceModel;
import resident_evil.app.repository.VirusRepository;

import javax.transaction.Transactional;
import java.text.MessageFormat;
import java.util.Date;
import java.util.List;
import java.util.StringJoiner;
import java.util.stream.Collectors;

@Service
public class VirusServiceImpl implements VirusService {

    private final VirusRepository virusRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public VirusServiceImpl(VirusRepository virusRepository, ModelMapper modelMapper) {
        this.virusRepository = virusRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public VirusServiceModel saveVirus(VirusServiceModel virusServiceModel) {
        Virus virus = this.modelMapper.map(virusServiceModel, Virus.class);
        virus = this.virusRepository.saveAndFlush(virus);
        return this.modelMapper.map(virus, VirusServiceModel.class);
    }

    @Override
    public List<VirusServiceModel> getAllViruses() {
        return this.virusRepository.findAll()
                .stream()
                .map(virus -> this.modelMapper.map(virus, VirusServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public VirusServiceModel getVirusById(int id) {
        Virus virus = this.virusRepository.findById(id).orElse(null);
        return this.modelMapper.map(virus, VirusServiceModel.class);
    }

    @Override
    public VirusServiceModel editVirusById(VirusServiceModel virusServiceModel) {
        Virus virus = this.virusRepository.findById(virusServiceModel.getId()).orElse(null);
        if (virus == null) {
            return null;
        }
        Date date = virus.getReleasedOn();
        virus = this.modelMapper.map(virusServiceModel, Virus.class);
        virus.setReleasedOn(date);
        this.virusRepository.saveAndFlush(virus);
        return this.modelMapper.map(virus, VirusServiceModel.class);
    }

    @Override
    public void removeVirusById(int id) {
        this.virusRepository.deleteById(id);
    }

    @Transactional
    @Override
    public String getGeoData() {
        List<Virus> viruses = this.virusRepository.findAll();

        StringBuilder jsonBuilder = new StringBuilder();
        String header = "{\n" +
                "      \"type\": \"FeatureCollection\",\n" +
                "      \"features\": [\n";
        String footer = "]\n" +
                "}\n";
        jsonBuilder.append(header);
        StringJoiner joiner = new StringJoiner(",");
        for (Virus virus : viruses) {
            String color = "#f00";
            int magnitude = 0;
            switch (virus.getMagnitude()) {
                case Low:
                    magnitude = 2;
                    break;
                case Medium:
                    magnitude = 4;
                    break;
                case High:
                    magnitude = 6;
                    break;
            }

            for (Capital capital : virus.getCapitals()) {
                String body = String.format("{\n" +
                        "      \"type\": \"Feature\",\n" +
                        "      \"properties\": {\n" +
                        "              \"mag\": %d,\n" +
                        "              \"color\": \"%s\"\n" +
                        "      },\n" +
                        "      \"geometry\": [\n" +
                        "              \"type\": \"Point\",\n" +
                        "              \"coordinates\": {\n" +
                        "                      %f,\n" +
                        "                      %f\n" +
                        "              ]\n" +
                        "      }\n" +
                        "}",
                        magnitude, color, capital.getLatitude(), capital.getLongitude());
                joiner.add(body);
            }
        }
        jsonBuilder.append(joiner);
        jsonBuilder.append(footer);

        return jsonBuilder.toString();
    }
}
