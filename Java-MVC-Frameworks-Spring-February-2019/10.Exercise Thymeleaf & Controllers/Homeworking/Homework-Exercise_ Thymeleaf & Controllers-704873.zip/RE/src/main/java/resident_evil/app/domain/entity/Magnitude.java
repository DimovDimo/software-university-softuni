package resident_evil.app.domain.entity;

public enum Magnitude {
    Low, Medium, High;
}
