package resident_evil.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import resident_evil.app.domain.entity.Capital;

import java.util.List;

@Repository
public interface CapitalRepository extends JpaRepository<Capital, Integer> {

    @Query("SELECT c FROM Capital AS c ORDER BY c.name")
    List<Capital> findAllOrderByName();
}
