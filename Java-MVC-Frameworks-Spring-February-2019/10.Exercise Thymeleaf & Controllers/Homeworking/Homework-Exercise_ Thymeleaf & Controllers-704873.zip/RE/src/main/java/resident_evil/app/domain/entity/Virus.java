package resident_evil.app.domain.entity;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "viruses")
public class Virus extends BaseEntity {
    private String name;
    private String description;
    private String sideEffects;
    private String creator;
    private Boolean isDeadly;
    private Boolean isCurable;
    private Mutation mutation;
    private Double turnoverRate;
    private Double hoursUntilTurn;
    private Magnitude magnitude;
    private Date releasedOn;
    private Set<Capital> capitals;


    @Column
    @Size(min = 3, max = 10, message = " Name must be between 3 and 10 chars")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(columnDefinition = "TEXT")
    @Size(min = 5, max = 100, message = " Description must be between 5 and 100 chars")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "side_effects")
    @Size(max = 50, message = " Side effects should be under 50 chars")
    public String getSideEffects() {
        return sideEffects;
    }

    public void setSideEffects(String sideEffects) {
        this.sideEffects = sideEffects;
    }

    @Column
    @Pattern(regexp = ".*([Cc]orp).*", message = " Creator should contain word Corp or corp")
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    @Column(name = "is_deadly")
    public Boolean getDeadly() {
        return isDeadly;
    }

    public void setDeadly(Boolean deadly) {
        isDeadly = deadly;
    }

    @Column(name = "is_curable")
    public Boolean getCurable() {
        return isCurable;
    }

    public void setCurable(Boolean curable) {
        isCurable = curable;
    }

    @Column
    @Enumerated(EnumType.STRING)
    @NotNull(message = " Mutation cannot be empty")
    public Mutation getMutation() {
        return mutation;
    }

    public void setMutation(Mutation mutation) {
        this.mutation = mutation;
    }

    @Column(name = "turnover_rate")
    @NotNull(message = " Turnover rate cannot be empty")
    @Min(value = 0, message = " Rate must be between 0 and 100")
    @Max(value = 100, message = " Rate must be between 0 and 100")
    public Double getTurnoverRate() {
        return turnoverRate;
    }

    public void setTurnoverRate(Double turnoverRate) {
        this.turnoverRate = turnoverRate;
    }

    @Column(name = "hours_until_turn")
    @NotNull(message = " Hours until turn cannot be empty")
    @Min(value = 1, message = " Hours must be between 1 and 12")
    @Max(value = 12, message = " Hours must be between 1 and 12")
    public Double getHoursUntilTurn() {
        return hoursUntilTurn;
    }

    public void setHoursUntilTurn(Double hoursUntilTurn) {
        this.hoursUntilTurn = hoursUntilTurn;
    }

    @Enumerated(EnumType.STRING)
    @NotNull(message = " Magnitude cannot be empty")
    @Column
    public Magnitude getMagnitude() {
        return magnitude;
    }

    public void setMagnitude(Magnitude magnitude) {
        this.magnitude = magnitude;
    }

    @Column(name = "released_on")
    @Past(message = " Release date should be prior to today")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @NotNull(message = " Release date cannot be empty")
    public Date getReleasedOn() {
        return releasedOn;
    }

    public void setReleasedOn(Date releasedOn) {
        this.releasedOn = releasedOn;
    }

    @NotEmpty(message = "You must select capitals")
    @ManyToMany(targetEntity = Capital.class, fetch = FetchType.LAZY)
    @JoinTable(name = "virus_city",
        joinColumns = @JoinColumn(name = "virus_id"),
        inverseJoinColumns = @JoinColumn(name = "city_id")
    )
    public Set<Capital> getCapitals() {
        return capitals;
    }

    public void setCapitals(Set<Capital> capitals) {
        this.capitals = capitals;
    }
}
