package resident_evil.app.domain.entity;

public enum Mutation {
    ZOMBIE, T_078_TYRANT, GIANT_SPIDER;
}
