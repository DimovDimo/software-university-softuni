package resident_evil.app.service;

import resident_evil.app.domain.model.service.CapitalServiceModel;

import java.util.List;

public interface CapitalService {

    List<CapitalServiceModel> findAllCapitals();
}
