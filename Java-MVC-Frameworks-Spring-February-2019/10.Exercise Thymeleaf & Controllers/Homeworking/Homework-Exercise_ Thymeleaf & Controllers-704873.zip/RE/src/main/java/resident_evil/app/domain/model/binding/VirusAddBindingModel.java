package resident_evil.app.domain.model.binding;

import org.springframework.format.annotation.DateTimeFormat;
import resident_evil.app.domain.entity.Capital;
import resident_evil.app.domain.entity.Magnitude;
import resident_evil.app.domain.entity.Mutation;

import javax.validation.constraints.*;
import java.util.Date;
import java.util.Set;

public class VirusAddBindingModel {
    private String name;
    private String description;
    private String sideEffects;
    private String creator;
    private Boolean isDeadly;
    private Boolean isCurable;
    private Mutation mutation;
    private Double turnoverRate;
    private Double hoursUntilTurn;
    private Magnitude magnitude;
    private Date releasedOn;
    private Set<Capital> capitals;

    @Size(min = 3, max = 10, message = " Name must be between 3 and 10 chars")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Size(min = 5, max = 100, message = " Description must be between 5 and 100 chars")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Size(max = 50, message = " Side effects should be under 50 chars")
    public String getSideEffects() {
        return sideEffects;
    }

    public void setSideEffects(String sideEffects) {
        this.sideEffects = sideEffects;
    }

    @Pattern(regexp = ".*([Cc]orp).*", message = " Creator should contain word Corp or corp")
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Boolean getDeadly() {
        return isDeadly;
    }

    public void setDeadly(Boolean deadly) {
        isDeadly = deadly;
    }

    public Boolean getCurable() {
        return isCurable;
    }

    public void setCurable(Boolean curable) {
        isCurable = curable;
    }

    @NotNull(message = " Mutation cannot be empty")
    public Mutation getMutation() {
        return mutation;
    }

    public void setMutation(Mutation mutation) {
        this.mutation = mutation;
    }

    @NotNull(message = " Turnover rate cannot be empty")
    @Min(value = 0, message = " Rate must be between 0 and 100")
    @Max(value = 100, message = " Rate must be between 0 and 100")
    public Double getTurnoverRate() {
        return turnoverRate;
    }

    public void setTurnoverRate(Double turnoverRate) {
        this.turnoverRate = turnoverRate;
    }

    @NotNull(message = " Hours until turn cannot be empty")
    @Min(value = 1, message = " Hours must be between 1 and 12")
    @Max(value = 12, message = " Hours must be between 1 and 12")
    public Double getHoursUntilTurn() {
        return hoursUntilTurn;
    }

    public void setHoursUntilTurn(Double hoursUntilTurn) {
        this.hoursUntilTurn = hoursUntilTurn;
    }

    @NotNull(message = " Magnitude cannot be empty")
    public Magnitude getMagnitude() {
        return magnitude;
    }

    public void setMagnitude(Magnitude magnitude) {
        this.magnitude = magnitude;
    }

    @Past(message = " Release date should be prior to today")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @NotNull(message = " Release date cannot be empty")
    public Date getReleasedOn() {
        return releasedOn;
    }

    public void setReleasedOn(Date releasedOn) {
        this.releasedOn = releasedOn;
    }

    @NotEmpty(message = "You must select capitals")
    public Set<Capital> getCapitals() {
        return capitals;
    }

    public void setCapitals(Set<Capital> capitals) {
        this.capitals = capitals;
    }
}
