package softuni.residentevil.domain.entities.enums;

public enum Magnitude {
    Low, Medium, High

}
