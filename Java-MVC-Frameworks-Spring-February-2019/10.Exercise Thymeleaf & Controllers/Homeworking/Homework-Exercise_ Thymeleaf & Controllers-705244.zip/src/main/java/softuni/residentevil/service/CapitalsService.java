package softuni.residentevil.service;


import softuni.residentevil.domain.models.service.CapitalsServiceModel;

import java.util.List;

public interface CapitalsService {

    List<CapitalsServiceModel> findAllSortedByName();
}
