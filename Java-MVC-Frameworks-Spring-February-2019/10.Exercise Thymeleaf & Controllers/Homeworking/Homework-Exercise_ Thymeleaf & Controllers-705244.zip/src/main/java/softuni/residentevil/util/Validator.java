package softuni.residentevil.util;

public interface Validator {
    <M> boolean isValid(M model);
}
