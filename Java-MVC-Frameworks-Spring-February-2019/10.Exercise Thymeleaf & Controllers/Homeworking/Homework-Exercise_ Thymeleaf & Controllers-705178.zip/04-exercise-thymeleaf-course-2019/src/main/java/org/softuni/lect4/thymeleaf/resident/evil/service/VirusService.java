package org.softuni.lect4.thymeleaf.resident.evil.service;

import java.util.List;

import org.softuni.lect4.thymeleaf.resident.evil.domain.models.service.VirusServiceModel;

public interface VirusService {

	public List<VirusServiceModel> findAllViruses();

	public void saveVirus(VirusServiceModel virusServiceModel);
}
