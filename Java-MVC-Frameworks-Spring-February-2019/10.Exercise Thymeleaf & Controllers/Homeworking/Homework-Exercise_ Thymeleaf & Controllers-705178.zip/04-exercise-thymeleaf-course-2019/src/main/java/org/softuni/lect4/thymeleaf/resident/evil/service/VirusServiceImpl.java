package org.softuni.lect4.thymeleaf.resident.evil.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.softuni.lect4.thymeleaf.resident.evil.domain.entities.Virus;
import org.softuni.lect4.thymeleaf.resident.evil.domain.models.service.VirusServiceModel;
import org.softuni.lect4.thymeleaf.resident.evil.repository.VirusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class VirusServiceImpl implements VirusService {

	private final VirusRepository virusRepository;
	private final ModelMapper modelMapper;

	@Autowired
	public VirusServiceImpl(VirusRepository virusRepository, ModelMapper modelMapper) {
		this.virusRepository = virusRepository;
		this.modelMapper = modelMapper;
	}

	@Override
	public List<VirusServiceModel> findAllViruses() {
		return virusRepository.findAll()
				.stream()
				.map(v -> modelMapper.map(v, VirusServiceModel.class))
				.collect(Collectors.toList());
	}

	@Override
	public void saveVirus(VirusServiceModel virusServiceModel) {
				Virus virus = modelMapper.map(virusServiceModel, Virus.class);
				virusRepository.saveAndFlush(virus);
	}
}
