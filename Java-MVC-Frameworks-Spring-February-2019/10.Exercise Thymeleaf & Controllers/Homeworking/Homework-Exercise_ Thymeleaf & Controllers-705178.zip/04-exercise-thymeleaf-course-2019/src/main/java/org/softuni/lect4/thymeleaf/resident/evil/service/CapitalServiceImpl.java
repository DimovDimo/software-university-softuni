package org.softuni.lect4.thymeleaf.resident.evil.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.softuni.lect4.thymeleaf.resident.evil.domain.models.service.CapitalServiceModel;
import org.softuni.lect4.thymeleaf.resident.evil.repository.CapitalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CapitalServiceImpl implements CapitalService {

	private final CapitalRepository capitalRepository;
	private final ModelMapper modelMapper;

	@Autowired
	public CapitalServiceImpl(CapitalRepository capitalRepository, ModelMapper modelMapper) {
		this.capitalRepository = capitalRepository;
		this.modelMapper = modelMapper;
	}

	@Override
	public List<CapitalServiceModel> findAllCapitals() {
		return capitalRepository.findAllOrderByName()
				.stream()
				.map( c-> modelMapper.map(c, CapitalServiceModel.class))
				.collect(Collectors.toList());
	}

}
