package org.softuni.lect4.thymeleaf.resident.evil.web.controllers;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.softuni.lect4.thymeleaf.resident.evil.domain.models.binding.VirusAddBindingModel;
import org.softuni.lect4.thymeleaf.resident.evil.domain.models.service.VirusServiceModel;
import org.softuni.lect4.thymeleaf.resident.evil.domain.models.view.CapitalListViewModel;
import org.softuni.lect4.thymeleaf.resident.evil.domain.models.view.VirusListViewModel;
import org.softuni.lect4.thymeleaf.resident.evil.service.CapitalService;
import org.softuni.lect4.thymeleaf.resident.evil.service.VirusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/viruses")
public class VirusController extends BaseController {

	private final CapitalService capitalService;
	private final VirusService virusService;
	private final ModelMapper modelMapper;

	@Autowired
	public VirusController(CapitalService capitalService, VirusService virusService, ModelMapper modelMapper) {
		this.capitalService = capitalService;
		this.virusService = virusService;
		this.modelMapper = modelMapper;
	}

	@GetMapping("/add")
	public ModelAndView add(ModelAndView modelAndView,
			@ModelAttribute(name = "bindingModel") VirusAddBindingModel bindingModel) {

		modelAndView.addObject("bindingModel", bindingModel);
		modelAndView.addObject("capitals", capitalService.findAllCapitals().stream()
				.map(c -> modelMapper.map(c, CapitalListViewModel.class)).collect(Collectors.toList()));
		return super.view("add-virus", modelAndView);
	}

	@PostMapping("/add")
	public ModelAndView post(ModelAndView modelAndView,
			@Valid @ModelAttribute(name = "bindingModel") VirusAddBindingModel bindingModel,
			BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			modelAndView.addObject("bindingModel", bindingModel);
			return super.view("add-virus", modelAndView);
		}
		VirusServiceModel virusServiceModel = modelMapper.map(bindingModel, VirusServiceModel.class);
		virusService.saveVirus(virusServiceModel);
		return super.redirect("/");
	}

	@GetMapping("/show")
	public ModelAndView show(ModelAndView modelAndView) {
		List<VirusListViewModel> viruses = virusService.findAllViruses().stream()
				.map(c -> modelMapper.map(c, VirusListViewModel.class)).collect(Collectors.toList());

		modelAndView.addObject("viruses", viruses);
		return super.view("show-viruses", modelAndView);
	}

}
