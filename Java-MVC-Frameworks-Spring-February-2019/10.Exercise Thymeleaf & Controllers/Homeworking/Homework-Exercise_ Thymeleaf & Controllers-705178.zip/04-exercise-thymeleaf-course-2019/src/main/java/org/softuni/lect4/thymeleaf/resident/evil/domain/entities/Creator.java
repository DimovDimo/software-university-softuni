package org.softuni.lect4.thymeleaf.resident.evil.domain.entities;

import java.util.Arrays;

public enum Creator {
	Corp, corp;

	public static Creator fromValue(String value) {
		for (Creator category : values()) {
			if (category.name().equals(value)) {
				return category;
			}
		}
		throw new IllegalArgumentException(
				"Unknown enum type " + value + ", Allowed values are " + Arrays.toString(values()));
	}
}
