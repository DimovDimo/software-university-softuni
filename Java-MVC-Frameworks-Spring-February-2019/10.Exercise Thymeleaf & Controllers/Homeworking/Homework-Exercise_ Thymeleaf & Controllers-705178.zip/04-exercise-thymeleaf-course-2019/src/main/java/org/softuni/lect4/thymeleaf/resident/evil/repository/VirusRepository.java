package org.softuni.lect4.thymeleaf.resident.evil.repository;

import org.softuni.lect4.thymeleaf.resident.evil.domain.entities.Virus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VirusRepository extends JpaRepository<Virus, String> {

}
