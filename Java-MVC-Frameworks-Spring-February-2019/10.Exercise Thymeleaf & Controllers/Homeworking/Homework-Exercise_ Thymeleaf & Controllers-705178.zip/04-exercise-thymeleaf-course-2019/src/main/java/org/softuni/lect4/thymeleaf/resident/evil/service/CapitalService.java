package org.softuni.lect4.thymeleaf.resident.evil.service;

import java.util.List;

import org.softuni.lect4.thymeleaf.resident.evil.domain.models.service.CapitalServiceModel;

public interface CapitalService {

	public List<CapitalServiceModel> findAllCapitals();
}
