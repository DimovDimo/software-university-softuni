package org.softuni.lect4.thymeleaf.resident.evil.domain.entities;

public enum Magnitude {
	Low, Medium, High;
}
