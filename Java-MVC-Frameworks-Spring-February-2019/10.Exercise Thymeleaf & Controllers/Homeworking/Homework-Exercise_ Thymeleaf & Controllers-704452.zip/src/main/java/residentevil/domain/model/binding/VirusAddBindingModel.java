package residentevil.domain.model.binding;

public class VirusAddBindingModel extends VirusBindingModel{

    public VirusAddBindingModel() {
    }
}
