package org.softuni.residentevil.web.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;

@Controller
public class HomeController extends BaseController {

    @GetMapping("/")
    public ModelAndView index(ModelAndView modelAndView){
        //modelAndView.setViewName("/index");
        //return modelAndView;

        //return this.view("index");

        return super.view("index");
    }

    @GetMapping("/home")
    public ModelAndView home(ModelAndView modelAndView, HttpSession session){
        modelAndView.setViewName("home");
        //modelAndView.addObject("documents", documents);


        return modelAndView;
    }
}
