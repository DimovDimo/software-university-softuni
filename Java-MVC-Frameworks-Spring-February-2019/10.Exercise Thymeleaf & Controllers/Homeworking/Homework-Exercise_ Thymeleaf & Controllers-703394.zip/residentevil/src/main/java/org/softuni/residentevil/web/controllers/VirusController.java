package org.softuni.residentevil.web.controllers;

import org.modelmapper.ModelMapper;
import org.softuni.residentevil.domain.entities.Virus;
import org.softuni.residentevil.domain.models.binding.VirusAddBindingModel;
import org.softuni.residentevil.domain.models.binding.VirusEditBindingModel;
import org.softuni.residentevil.domain.models.service.VirusServiceModel;
import org.softuni.residentevil.domain.models.view.CapitalListViewModel;
import org.softuni.residentevil.domain.models.view.VirusListViewModel;
import org.softuni.residentevil.service.CapitalService;
import org.softuni.residentevil.service.VirusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/viruses")
public class VirusController extends BaseController {
    private final VirusService virusService;
    private final CapitalService capitalService;
    private final ModelMapper modelMapper;

    @Autowired
    public VirusController(VirusService virusService, CapitalService capitalService, ModelMapper modelMapper) {
        this.virusService = virusService;
        this.capitalService = capitalService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/add")
    public ModelAndView add(ModelAndView modelAndView, @ModelAttribute(name = "bindingModel") VirusAddBindingModel bindingModel){
        modelAndView.addObject("bindingModel", bindingModel);

        modelAndView.addObject("capitals",
                this.capitalService.findAllCapitals()
                        .stream().map(c -> this.modelMapper.map(c, CapitalListViewModel.class))
                        .collect(Collectors.toList()));


        return super.view("add-virus", modelAndView);
    }

    @PostMapping("/add")
    public ModelAndView addConfirm(ModelAndView modelAndView, @Valid @ModelAttribute(name = "bindingModel") VirusAddBindingModel bindingModel, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            modelAndView.addObject("bindingModel", bindingModel);

            modelAndView.addObject("capitals",
                    this.capitalService.findAllCapitals()
                            .stream().map(c -> this.modelMapper.map(c, CapitalListViewModel.class))
                            .collect(Collectors.toList()));

            return super.view("add-virus", modelAndView);
        }

        this.virusService.addVirus(this.modelMapper.map(bindingModel, VirusServiceModel.class));

        return super.redirect("/");
    }

    @GetMapping("/show")
    public ModelAndView showAll(ModelAndView modelAndView, @ModelAttribute(name = "listViewModel") VirusListViewModel listViewModel){

        modelAndView.addObject("listViewModel",
                this.virusService.findAllViruses().stream().map(c -> this.modelMapper.map(c, VirusListViewModel.class))
                .collect(Collectors.toList()));

        return super.view("all-viruses", modelAndView);
    }

    @GetMapping("/edit/{id}")
    public ModelAndView edit(ModelAndView modelAndView, @ModelAttribute(name = "bindingModel") VirusEditBindingModel bindingModel, @PathVariable String id){

        VirusServiceModel virusServiceModel = this.virusService.findVirusById(id);

        modelAndView.addObject("bindingModel", this.modelMapper.map(virusServiceModel, VirusEditBindingModel.class));

        modelAndView.addObject("capitals",
                this.capitalService.findAllCapitals()
                        .stream().map(c -> this.modelMapper.map(c, CapitalListViewModel.class))
                        .collect(Collectors.toList()));


        return super.view("edit-virus", modelAndView);
    }

    @PostMapping("/edit/{id}")
    public ModelAndView editConfirm(ModelAndView modelAndView, @Valid @ModelAttribute(name = "bindingModel") VirusEditBindingModel bindingModel, @PathVariable String id, BindingResult bindingResult){

        this.virusService.editVirus(id, this.modelMapper.map(bindingModel, VirusServiceModel.class));

        return super.redirect("/viruses/show");
    }

    @GetMapping("/delete/{id}")
    public ModelAndView delete(ModelAndView modelAndView, @PathVariable String id){

        this.virusService.deleteVirus(id);

        return super.redirect("/viruses/show");
    }

}
