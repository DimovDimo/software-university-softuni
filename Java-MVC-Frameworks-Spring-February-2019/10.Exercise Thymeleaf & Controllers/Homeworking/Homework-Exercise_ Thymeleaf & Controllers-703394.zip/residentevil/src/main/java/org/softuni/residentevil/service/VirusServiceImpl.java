package org.softuni.residentevil.service;

import org.modelmapper.ModelMapper;
import org.softuni.residentevil.domain.entities.Virus;
import org.softuni.residentevil.domain.models.service.VirusServiceModel;
import org.softuni.residentevil.repository.VirusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class VirusServiceImpl implements VirusService {
    private final VirusRepository virusRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public VirusServiceImpl(VirusRepository virusRepository, ModelMapper modelMapper) {
        this.virusRepository = virusRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public VirusServiceModel addVirus(VirusServiceModel virusServiceModel){
        Virus virus = this.modelMapper.map(virusServiceModel, Virus.class);

        try{
            virus = this.virusRepository.saveAndFlush(virus);
            return this.modelMapper.map(virus, VirusServiceModel.class);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<VirusServiceModel> findAllViruses() {
        return this.virusRepository
                .findAllOrderByName()
                .stream()
                .map(c -> this.modelMapper.map(c, VirusServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public VirusServiceModel findVirusById(String id) {
        Virus virus = this.virusRepository.findById(id).orElse(null);

        if(virus != null) {
            return this.modelMapper.map(virus, VirusServiceModel.class);
        }

        return null;
    }

    @Override
    public VirusServiceModel editVirus(String id, VirusServiceModel virusServiceModel) {
        Virus virus =this.modelMapper.map(virusServiceModel, Virus.class);
        virus.setId(id);

        return this.modelMapper.map(
                this.virusRepository
                        .saveAndFlush(virus),
                VirusServiceModel.class);
    }

    @Override
    public void deleteVirus(String id) {
        this.virusRepository.deleteById(id);
    }
}
