package residentevil_app.domain.enums;

public enum Magnitude {
    LOW, MEDIUM, HIGH;
}
