package p04residentevel.domain.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import p04residentevel.domain.models.service.CapitalServiceModel;
import p04residentevel.domain.repository.CapitalRepository;

import java.util.Arrays;
import java.util.List;

@Service
public class CapitalServiceImpl implements CapitalService {
    private final CapitalRepository capitalRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public CapitalServiceImpl(CapitalRepository capitalRepository, ModelMapper modelMapper) {
        this.capitalRepository = capitalRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<CapitalServiceModel> findAllCapitals() {

        return Arrays.asList(this.modelMapper
                .map(this.capitalRepository.findCapitalsByIdNotNullOrderByName(), CapitalServiceModel[].class));
    }

    @Override
    public CapitalServiceModel findCapitalById(String id) {
        return this.modelMapper.map(this.capitalRepository.findCapitalById(id), CapitalServiceModel.class);
    }
}
