package p04residentevel.domain.entities;

public enum Creator {
    Corp, corp;
}
