package p04residentevel.domain.service;

import p04residentevel.domain.models.service.VirusServiceModel;

import java.util.List;

public interface VirusService {

    void addVirus(VirusServiceModel virusServiceModel);

    List<VirusServiceModel> listAllViruses();

    VirusServiceModel findById(String id);

    void editVirus(String id, VirusServiceModel virusServiceModel);

    void deleteVirus(String id);
}
