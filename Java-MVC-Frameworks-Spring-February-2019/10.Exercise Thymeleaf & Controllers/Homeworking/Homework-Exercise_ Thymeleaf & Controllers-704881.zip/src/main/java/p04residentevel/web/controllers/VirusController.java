package p04residentevel.web.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import p04residentevel.domain.entities.Capital;
import p04residentevel.domain.models.binding.VirusAddBindingModel;
import p04residentevel.domain.models.service.VirusServiceModel;
import p04residentevel.domain.models.view.CapitalsViewModel;
import p04residentevel.domain.models.view.VirusViewModel;
import p04residentevel.domain.service.CapitalService;
import p04residentevel.domain.service.VirusService;

import javax.validation.Valid;
import java.util.Arrays;
import java.util.List;

@Controller
@RequestMapping("/viruses")
public class VirusController extends BaseController {

    private final CapitalService capitalService;
    private final VirusService virusService;
    private final ModelMapper modelMapper;

    @Autowired
    public VirusController(CapitalService capitalService, VirusService virusService, ModelMapper modelMapper) {
        this.capitalService = capitalService;
        this.virusService = virusService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/add")
    public ModelAndView add(ModelAndView modelAndView, @ModelAttribute(name = "bindingModel")
            VirusAddBindingModel virusAddBindingModel) {

        setupModelAndView(modelAndView, virusAddBindingModel);

        modelAndView.setViewName("add-virus");
        return modelAndView;
//        return super.view("add-virus", modelAndView);
    }

    @PostMapping("/add")
    public ModelAndView addConfirm(@Valid @ModelAttribute(name = "bindingModel") VirusAddBindingModel virusAddBindingModel,
                                   BindingResult bindingResult, ModelAndView modelAndView) {
        if (bindingResult.hasErrors()) {
            setupModelAndView(modelAndView, virusAddBindingModel);

            modelAndView.setViewName("add-virus");
            return modelAndView;
//            return super.view("add-virus", modelAndView);
        }

        VirusServiceModel virusServiceModel = setupVirusServiceModel(virusAddBindingModel);
        this.virusService.addVirus(virusServiceModel);

        modelAndView.setViewName("redirect:/viruses/show");
        return modelAndView;
//        return super.redirect("/viruses/show");
    }

    @GetMapping("/show")
    public ModelAndView show(ModelAndView modelAndView) {
        List<VirusViewModel> virusViewModels = Arrays.asList(this.modelMapper
                .map(this.virusService.listAllViruses(), VirusViewModel[].class));

        modelAndView.addObject("viruses", virusViewModels);

        modelAndView.setViewName("show-virus");
        return modelAndView;
//        return super.view("show-virus", modelAndView);
    }

    @GetMapping("/delete/{id}")
    public ModelAndView delete(@PathVariable("id") String id, ModelAndView modelAndView) {
        try {
            this.virusService.deleteVirus(id);

            modelAndView.setViewName("redirect:/viruses/show");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return modelAndView;
    }

    @GetMapping("/edit/{id}")
    public ModelAndView edit(@PathVariable("id") String id, ModelAndView modelAndView,
                             @ModelAttribute(name = "bindingModel")
                                     VirusAddBindingModel virusAddBindingModel) {

        virusAddBindingModel = this.modelMapper.map(this.virusService.findById(id), VirusAddBindingModel.class);

        setupModelAndView(modelAndView, virusAddBindingModel);

        modelAndView.setViewName("edit-virus");
        return modelAndView;
//        return super.view("edit-virus", modelAndView);

    }

    @PostMapping("/edit/{id}")
    public ModelAndView editConfirm(@PathVariable("id") String id, @Valid @ModelAttribute(name = "bindingModel")
            VirusAddBindingModel virusAddBindingModel, BindingResult bindingResult, ModelAndView modelAndView) {

        virusAddBindingModel.setId(id);

        if (bindingResult.hasErrors()) {
            setupModelAndView(modelAndView, virusAddBindingModel);

            modelAndView.setViewName("edit-virus");
            return modelAndView;
//            return super.view("edit-virus", modelAndView);

        }

        VirusServiceModel virusServiceModel = setupVirusServiceModel(virusAddBindingModel);
        this.virusService.editVirus(id, virusServiceModel);

        modelAndView.setViewName("redirect:/viruses/show");
        return modelAndView;
//        return super.redirect("/viruses/show");
    }

    private VirusServiceModel setupVirusServiceModel(@ModelAttribute(name = "bindingModel")
                                                     @Valid VirusAddBindingModel virusAddBindingModel) {

        VirusServiceModel virusServiceModel = this.modelMapper.map(virusAddBindingModel, VirusServiceModel.class);
        virusServiceModel.setCapitals(Arrays.asList(this.modelMapper
                .map(virusAddBindingModel.getCapitals().stream()
                        .map(this.capitalService::findCapitalById).toArray(), Capital[].class)));

        return virusServiceModel;
    }

    private void setupModelAndView(ModelAndView modelAndView,
                                   @ModelAttribute(name = "bindingModel") VirusAddBindingModel virusAddBindingModel) {
        modelAndView.addObject("bindingModel", virusAddBindingModel);
        modelAndView.addObject("capitals", this.modelMapper
                .map(this.capitalService.findAllCapitals(), CapitalsViewModel[].class));
    }
}
