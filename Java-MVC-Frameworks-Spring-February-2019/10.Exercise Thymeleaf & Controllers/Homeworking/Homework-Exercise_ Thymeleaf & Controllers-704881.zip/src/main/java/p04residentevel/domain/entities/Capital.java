package p04residentevel.domain.entities;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity(name = "capitals")
public class Capital extends BaseEntity {

    private String name;
    private Double latitude;
    private Double longitude;

    @Column(nullable = false)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column
    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    @Column
    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }
}
