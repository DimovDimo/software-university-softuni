package p04residentevel.domain.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import p04residentevel.domain.entities.Virus;
import p04residentevel.domain.models.service.VirusServiceModel;
import p04residentevel.domain.repository.VirusRepository;

import javax.validation.Validator;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class VirusServiceImpl implements VirusService {
    private final VirusRepository virusRepository;
    private final ModelMapper modelMapper;
    private final Validator validator;

    @Autowired
    public VirusServiceImpl(VirusRepository virusRepository, ModelMapper modelMapper, Validator validator) {
        this.virusRepository = virusRepository;
        this.modelMapper = modelMapper;
        this.validator = validator;
    }

    @Override
    public void addVirus(VirusServiceModel virusServiceModel) {
        if (this.validator.validate(virusServiceModel).size() != 0){
            throw new IllegalArgumentException("Error during adding the virus!");
        }

        Virus virus = this.modelMapper.map(virusServiceModel, Virus.class);

        this.virusRepository.saveAndFlush(virus);
    }

    @Override
    public List<VirusServiceModel> listAllViruses() {
        return Arrays.asList(this.modelMapper
                .map(this.virusRepository.findAll().toArray(), VirusServiceModel[].class));
    }

    @Override
    public VirusServiceModel findById(String id) {
        Virus virus = this.virusRepository.findById(id).orElse(null);
        return this.modelMapper.map(virus, VirusServiceModel.class);
    }

    @Override
    public void editVirus(String id, VirusServiceModel virusServiceModel) {
        Optional<Virus> virusById = this.virusRepository.findById(id);

        VirusServiceModel toEdit = this.modelMapper.map(virusById, VirusServiceModel.class);

        toEdit.setId(id);
        toEdit.setName(virusServiceModel.getName());
        toEdit.setDescription(virusServiceModel.getDescription());
        toEdit.setSideEffects(virusServiceModel.getSideEffects());
        toEdit.setCreator(virusServiceModel.getCreator());
        toEdit.setDeadly(virusServiceModel.isDeadly());
        toEdit.setCurable(virusServiceModel.isCurable());
        toEdit.setMutation(virusServiceModel.getMutation());
        toEdit.setTurnoverRate(virusServiceModel.getTurnoverRate());
        toEdit.setHoursUntilTurn(virusServiceModel.getHoursUntilTurn());
        toEdit.setMagnitude(virusServiceModel.getMagnitude());
        toEdit.setReleasedOn(virusServiceModel.getReleasedOn());
        toEdit.setCapitals(virusServiceModel.getCapitals());

        this.virusRepository.save(this.modelMapper.map(toEdit, Virus.class));
    }

    @Override
    public void deleteVirus(String id) {
        try {
            this.virusRepository.deleteById(id);
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
