package p04residentevel.util;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@Constraint(validatedBy = CreatorCustomValidatorImpl.class)
public @interface CreatorCustomValidator {

    String message() default "Invalid creator - can be either \"Corp\" or \"corp\"";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}

