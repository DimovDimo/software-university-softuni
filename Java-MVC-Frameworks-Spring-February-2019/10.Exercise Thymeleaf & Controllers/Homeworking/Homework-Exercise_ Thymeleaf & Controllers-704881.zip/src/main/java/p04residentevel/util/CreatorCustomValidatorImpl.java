package p04residentevel.util;

import p04residentevel.domain.entities.Creator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CreatorCustomValidatorImpl implements ConstraintValidator<CreatorCustomValidator, String> {
   public void initialize(CreatorCustomValidator constraint) {
   }

   @Override
   public boolean isValid(String creatorName, ConstraintValidatorContext constraintValidatorContext) {
      return creatorName != null &&
              (Creator.corp.name().equals(creatorName)
              || Creator.Corp.name().equals(creatorName));
   }
}
