package p04residentevel.util;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.LocalDate;

public class DateCustomValidatorImpl implements ConstraintValidator<DateCustomValidator, LocalDate> {
   public void initialize(DateCustomValidator constraint) {
   }

   @Override
   public boolean isValid(LocalDate date, ConstraintValidatorContext context) {
      if (date == null) return false;

      return date.isBefore(LocalDate.now());
   }
}
