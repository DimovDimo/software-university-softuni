package p04residentevel.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import p04residentevel.domain.entities.Capital;

import java.util.List;

public interface CapitalRepository extends JpaRepository<Capital, String> {
    List<Capital> findCapitalsByIdNotNullOrderByName();
    Capital findCapitalById(String id);
}
