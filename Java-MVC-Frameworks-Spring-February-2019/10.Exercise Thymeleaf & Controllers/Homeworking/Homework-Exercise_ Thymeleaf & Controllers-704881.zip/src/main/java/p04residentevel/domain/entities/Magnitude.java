package p04residentevel.domain.entities;

public enum Magnitude {
    Low, Medium, High;
}
