package p04residentevel.domain.service;

import p04residentevel.domain.models.service.CapitalServiceModel;

import java.util.List;

public interface CapitalService {

    List<CapitalServiceModel> findAllCapitals();

    CapitalServiceModel findCapitalById(String id);
}
