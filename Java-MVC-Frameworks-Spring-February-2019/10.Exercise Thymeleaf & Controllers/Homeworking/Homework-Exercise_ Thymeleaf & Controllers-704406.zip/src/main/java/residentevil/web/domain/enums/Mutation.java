package residentevil.web.domain.enums;

/**
 * Created by Neycho Damgaliev on 3/16/2019.
 */
public enum Mutation {
    ZOMBIE,T_078_TYRANT, GIANT_SPIDER;
}
