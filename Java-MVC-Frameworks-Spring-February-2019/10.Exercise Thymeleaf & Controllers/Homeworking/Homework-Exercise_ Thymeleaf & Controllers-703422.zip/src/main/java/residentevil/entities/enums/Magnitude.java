package residentevil.entities.enums;

public enum Magnitude {
    LOW,
    MEDIUM,
    HIGH;
}
