package softuni.residentevil.domain.entities;

public enum Creator {
  Corp, corp;


}
