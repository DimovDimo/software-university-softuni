package softuni.residentevil.domain.entities;

public enum Magnitude {
  Low, Medium, High;
}
