package residentevil.domain.entities.enums;

public enum Creator {
    Corp,corp;
}
