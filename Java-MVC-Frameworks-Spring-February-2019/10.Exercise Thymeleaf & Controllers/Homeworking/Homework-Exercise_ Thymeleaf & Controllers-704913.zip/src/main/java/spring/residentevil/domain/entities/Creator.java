package spring.residentevil.domain.entities;

public enum Creator {
    Corp,corp;
}
