package spring.residentevil.domain.entities;

public enum Magnitude {

    Low,Medium,High
}
