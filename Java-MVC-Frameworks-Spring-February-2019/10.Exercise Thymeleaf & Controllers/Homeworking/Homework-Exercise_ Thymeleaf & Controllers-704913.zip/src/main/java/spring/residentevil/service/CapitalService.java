package spring.residentevil.service;

import spring.residentevil.domain.models.service.CapitalServiceModel;

import java.util.List;

public interface CapitalService {

    List<CapitalServiceModel> findCapitals();
}
