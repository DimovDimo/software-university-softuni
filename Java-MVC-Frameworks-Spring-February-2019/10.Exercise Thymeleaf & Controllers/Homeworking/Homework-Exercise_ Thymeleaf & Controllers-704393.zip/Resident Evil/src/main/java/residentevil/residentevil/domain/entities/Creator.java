package residentevil.residentevil.domain.entities;

public enum Creator {
    Corp, corp;
}
