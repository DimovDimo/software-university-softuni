package residentevil.residentevil.domain.entities;

public enum Mutation {

    ZOMBIE, T_078_TYRANT, GIANT_SPIDER;
}
