package realestate.domain.models.view;

import java.math.BigDecimal;

public class OfferViewModel {

    private BigDecimal appartmentRent;
    private String appartmentType;
    private BigDecimal agencyCommission;

    public OfferViewModel() {
    }

    public BigDecimal getAppartmentRent() {
        return appartmentRent;
    }

    public void setAppartmentRent(BigDecimal appartmentRent) {
        this.appartmentRent = appartmentRent;
    }

    public String getAppartmentType() {
        return appartmentType;
    }

    public void setAppartmentType(String appartmentType) {
        this.appartmentType = appartmentType;
    }

    public BigDecimal getAgencyCommission() {
        return agencyCommission;
    }

    public void setAgencyCommission(BigDecimal agencyCommission) {
        this.agencyCommission = agencyCommission;
    }
}
