package realestate.domain.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.math.BigDecimal;

@Entity(name="offers")
public class Offer extends BaseEntity {
    private BigDecimal appartmentRent;
    private String appartmentType;
    private BigDecimal agencyCommission;

    public Offer() {
    }
@Column(name="appartment_rent")
    public BigDecimal getAppartmentRent() {
        return appartmentRent;
    }

    public void setAppartmentRent(BigDecimal appartmentRent) {
        this.appartmentRent = appartmentRent;
    }
@Column(name="appartment_type")
    public String getAppartmentType() {
        return appartmentType;
    }

    public void setAppartmentType(String appartmentType) {
        this.appartmentType = appartmentType;
    }
@Column(name="agency_commission")
    public BigDecimal getAgencyCommission() {
        return agencyCommission;
    }

    public void setAgencyCommission(BigDecimal agencyCommission) {
        this.agencyCommission = agencyCommission;
    }
}
