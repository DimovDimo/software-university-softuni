package realestate.domain.models.service;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class OfferServiceModel {

    private String id;
    private BigDecimal appartmentRent;
    private String appartmentType;
    private BigDecimal agencyCommission;

    public OfferServiceModel() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
@NotNull
@DecimalMin("0.0001")
    public BigDecimal getAppartmentRent() {
        return appartmentRent;
    }

    public void setAppartmentRent(BigDecimal appartmentRent) {
        this.appartmentRent = appartmentRent;
    }
@NotNull
@NotEmpty
    public String getAppartmentType() {
        return appartmentType;
    }

    public void setAppartmentType(String appartmentType) {
        this.appartmentType = appartmentType;
    }
@NotNull
@DecimalMin("0")
@DecimalMax("100")
    public BigDecimal getAgencyCommission() {
        return agencyCommission;
    }

    public void setAgencyCommission(BigDecimal agencyCommission) {
        this.agencyCommission = agencyCommission;
    }
}
