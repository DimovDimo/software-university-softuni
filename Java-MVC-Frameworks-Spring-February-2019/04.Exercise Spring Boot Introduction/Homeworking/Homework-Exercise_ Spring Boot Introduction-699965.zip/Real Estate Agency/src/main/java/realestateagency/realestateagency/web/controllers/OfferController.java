package realestateagency.realestateagency.web.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class OfferController {


}
