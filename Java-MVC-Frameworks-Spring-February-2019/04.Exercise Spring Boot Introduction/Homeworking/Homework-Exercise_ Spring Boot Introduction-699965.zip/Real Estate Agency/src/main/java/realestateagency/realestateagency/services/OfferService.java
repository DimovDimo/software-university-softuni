package realestateagency.realestateagency.services;

import org.springframework.stereotype.Service;

@Service
public interface OfferService {
}
