package realestateagency.realestateagency.services;

public class OfferServiceImpl implements OfferService {
}
