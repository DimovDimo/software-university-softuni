package realestate.services;

import realestate.domain.models.binding.OfferFindBindingModel;
import realestate.domain.models.service.OfferServiceModel;

import java.util.List;

public interface OfferService {

    void registerOffer(OfferServiceModel model);

    List<OfferServiceModel> findAllOffers();

    void findOffer(OfferFindBindingModel model);
}
