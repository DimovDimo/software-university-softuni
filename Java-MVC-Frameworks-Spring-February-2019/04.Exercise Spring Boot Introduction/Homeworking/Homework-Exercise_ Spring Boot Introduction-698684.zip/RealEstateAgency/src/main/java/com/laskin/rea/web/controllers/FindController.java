package com.laskin.rea.web.controllers;

import com.laskin.rea.domain.models.binding.FindBindingModel;
import com.laskin.rea.services.OfferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class FindController {

    private final OfferService offerService;

    @Autowired
    public FindController(OfferService offerService) {
        this.offerService = offerService;
    }

    @GetMapping("/find")
    public String find(){
        return "find.html";
    }

    @PostMapping("/find")
    public String findConfirm(@ModelAttribute(name = "model") FindBindingModel model){

        try{
            this.offerService.findOffer(model);
            return "redirect:/";
        }catch (IllegalArgumentException iae){
            iae.printStackTrace();

            return "redirect:/find.html";
        }

    }
}
