package softuni.service;

import org.springframework.stereotype.Service;
import softuni.domain.models.service.OfferServiceModel;

import java.util.List;

@Service
public interface OfferService {
    OfferServiceModel save(OfferServiceModel model);
    List<OfferServiceModel> find(String apartmentType);
    OfferServiceModel delete(OfferServiceModel offerServiceModel);
    List<OfferServiceModel> findAll();
}
