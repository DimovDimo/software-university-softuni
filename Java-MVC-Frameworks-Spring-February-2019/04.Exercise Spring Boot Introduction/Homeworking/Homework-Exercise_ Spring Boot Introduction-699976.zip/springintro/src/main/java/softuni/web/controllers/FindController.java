package softuni.web.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import softuni.domain.models.binding.FindBindingModel;
import softuni.domain.models.service.OfferServiceModel;
import softuni.service.OfferService;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class FindController {
    private final OfferService offerService;

    public FindController(OfferService offerService) {
        this.offerService = offerService;
    }


    @GetMapping("/find")
    public String find(){
        return "find.html";
    }

    @PostMapping("/find")
    public String find(FindBindingModel findBindingModel){
        if(findBindingModel.getFamilyBudget().compareTo(new BigDecimal("0.00"))<=0 ||
        findBindingModel.getFamilyApartmentType().equals("") ||
                findBindingModel.getFamilyName().equals("")){
            return "redirect:/find";
        }
        List<OfferServiceModel> offerServiceModel= this.offerService.find(findBindingModel.getFamilyApartmentType()).
                stream().filter(x->(findBindingModel.getFamilyBudget().compareTo(x.getApartmentRent().
                add(x.getApartmentRent().multiply(x.getAgencyCommission().
                        divide(new BigDecimal("100"))))))>=0).collect(Collectors.toList());
        if(offerServiceModel.size()>0){
           OfferServiceModel offerServiceModel1= this.offerService.delete(offerServiceModel.get(0));
        }else{
            return "redirect:/find";
        }


        return "redirect:/";
    }
}
