package softuni.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.domain.entities.Offer;
import softuni.domain.models.service.OfferServiceModel;
import softuni.repository.OfferRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OfferServiceImpl implements OfferService {
    private final  OfferRepository offerRepository;
    private final  ModelMapper modelMapper;

    @Autowired
    public OfferServiceImpl(OfferRepository offerRepository, ModelMapper modelMapper) {
        this.offerRepository = offerRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public OfferServiceModel save(OfferServiceModel model) {
        this.offerRepository.saveAndFlush(this.modelMapper.map(model, Offer.class));
        return model;
    }

    @Override
    public List<OfferServiceModel> find(String apartmentType) {
       List<OfferServiceModel> models= this.offerRepository.findAllByApartmentType(apartmentType).stream().
                map(x->this.modelMapper.map(x,OfferServiceModel.class)).collect(Collectors.toList());
       if(models.size()==0){
           return null;
       }
       return models;
    }

    @Override
    public OfferServiceModel delete(OfferServiceModel offerServiceModel) {
        this.offerRepository.delete(this.modelMapper.map(offerServiceModel,Offer.class));
        return offerServiceModel;
    }

    @Override
    public List<OfferServiceModel> findAll() {
        return this.offerRepository.findAll().stream().map(x->this.modelMapper.map(x,OfferServiceModel.class)).
                collect(Collectors.toList());
    }
}
