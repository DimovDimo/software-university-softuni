package softuni.web.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import softuni.domain.models.view.OfferViewModel;
import softuni.service.OfferService;

import java.io.*;
import java.util.List;
import java.util.stream.Collectors;


@Controller
public class HomeController {
    private final String PATH_FILE="D:\\000000 PROGRAMMING COURSE\\10 JAVA WEB MODULE\\02 Java MVC Frameworks - Spring\\01 SPRING BOOT INTRODUCTION\\Exrecise\\springintro\\src\\main\\resources\\static\\index.html";
 private final OfferService offerService;
 private final ModelMapper modelMapper;

    @Autowired
    public HomeController(OfferService offerService, ModelMapper modelMapper) {
        this.offerService = offerService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/")
    @ResponseBody
    public String find() throws IOException {
        BufferedReader bufferedReader = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(
                                new File(PATH_FILE)
                        )
                ));
        StringBuilder sbFile = new StringBuilder();
        String line;

        while ((line = bufferedReader.readLine()) != null) {
            sbFile.append(line).append(System.lineSeparator());
        }

        List<OfferViewModel> models = this.offerService.findAll().stream().
                map(x -> this.modelMapper.map(x, OfferViewModel.class)).collect(Collectors.toList());
        StringBuilder sb = new StringBuilder();
        String indexST = null;
        if (models.size() == 0) {
          indexST=sbFile.toString().replace("{{p}}", "There aren`t any offers!");

        } else {
            for (OfferViewModel model : models) {
                sb.append(model.toString()).append(System.lineSeparator());
            }
            indexST=sbFile.toString().replace("{{p}}", sb.toString());
        }
        return indexST;
    }
}
