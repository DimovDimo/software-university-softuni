package softuni.web.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import softuni.domain.models.binding.OfferBindingModel;
import softuni.domain.models.service.OfferServiceModel;
import softuni.service.OfferService;

import java.math.BigDecimal;

@Controller
public class RegisterController {
 private final OfferService offerService;
 private final ModelMapper modelMapper;

 @Autowired
    public RegisterController(OfferService offerService, ModelMapper modelMapper) {
        this.offerService = offerService;
     this.modelMapper = modelMapper;
 }

    @GetMapping("/register")
    public String register() {
        return "register.html";
    }

    @PostMapping("/register")
    public String registerOffer(OfferBindingModel offerBindingModel) {
     if(  offerBindingModel.getAgencyCommission()==null || offerBindingModel.getApartmentRent()==null){
         return "redirect:/register";
     }

        if((offerBindingModel.getAgencyCommission().compareTo(new BigDecimal("0.00"))
        <0 || offerBindingModel.getAgencyCommission().compareTo(new BigDecimal("100"))>0 ||
         offerBindingModel.getApartmentRent().compareTo(new BigDecimal("0.00"))<0 ||
                offerBindingModel.getApartmentType().equals(""))){
            return "redirect:/register";
        }
        OfferServiceModel model=this.modelMapper.map(offerBindingModel,OfferServiceModel.class);
        this.offerService.save(model);
        return"redirect:/";

    }

}
