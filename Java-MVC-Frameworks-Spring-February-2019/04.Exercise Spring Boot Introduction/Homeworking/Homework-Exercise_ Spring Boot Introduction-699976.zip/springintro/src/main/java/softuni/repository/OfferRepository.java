package softuni.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.domain.entities.Offer;

import java.util.List;

@Repository
public interface OfferRepository extends JpaRepository<Offer,String> {

    Offer saveAndFlush(Offer offer);
    List<Offer> findAllByApartmentType(String apartmentType);
    List<Offer> findAll();
    @Override
    void delete(Offer offer);
}
