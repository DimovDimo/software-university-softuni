﻿using System;

public static class Heap<T> where T : IComparable<T>
{
    public static void Sort(T[] arr)
    {
        throw new NotImplementedException();
    }
}
